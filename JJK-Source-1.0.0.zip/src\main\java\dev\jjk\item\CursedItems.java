package dev.jjk.item;

import dev.jjk.JJKPlugin;
import dev.jjk.character.CharacterType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;
import java.util.Locale;

/**
 * Optional item activation: right-click a Cursed Object to transform.
 *  - Sukuna's Finger (sukuna)
 *  - Gojo's Blindfold (gojo)
 *  - Ten Shadows Seal (megumi)
 *  - Blood of the Death Painting (yuji)
 *  - Inventory Curse (toji)
 */
public final class CursedItems implements Listener {

    private final JJKPlugin plugin;

    public CursedItems(JJKPlugin plugin) { this.plugin = plugin; }

    public ItemStack create(String kind) {
        return switch (kind.toLowerCase(Locale.ROOT)) {
            case "finger" -> object(Material.ROTTEN_FLESH, "Sukuna's Finger", CharacterType.SUKUNA);
            case "blindfold" -> object(Material.BLACK_DYE, "Gojo's Blindfold", CharacterType.GOJO);
            case "seal" -> object(Material.INK_SAC, "Ten Shadows Seal", CharacterType.MEGUMI);
            case "blood" -> object(Material.RED_DYE, "Blood of the Death Painting", CharacterType.YUJI);
            case "curse" -> object(Material.CHEST, "Inventory Curse", CharacterType.TOJI);
            default -> null;
        };
    }

    private ItemStack object(Material mat, String name, CharacterType type) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name, NamedTextColor.LIGHT_PURPLE).decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Cursed Object — right-click to become", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.text(type.displayName(), NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false)));
        meta.getPersistentDataContainer().set(plugin.cursedObjectKey(), PersistentDataType.STRING, type.id());
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = e.getItem();
        if (item == null || !item.hasItemMeta()) return;
        // Ability icons are handled (and cancelled) by CombatInputListener.
        if (plugin.characters().isAbilityItem(item)) return;
        String id = item.getItemMeta().getPersistentDataContainer()
                .get(plugin.cursedObjectKey(), PersistentDataType.STRING);
        if (id == null) return;
        CharacterType type = CharacterType.fromString(id);
        if (type == null) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        plugin.characters().transform(p, type);
    }
}
