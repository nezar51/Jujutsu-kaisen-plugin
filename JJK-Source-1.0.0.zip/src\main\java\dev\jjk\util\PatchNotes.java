package dev.jjk.util;

import dev.jjk.JJKPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;

import java.io.File;
import java.util.List;

/** The clickable "Patchs & Feed Backs" word and its in-game book. */
public final class PatchNotes {

    private final JJKPlugin plugin;
    private YamlConfiguration config;

    public PatchNotes(JJKPlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "patches.yml");
        if (!file.exists()) plugin.saveResource("patches.yml", false);
        config = YamlConfiguration.loadConfiguration(file);
    }

    public boolean enabled() { return config.getBoolean("enabled", true); }

    public String version() { return config.getString("latest.version", "1.0.1"); }

    public Component announcement() {
        return Component.text("Patchs & Feed Backs", NamedTextColor.GOLD, TextDecoration.BOLD)
                .clickEvent(ClickEvent.runCommand("/jjk patches"))
                .hoverEvent(HoverEvent.showText(Component.text("Click to read patch " + version(), NamedTextColor.LIGHT_PURPLE)));
    }

    public void notify(Player p) {
        if (!enabled()) return;
        p.sendMessage(Component.text("[JJK] ", NamedTextColor.LIGHT_PURPLE).append(announcement()));
    }

    public void broadcastToOnline() {
        if (!enabled()) return;
        for (Player p : plugin.getServer().getOnlinePlayers()) notify(p);
    }

    public void open(Player p) {
        if (!enabled()) return;
        ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
        BookMeta meta = (BookMeta) book.getItemMeta();
        meta.title(plugin.messages().component(config.getString("latest.title", "JJK Patch Notes")));
        meta.author(plugin.messages().component(config.getString("latest.author", "JJK Dev")));
        List<Component> pages = config.getStringList("latest.pages").stream()
                .map(s -> plugin.messages().component(s)).toList();
        meta.pages(pages);
        book.setItemMeta(meta);
        p.openBook(book);
    }

}
