package dev.jjk.character;

import org.bukkit.Material;

/**
 * The five playable JJK characters.
 */
public enum CharacterType {
    GOJO("gojo", "Satoru Gojo", Material.ENDER_EYE),
    SUKUNA("sukuna", "Ryomen Sukuna", Material.BLAZE_ROD),
    MEGUMI("megumi", "Megumi Fushiguro", Material.INK_SAC),
    YUJI("yuji", "Yuji Itadori", Material.REDSTONE),
    TOJI("toji", "Toji Fushiguro", Material.IRON_SWORD);

    private final String id;
    private final String displayName;
    private final Material menuIcon;

    CharacterType(String id, String displayName, Material menuIcon) {
        this.id = id;
        this.displayName = displayName;
        this.menuIcon = menuIcon;
    }

    public String id() { return id; }
    public String displayName() { return displayName; }
    public Material menuIcon() { return menuIcon; }

    public boolean usesStamina() { return this == TOJI; }

    public static CharacterType fromString(String s) {
        if (s == null) return null;
        for (CharacterType t : values()) {
            if (t.id.equalsIgnoreCase(s) || t.name().equalsIgnoreCase(s)) return t;
        }
        return null;
    }
}
