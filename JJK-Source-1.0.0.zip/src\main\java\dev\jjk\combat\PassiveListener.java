package dev.jjk.combat;

import dev.jjk.JJKPlugin;
import dev.jjk.character.CharacterType;
import dev.jjk.skills.GojoController;
import dev.jjk.skills.TojiController;
import dev.jjk.skills.YujiController;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Combat passives: Gojo's Infinity, Yuji's Black Flash window & Manji counter,
 * Toji's momentum gauge & ISOH nullification, shikigami on-hit effects and
 * Mahoraga's damage adaptation.
 */
public final class PassiveListener implements Listener {

    private final JJKPlugin plugin;

    public PassiveListener(JJKPlugin plugin) { this.plugin = plugin; }

    private Player resolveAttacker(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof Projectile proj) {
            ProjectileSource src = proj.getShooter();
            if (src instanceof Player p) return p;
        }
        return null;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamageByEntity(EntityDamageByEntityEvent e) {
        if (e.isCancelled()) return;
        Entity damager = e.getDamager();
        Entity victim = e.getEntity();
        Player attacker = resolveAttacker(damager);

        // --- Mahoraga adaptation -------------------------------------
        if (plugin.summons().isSummon(victim) && "mahoraga".equals(plugin.summons().kindOf(victim))) {
            String signature = e.getCause().name();
            if (attacker != null && plugin.characters().type(attacker) != null) {
                signature += "|" + plugin.characters().type(attacker).id();
            }
            double mult = plugin.summons().adaptationMultiplier(victim, signature);
            e.setDamage(e.getDamage() * mult);
            victim.getWorld().spawnParticle(Particle.END_ROD, victim.getLocation().add(0, 3, 0), 6, 0.3, 0.3, 0.3, 0.05);
            if (mult <= 0.4 && attacker != null) {
                attacker.sendMessage(Component.text("Mahoraga has adapted to your technique.", NamedTextColor.GOLD));
            }
        }

        // --- Shikigami on-hit effects ---------------------------------
        if (plugin.summons().isSummon(damager) && victim instanceof LivingEntity le) {
            String kind = plugin.summons().kindOf(damager);
            if ("dog".equals(kind)) applyBleed(le);
            if ("nue".equals(kind)) {
                le.getWorld().strikeLightningEffect(le.getLocation());
                le.damage(2.0, damager);
                le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 3));
                le.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 60, 1));
            }
        }

        // --- Attacker-side passives -----------------------------------
        if (attacker != null) {
            if (plugin.domains().isStunned(attacker)) { e.setCancelled(true); return; }
            CharacterType at = plugin.characters().type(attacker);
            if (at == CharacterType.YUJI) {
                YujiController yuji = (YujiController) plugin.controller(CharacterType.YUJI);
                // Black Flash: left-click hit inside the timing window after a cast.
                boolean guaranteed = yuji.consumeGuaranteedBlackFlash(attacker);
                boolean inWindow = yuji.inBlackFlashWindow(attacker);
                if (guaranteed || inWindow) {
                    double mult = plugin.getConfig().getDouble("black-flash.damage-multiplier", 2.5);
                    e.setDamage(e.getDamage() * mult);
                    double refill = plugin.getConfig().getDouble("black-flash.ce-refill", 40);
                    plugin.energy().add(attacker, refill);
                    blackFlashFx(victim);
                    attacker.sendActionBar(Component.text(" BLACK FLASH ", NamedTextColor.DARK_RED));
                    attacker.playSound(attacker.getLocation(), "entity.warden.sonic_boom", 0.8f, 1.6f);
                    yuji.resetWindow(attacker);
                }
                if (yuji.shrineAwakened(attacker)) {
                    // Shrine awakening: bonus soul cut on melee.
                    if (victim instanceof LivingEntity le) {
                        plugin.fx().hit(le, 3.0, attacker, true, true);
                        plugin.fx().dust(le.getLocation().add(0, 1, 0), Color.RED, 1f, 5, 0.3);
                    }
                }
            }
            if (at == CharacterType.TOJI && victim instanceof LivingEntity) {
                double gain = plugin.getConfig().getDouble("energy.toji-stamina-per-hit", 8);
                plugin.energy().add(attacker, gain);
            }
        }

        // --- Victim-side passives -------------------------------------
        if (victim instanceof Player vp) {
            CharacterType vt = plugin.characters().type(vp);

            // Toji's Inverted Spear of Heaven: nullify active techniques on hit.
            if (DamageFlags.consumeIsoh(vp.getUniqueId())) {
                nullifyTechniques(vp, vt);
            }

            boolean unblockable = DamageFlags.consumeUnblockable(vp.getUniqueId());
            boolean sureHit = attacker != null && plugin.domains().hasSureHit(attacker);

            // Gojo's Infinity
            if (vt == CharacterType.GOJO) {
                GojoController gojo = (GojoController) plugin.controller(CharacterType.GOJO);
                if (gojo.isInfinity(vp) && !unblockable && !sureHit) {
                    if (!plugin.energy().consume(vp, 5)) {
                        gojo.setInfinity(vp, false);
                        vp.sendMessage(Component.text("Infinity collapsed — out of Cursed Energy!", NamedTextColor.RED));
                    } else {
                        e.setCancelled(true);
                        if (damager instanceof Projectile proj) {
                            proj.setVelocity(proj.getVelocity().multiply(-0.6));
                            plugin.fx().dust(proj.getLocation(), Color.fromRGB(120, 180, 255), 1.4f, 8, 0.2);
                        } else if (damager instanceof LivingEntity le) {
                            le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 2));
                            plugin.fx().knock(le, le.getLocation().toVector().subtract(vp.getLocation().toVector()), 0.4);
                            plugin.fx().ring(vp.getLocation(), 1.6, Color.fromRGB(120, 180, 255), 16);
                        }
                        return;
                    }
                }
            }

            // Yuji's Manji Kick counter stance
            if (vt == CharacterType.YUJI && !(damager instanceof Projectile) && !sureHit) {
                YujiController yuji = (YujiController) plugin.controller(CharacterType.YUJI);
                if (yuji.consumeManjiStance(vp) && damager instanceof LivingEntity le) {
                    e.setCancelled(true);
                    plugin.bridge().play(vp, "anim_manji_kick");
                    plugin.fx().hit(le, 8.0, vp, false, false);
                    plugin.fx().knock(le, le.getLocation().toVector().subtract(vp.getLocation().toVector()).setY(0.5), 1.6);
                    vp.getWorld().spawnParticle(Particle.SWEEP_ATTACK, le.getLocation().add(0, 1, 0), 3, 0.3, 0.3, 0.3, 0);
                    vp.playSound(vp.getLocation(), "entity.player.attack.strong", 1f, 0.8f);
                }
            }
        }
    }

    private void nullifyTechniques(Player vp, CharacterType vt) {
        if (vt == CharacterType.GOJO) {
            ((GojoController) plugin.controller(CharacterType.GOJO)).setInfinity(vp, false);
        }
        plugin.fx().dispel(vp);
        plugin.summons().despawnAll(vp);
        plugin.domains().endFor(vp);
        vp.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, vp.getLocation().add(0, 1, 0), 25, 0.4, 0.7, 0.4, 0.1);
        vp.sendMessage(Component.text("Inverted Spear of Heaven nullified your technique!", NamedTextColor.DARK_AQUA));
        vp.playSound(vp.getLocation(), "block.glass.break", 1f, 0.6f);
    }

    private void blackFlashFx(Entity victim) {
        var loc = victim.getLocation().add(0, 1, 0);
        var world = victim.getWorld();
        world.spawnParticle(Particle.SONIC_BOOM, loc, 1);
        plugin.fx().dust(loc, Color.BLACK, 2.2f, 14, 0.4);
        plugin.fx().dust(loc, Color.fromRGB(200, 20, 20), 1.8f, 14, 0.4);
        world.spawnParticle(Particle.ELECTRIC_SPARK, loc, 20, 0.4, 0.5, 0.4, 0.2);
        // Black-and-red ItemDisplay sparks.
        var black = plugin.fx().itemDisplay(loc, Material.COAL, 0.5f);
        var red = plugin.fx().itemDisplay(loc.clone().add(0.3, 0.2, 0), Material.REDSTONE, 0.5f);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (black.isValid()) black.remove();
            if (red.isValid()) red.remove();
        }, 8L);
    }

    private void applyBleed(LivingEntity le) {
        new BukkitRunnable() {
            int ticks = 0;
            @Override public void run() {
                if (!le.isValid() || le.isDead() || ticks++ >= 4) { cancel(); return; }
                le.damage(1.0);
                plugin.fx().dust(le.getLocation().add(0, 1, 0), Color.fromRGB(160, 0, 0), 1f, 6, 0.3);
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    // --- Toji: no fall damage after Heavenly Blitz ---------------------
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (plugin.characters().type(p) != CharacterType.TOJI) return;
        if (e.getCause() == EntityDamageEvent.DamageCause.FALL) {
            TojiController toji = (TojiController) plugin.controller(CharacterType.TOJI);
            if (toji.noFall(p)) e.setCancelled(true);
        }
    }
}
