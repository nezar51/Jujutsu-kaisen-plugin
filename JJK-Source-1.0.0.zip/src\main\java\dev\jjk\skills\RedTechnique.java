package dev.jjk.skills;

import dev.jjk.JJKPlugin;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Gojo - Cursed Technique Reversal: Red, built entirely from particles.
 * No display entities, models or resource packs are used.
 *
 *   ticks  0-15  tight pulsing crimson orb
 *   ticks 15-40  inward-collapsing helical vortex
 *   tick  40     white flash + red blast, area damage and knockback
 *   ticks 40-90  gravity-driven dark red debris
 */
public final class RedTechnique {

    private static final Particle.DustOptions RED =
            new Particle.DustOptions(Color.fromRGB(220, 20, 30), 1.6f);
    private static final Particle.DustOptions DARK_RED =
            new Particle.DustOptions(Color.fromRGB(120, 8, 16), 1.3f);
    private static final Particle.DustOptions WHITE =
            new Particle.DustOptions(Color.fromRGB(255, 245, 245), 2.2f);

    private final JJKPlugin plugin;

    public RedTechnique(JJKPlugin plugin) { this.plugin = plugin; }

    public void cast(Player caster) {
        Vector dir = caster.getEyeLocation().getDirection().clone().normalize();
        Location center = caster.getEyeLocation().clone().add(dir.clone().multiply(1.5));

        caster.getWorld().playSound(center, "entity.blaze.shoot", 1f, 0.7f);

        List<Debris> debris = new ArrayList<>();

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                World world = center.getWorld();

                // The orb drifts forward along the player's gaze until detonation.
                if (tick < 40) center.add(dir.clone().multiply(0.16));

                if (tick < 15) {
                    phaseOrb(world, center, tick);
                } else if (tick < 40) {
                    phaseVortex(world, center, tick);
                } else if (tick == 40) {
                    phaseDetonation(world, center, caster, debris);
                } else {
                    phaseDebris(world, debris);
                }

                tick++;
                if (tick > 90) cancel();
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ------------------------------------------------------------------
    // Phase 1 - pulsing sphere that tightens (ticks 0-15)
    // ------------------------------------------------------------------
    private void phaseOrb(World world, Location center, int tick) {
        double progress = tick / 15.0;
        double pulse = 1.0 + 0.18 * Math.sin(tick * 0.9);
        double radius = (1.15 - 0.65 * progress) * pulse;
        for (int i = 0; i < 90; i++) {
            Location p = center.clone().add(randomUnit().multiply(radius));
            world.spawnParticle(Particle.DUST, p, 1, 0.02, 0.02, 0.02, 0, RED);
        }
        world.spawnParticle(Particle.DUST, center, 6, 0.15, 0.15, 0.15, 0, RED);
    }

    // ------------------------------------------------------------------
    // Phase 2 - rotating helix rings collapsing inward (ticks 15-40)
    // ------------------------------------------------------------------
    private void phaseVortex(World world, Location center, int tick) {
        double progress = (tick - 15) / 25.0;
        double radius = 2.3 - 1.85 * progress;
        int rings = 4;
        int pointsPerRing = 14;
        for (int r = 0; r < rings; r++) {
            double base = tick * 0.38 + r * (2 * Math.PI / rings);
            for (int i = 0; i < pointsPerRing; i++) {
                double a = base + i * (2 * Math.PI / pointsPerRing);
                double y = Math.sin(a * 2 + r) * 0.5 * (1 - progress) + (r - 1.5) * 0.22;
                Location p = center.clone().add(Math.cos(a) * radius, y, Math.sin(a) * radius);
                world.spawnParticle(Particle.DUST, p, 1, 0, 0, 0, 0, RED);
            }
        }
        world.spawnParticle(Particle.DUST, center, 12, 0.25, 0.25, 0.25, 0, RED);
    }

    // ------------------------------------------------------------------
    // Phase 3 - flash, outward blast, damage + knockback (tick 40)
    // ------------------------------------------------------------------
    private void phaseDetonation(World world, Location center, Player caster, List<Debris> debris) {
        world.spawnParticle(Particle.FLASH, center, 40, 0.25, 0.25, 0.25, 0);
        world.spawnParticle(Particle.DUST, center, 110, 0.4, 0.4, 0.4, 0, WHITE);
        world.spawnParticle(Particle.DUST, center, 200, 1.6, 1.6, 1.6, 0.85, RED);
        world.spawnParticle(Particle.EXPLOSION_EMITTER, center, 1);
        plugin.fx().sharp(center, caster.getEyeLocation().getDirection(), 28);
        world.playSound(center, "entity.generic.explode", 1.4f, 0.8f);
        world.playSound(center, "entity.warden.sonic_boom", 0.8f, 1.6f);

        double maxDamage = plugin.getConfig().getDouble("red.damage", 16.0);
        double radius = 6.0;
        double knockback = plugin.getConfig().getDouble("red.knockback", 2.4);

        for (Entity e : world.getNearbyEntities(center, radius, radius, radius)) {
            if (!(e instanceof LivingEntity le) || e.equals(caster)) continue;
            Vector away = le.getLocation().toVector().subtract(center.toVector());
            double dist = away.length();
            if (dist < 0.001) away = caster.getEyeLocation().getDirection().clone();
            away.normalize().multiply(knockback * (1.0 - Math.min(1.0, dist / radius)));
            away.setY(Math.max(0.55, away.getY()));
            le.setVelocity(le.getVelocity().add(away));
            double damage = Math.max(1.0, maxDamage * (1.0 - dist / radius));
            plugin.fx().hit(le, damage, caster, false, false);
        }

        plugin.fx().deleteSphere(caster, center, radius);

        // Seed the debris field for phase 4.
        for (int i = 0; i < 90; i++) {
            Vector offset = randomUnit().multiply(1.0 + ThreadLocalRandom.current().nextDouble(0, 3.5));
            offset.setY(Math.abs(offset.getY()) * 0.8 + 0.3);
            debris.add(new Debris(
                    center.clone().add(offset),
                    new Vector(offset.getX() * 0.05, 0.04, offset.getZ() * 0.05)));
        }
    }

    // ------------------------------------------------------------------
    // Phase 4 - gravity-driven dark red debris (ticks 41-90)
    // ------------------------------------------------------------------
    private void phaseDebris(World world, List<Debris> debris) {
        debris.removeIf(d -> {
            d.velocity.setY(d.velocity.getY() - 0.012); // gravity
            d.location.add(d.velocity);
            world.spawnParticle(Particle.DUST, d.location, 1, 0.03, 0.03, 0.03, 0, DARK_RED);
            return d.location.getY() < d.groundY - 0.2;
        });
    }

    private static final class Debris {
        final Location location;
        final Vector velocity;
        final double groundY;
        Debris(Location location, Vector velocity) {
            this.location = location;
            this.velocity = velocity;
            this.groundY = location.clone().subtract(0, 2, 0).getY();
        }
    }

    private static Vector randomUnit() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double u = r.nextDouble(-1, 1);
        double theta = r.nextDouble(0, 2 * Math.PI);
        double s = Math.sqrt(1 - u * u);
        return new Vector(s * Math.cos(theta), u, s * Math.sin(theta));
    }
}
