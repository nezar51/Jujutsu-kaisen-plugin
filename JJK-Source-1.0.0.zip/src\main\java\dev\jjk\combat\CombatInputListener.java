package dev.jjk.combat;

import dev.jjk.JJKPlugin;
import dev.jjk.character.CharacterType;
import dev.jjk.gui.CharacterMenu;
import dev.jjk.util.FX;
import dev.jjk.util.Sounds;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Method A of the dual keybind system: native vanilla inputs.
 *
 *  1-4   PlayerItemHeldEvent      -> cancel + instant cast (Shift = variant)
 *  5     PlayerItemHeldEvent      -> exit transformation
 *  F     PlayerSwapHandItemsEvent -> passive / stance (Shift+F = domain)
 *  Q     PlayerDropItemEvent      -> character ultimate technique (Shift+Q = dash)
 *  LMB   PlayerAnimationEvent     -> combo animation hooks / Black Flash finisher
 *
 * Method B (silent /jjk skill commands) routes into the same cast() gate.
 */
public final class CombatInputListener implements Listener {

    private final JJKPlugin plugin;
    /** Last ability key (1-6) each player cast, for right-click / left-click recasts. */
    private final Map<UUID, Integer> lastAbilitySlot = new HashMap<>();

    public CombatInputListener(JJKPlugin plugin) { this.plugin = plugin; }

    // ------------------------------------------------------------------
    // Hotbar keys 1-9
    // ------------------------------------------------------------------
    @EventHandler(priority = EventPriority.LOWEST)
    public void onHeld(PlayerItemHeldEvent e) {
        Player p = e.getPlayer();
        if (!plugin.characters().isTransformed(p) || plugin.characters().isSwitching(p)) return;
        int slot = e.getNewSlot();
        // Do NOT cancel this event. Cancelling makes the client revert the held
        // slot to 0, which fires a second event that re-casts move 1 (making
        // key N appear to cast move N-1). Letting the slot change stand keeps
        // key N mapped exactly to move N.
        if (slot == CharacterController.EXIT_SLOT) {
            plugin.characters().exit(p, "key 9");
            return;
        }
        // Slot 1 (index 0) is intentionally empty. From slot 2 onward, the slot
        // index equals the move number, so key N casts move N directly.
        if (slot == 0 || slot > CharacterController.HOTBAR_SKILLS) return;
        CharacterController ctrl = plugin.characters().controller(p);
        SkillDef def = ctrl.skill(p, slot, p.isSneaking());
        if (def != null) {
            lastAbilitySlot.put(p.getUniqueId(), slot);
            cast(p, def);
            // Silently return the cursor to slot 1 so pressing the same key
            // again fires a fresh event (server-side changes fire no event).
            p.getInventory().setHeldItemSlot(0);
        }
    }

    // ------------------------------------------------------------------
    // F / Shift+F
    // ------------------------------------------------------------------
    @EventHandler(priority = EventPriority.LOWEST)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        Player p = e.getPlayer();
        if (!plugin.characters().isTransformed(p) || plugin.characters().isSwitching(p)) return;
        e.setCancelled(true);
        CharacterController ctrl = plugin.characters().controller(p);
        SkillDef def = p.isSneaking() ? ctrl.domain(p) : ctrl.passive();
        if (def != null) cast(p, def);
    }

    // ------------------------------------------------------------------
    // Q -> character ultimate technique (Shift+Q -> mobility dash)
    // ------------------------------------------------------------------
    @EventHandler(priority = EventPriority.LOWEST)
    public void onDrop(PlayerDropItemEvent e) {
        Player p = e.getPlayer();
        if (plugin.characters().isSwitching(p)) return;
        if (p.isSneaking()) {
            e.setCancelled(true);
            dash(p);
            return;
        }
        if (!plugin.characters().isTransformed(p)) return;
        e.setCancelled(true);
        CharacterController ctrl = plugin.characters().controller(p);
        if (ctrl == null) return;

        SkillDef ultimate = ctrl.ultimate(p);
        if (ultimate != null) {
            cast(p, ultimate);
        } else {
            // Safety net for characters without a dedicated Q technique.
            dash(p);
        }
    }

    /** Forward burst dash (Shift+Q, and fallback for characters with no Q skill). */
    public void dash(Player p) {
        if (plugin.domains().isStunned(p)) {
            plugin.energy().flash(p, "§c§lFrozen in Unlimited Void...");
            return;
        }
        String cdKey = p.getUniqueId() + ":dash";
        if (plugin.cooldowns().remaining(p, cdKey) > 0) {
            plugin.energy().flash(p, "§7Dash on cooldown.");
            return;
        }
        plugin.cooldowns().set(p, cdKey, 800);
        p.getWorld().spawnParticle(Particle.SONIC_BOOM, p.getLocation().add(0, 1, 0), 2, 0.5, 0.5, 0.5, 0);
        plugin.sounds().play(p, Sounds.DASH, 1f, 1.2f);
        FX fx = plugin.fx();
        Location dest = fx.forwardTeleport(p, 10);
        p.teleport(dest);
        p.getWorld().spawnParticle(Particle.SONIC_BOOM, dest.clone().add(0, 1, 0), 2, 0.5, 0.5, 0.5, 0);
        fx.dust(dest.clone().add(0, 1, 0), Color.fromRGB(200, 200, 255), 1.5f, 25, 0.6);
        fx.afterimage(p);
    }

    // ------------------------------------------------------------------
    // Left click
    // ------------------------------------------------------------------
    @EventHandler
    public void onAnimation(PlayerAnimationEvent e) {
        if (e.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        Player p = e.getPlayer();
        if (!plugin.characters().isTransformed(p)) return;
        CharacterController ctrl = plugin.characters().controller(p);
        if (ctrl == null) return;

        // Finishers first: Gojo barrage Black Flash / Yuji Black Flash / fist hits.
        // Only if nothing consumed the click do we fall back to a left-click variant.
        if (ctrl.onLeftClick(p)) return;

        if (plugin.getConfig().getBoolean("input.left-click-variants", true)) {
            int held = p.getInventory().getHeldItemSlot();
            if (held >= 0 && held <= CharacterController.HOTBAR_SKILLS) {
                int move = lastAbilitySlot.getOrDefault(p.getUniqueId(), held == 0 ? 1 : held);
                SkillDef variant = ctrl.skill(p, move, true);
                if (variant != null && variant.leftClickVariant) cast(p, variant);
            }
        }
    }

    // ------------------------------------------------------------------
    // Shift+G (or any key mapped to /jjk ultimate) - Ultimate Form
    // ------------------------------------------------------------------
    @EventHandler(priority = EventPriority.LOWEST)
    public void onInteractUltimate(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        if (!plugin.characters().isTransformed(p) || plugin.characters().isSwitching(p)) return;
        if (!p.isSneaking()) return;
        
        if (plugin.getConfig().getBoolean("input.ultimate-key-enabled", true)) {
            e.setCancelled(true);
            CharacterController ctrl = plugin.characters().controller(p);
            if (ctrl != null) {
                if (ctrl.isUltimateForm(p)) {
                    ctrl.exitUltimateForm(p);
                } else {
                    ctrl.enterUltimateForm(p);
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // The 4-step cast gate (shared by hotbar inputs AND silent commands)
    // ------------------------------------------------------------------
    public void cast(Player p, SkillDef def) {
        CharacterType type = plugin.characters().type(p);
        if (type == null || def == null) return;
        CharacterController ctrl = plugin.controller(type);
        if (ctrl.isUltimateSkill(def) && !ctrl.isUltimateForm(p)) {
            plugin.energy().flash(p, "§dEnter Ultimate Form first.");
            return;
        }

        // 1. Stun / domain / chain-cuff check.
        if (plugin.domains().isStunned(p)) {
            plugin.energy().flash(p, "§c§lFrozen in Unlimited Void...");
            return;
        }
        if (plugin.chains().isChained(p.getUniqueId())) {
            plugin.energy().flash(p, "§cBound by chains - unable to cast!");
            return;
        }

        // 2. Cooldown check (ms timestamps + vanilla item cooldown overlay).
        String cdKey = type.id() + ":" + def.key;
        long remaining = plugin.cooldowns().remaining(p, cdKey);
        if (remaining > 0) {
            plugin.energy().flash(p, "§e" + def.name + " §7on cooldown: §f" + String.format("%.1f", remaining / 1000.0) + "s");
            return;
        }

        // 3. Cursed Energy / Stamina check (Six Eyes discount for Gojo).
        double cost = def.cost;
        if (type == CharacterType.GOJO) {
            cost *= plugin.getConfig().getDouble("energy.six-eyes-cost-multiplier", 0.6);
        }
        if (!plugin.energy().consume(p, cost)) {
            String res = type.usesStamina() ? "Stamina" : "Cursed Energy";
            plugin.energy().flash(p, "§c§lNot enough " + res + "! §7(" + (int) cost + " needed)");
            return;
        }

        // 4. Execution & sync: cooldown, overlay, BetterModel animation, skill.
        plugin.cooldowns().set(p, cdKey, def.cooldownMs);
        applyVisualCooldown(p, ctrl, def);
        plugin.bridge().play(p, def.animationId);
        plugin.sounds().play(p, Sounds.CAST, 0.8f, 1f);
        ctrl.onCast(p, def);
        def.execute(p);
    }

    private void applyVisualCooldown(Player p, CharacterController ctrl, SkillDef def) {
        try {
            int slot = Integer.parseInt(def.key.replace("s", "")) - 1;
            org.bukkit.Material[] icons = ctrl.activeIcons(p);
            if (slot >= 0 && slot < Math.min(CharacterController.HOTBAR_SKILLS, icons.length) && def.cooldownMs > 0) {
                p.setCooldown(icons[slot], (int) (def.cooldownMs / 50));
            }
        } catch (NumberFormatException ignored) {
            // q / f / fs have no hotbar overlay
        }
    }

    // ------------------------------------------------------------------
    // Protection: icons are unmovable, vanilla item usage suppressed
    // ------------------------------------------------------------------
    @EventHandler(priority = EventPriority.LOWEST)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() == Action.PHYSICAL) return;
        if (plugin.characters().isAbilityItem(e.getItem())) {
            e.setCancelled(true); // no pearl throws / bow draws from ability icons
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onRightClick(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        if (!plugin.characters().isTransformed(p) || plugin.characters().isSwitching(p)) return;
        
        // Re-cast the last ability used (or the held icon's move as a fallback).
        int heldSlot = p.getInventory().getHeldItemSlot();
        if (heldSlot < 0 || heldSlot >= CharacterController.HOTBAR_SKILLS) return;
        if (!plugin.characters().isAbilityItem(e.getItem())) return;
        int move = lastAbilitySlot.getOrDefault(p.getUniqueId(), heldSlot + 1);
        CharacterController ctrl = plugin.characters().controller(p);
        SkillDef def = ctrl.skill(p, move, p.isSneaking());
        if (def != null) {
            e.setCancelled(true);
            cast(p, def);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!plugin.characters().isTransformed(p)) return;
        if (e.getView().getTopInventory().getHolder() instanceof CharacterMenu) return; // menu handles itself
        e.setCancelled(true); // hotbar + inventory locked while transformed
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!plugin.characters().isTransformed(p)) return;
        if (e.getView().getTopInventory().getHolder() instanceof CharacterMenu) return;
        e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPickup(EntityPickupItemEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (plugin.characters().isTransformed(p)
                && plugin.getConfig().getBoolean("transform.block-item-pickup", true)) {
            e.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------
    // Unlimited Void freeze
    // ------------------------------------------------------------------
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!plugin.domains().isStunned(e.getPlayer())) return;
        if (e.getFrom().getBlockX() != e.getTo().getBlockX()
                || e.getFrom().getBlockY() != e.getTo().getBlockY()
                || e.getFrom().getBlockZ() != e.getTo().getBlockZ()) {
            e.setCancelled(true);
        }
    }
}
