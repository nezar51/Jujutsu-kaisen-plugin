spackage dev.jjk.skills;

import dev.jjk.JJKPlugin;
import dev.jjk.character.CharacterType;
import dev.jjk.combat.CharacterController;
import dev.jjk.combat.SkillDef;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Satoru Gojo â€” Limitless & Six Eyes.
 * 1 Blue | Shift+1 Maximum Blue | 2 Red | 3 Teleport | 4 Limitless Barrage
 * 5 Six Eyes Scan | 6 Infinity Pulse | 7 Blue Scatter | 8 Red Mine
 * Q Hollow Purple | F Infinity toggle | Shift+F Unlimited Void
 */
public final class GojoController extends CharacterController {

    private static final Color BLUE = Color.fromRGB(60, 120, 255);
    private static final Color RED = Color.fromRGB(255, 40, 40);
    private static final Color PURPLE = Color.fromRGB(170, 40, 255);
    private static final Particle.DustOptions BLUE_DUST = new Particle.DustOptions(Color.fromRGB(55, 145, 255), 1.25f);
    private static final Particle.DustOptions CYAN_DUST = new Particle.DustOptions(Color.fromRGB(100, 235, 255), 1.1f);
    private static final Particle.DustOptions RED_DUST = new Particle.DustOptions(Color.fromRGB(245, 35, 45), 1.25f);
    private static final Particle.DustOptions VIOLET_DUST = new Particle.DustOptions(PURPLE, 1.6f);
    private static final Particle.DustOptions MAGENTA_DUST = new Particle.DustOptions(Color.fromRGB(245, 70, 220), 1.15f);
    private static final Particle.DustOptions WHITE_DUST = new Particle.DustOptions(Color.WHITE, 1.3f);

    private final Set<UUID> infinity = new HashSet<>();
    private final Map<UUID, BarrageState> barrages = new HashMap<>();
    private final RedTechnique redFx;
    private final BlueTechnique blueFx;

    private static final class BarrageState {
        LivingEntity target;
        long endMillis;
        boolean finished;
    }

    public GojoController(JJKPlugin plugin) {
        super(plugin);
        redFx = new RedTechnique(plugin);
        blueFx = new BlueTechnique(plugin);


        // === NORMAL FORM â€” 4 moves (keys 1-4) ===
        regNormal(1, false, "Cursed Technique Lapse: Blue", "anim_point", 40, 3000, this::blue);
        regNormalLeft(1, "Maximum Output: Blue", "anim_point", 120, 12000, this::maximumBlue);
        regNormal(2, false, "Cursed Technique Reversal: Red", "anim_flick", 50, 5000, this::red);
        regNormal(3, false, "Teleportation (Spatial Compression)", "anim_clasp", 25, 4000, this::teleport);
        regNormal(4, false, "Limitless Barrage", "anim_barrage", 60, 8000, this::barrage);

        // === ULTIMATE FORM â€” "Six Eyes Awakened" (replaces the 4 normal moves) ===
        regUltimate(1, false, "Hollow Technique: Purple", "anim_purple_charge", 120, 12000, this::hollowPurple);
        regUltimate(2, false, "Blue Scatter", "anim_point", 70, 6000, this::blueScatter);
        regUltimate(3, false, "Infinity Pulse", "anim_flick", 45, 5000, this::infinityPulse);
        regUltimate(4, false, "Six Eyes Overload", "anim_clasp", 45, 8000, p -> scan(p, true));

        // === Techniques shared by both forms ===
        reg("q", "Hollow Technique: Purple", "anim_purple_charge", 120, 12000, this::hollowPurple);
        reg("f", "Infinity (Toggle)", "anim_clasp", 0, 500, this::toggleInfinity);
        reg("fs", "Domain Expansion: Unlimited Void", "anim_gojo_domain", 300, 60000,
                p -> plugin.domains().start(p, CharacterType.GOJO));
    }

    @Override public CharacterType type() { return CharacterType.GOJO; }

    @Override public Material[] normalIcons() {
        return new Material[]{Material.BLUE_DYE, Material.RED_DYE, Material.ENDER_PEARL, Material.NETHER_STAR};
    }

    @Override public Material[] ultimateIcons() {
        return new Material[]{Material.PURPLE_DYE, Material.LIGHT_BLUE_DYE, Material.CYAN_DYE, Material.ENDER_EYE};
    }

    // Backward-compat alias used by old cooldown overlay code.
    @Override public Material[] icons() { return normalIcons(); }

    public boolean isInfinity(Player p) { return infinity.contains(p.getUniqueId()); }

    public void setInfinity(Player p, boolean on) {
        if (on) infinity.add(p.getUniqueId());
        else infinity.remove(p.getUniqueId());
    }

    private void toggleInfinity(Player p) {
        boolean on = !isInfinity(p);
        setInfinity(p, on);
        p.playSound(p.getLocation(), on ? "block.amethyst_block.chime" : "block.amethyst_block.break", 1f, on ? 1.4f : 0.8f);
        p.sendMessage(net.kyori.adventure.text.Component.text("Infinity " + (on ? "ENABLED â€” attacks slow and deflect" : "disabled"),
                on ? net.kyori.adventure.text.format.NamedTextColor.AQUA : net.kyori.adventure.text.format.NamedTextColor.GRAY));
    }

    @Override public String status(Player p) { return isInfinity(p) ? "Â§bInfinity ON" : ""; }

    @Override public double stanceDrain(Player p) {
        return isInfinity(p) ? plugin.getConfig().getDouble("energy.stance-drain.gojo", 2) : 0;
    }

    @Override public void tick(Player p) {
        if (isInfinity(p)) {
            if (plugin.energy().get(p) <= 0) {
                setInfinity(p, false);
                return;
            }
            // Spherical particle barrier.
            Location c = p.getLocation().add(0, 1, 0);
            for (int i = 0; i < 14; i++) {
                double a = Math.random() * Math.PI * 2;
                double b = Math.random() * Math.PI - Math.PI / 2;
                double r = 1.7;
                Location pt = c.clone().add(Math.cos(a) * Math.cos(b) * r, Math.sin(b) * r, Math.sin(a) * Math.cos(b) * r);
                fx().dust(pt, BLUE, 0.8f, 1, 0);
            }
        }
    }

    @Override public void onExit(Player p) {
        infinity.remove(p.getUniqueId());
        barrages.remove(p.getUniqueId());
    }

    // ------------------------------------------------------------------
    // ULTIMATE FORM: Six Eyes Awakened â€” replaces the normal moves
    // ------------------------------------------------------------------
    @Override
    protected void onUltimateActivate(Player p) {
        p.sendMessage(net.kyori.adventure.text.Component.text("ã€ŒSix Eyes Awakenedã€ â€” ULTIMATE ACTIVATED!", net.kyori.adventure.text.format.NamedTextColor.LIGHT_PURPLE));
        p.playSound(p.getLocation(), "entity.ender_dragon.death", 1.5f, 0.8f);

        // Gojo ult buffs: Strength 3, Speed 2, Resistance 3.
        p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, PotionEffect.INFINITE_DURATION, 2));
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, PotionEffect.INFINITE_DURATION, 1));
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, PotionEffect.INFINITE_DURATION, 2));

        // Fiery aura + purple energy surge
        Location loc = p.getLocation().add(0, 2, 0);
        for (int i = 0; i < 10; i++) {
            double a = Math.random() * Math.PI * 2;
            double r = 1.5 + Math.random() * 2;
            Location pt = loc.clone().add(Math.cos(a) * r, 0, Math.sin(a) * r);
            fx().dust(pt, PURPLE, 2f, 12, 0.8);
        }
        p.getWorld().spawnParticle(Particle.ENCHANT, loc, 30, 0.6, 1.2, 0.6, 0.15);
        p.getWorld().spawnParticle(Particle.REVERSE_PORTAL, loc, 20, 0.5, 0.9, 0.5, 0.1);
        p.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, loc, 15, 0.4, 0.8, 0.4, 0.05);
    }

    @Override
    protected void onUltimateDeactivate(Player p) {
        // Ultimate ended â€” restore normal form effects
        Location loc = p.getLocation().add(0, 1, 0);
        p.getWorld().spawnParticle(Particle.ENCHANT, loc, 20, 0.5, 0.9, 0.5, 0.08);
        p.playSound(p.getLocation(), "entity.enderman.teleport", 0.8f, 0.5f);
        // Remove ult buffs.
        p.removePotionEffect(PotionEffectType.STRENGTH);
        p.removePotionEffect(PotionEffectType.SPEED);
        p.removePotionEffect(PotionEffectType.RESISTANCE);
    }

    @Override public boolean onLeftClick(Player p) {
        boolean used = false;
        BarrageState st = barrages.get(p.getUniqueId());
        if (st != null && !st.finished && st.target != null && st.target.isValid()) {
            // Black Flash finisher on left-click timing.
            st.finished = true;
            fx().hit(st.target, 6.0, p, true, true);
            p.getWorld().spawnParticle(Particle.SONIC_BOOM, st.target.getLocation().add(0, 1, 0), 1);
            fx().dust(st.target.getLocation().add(0, 1, 0), Color.BLACK, 2f, 12, 0.4);
            fx().dust(st.target.getLocation().add(0, 1, 0), RED, 1.6f, 12, 0.4);
            p.playSound(p.getLocation(), "entity.warden.sonic_boom", 0.7f, 1.8f);
            plugin.energy().add(p, 30);
            p.sendActionBar(net.kyori.adventure.text.Component.text("BLACK FLASH", net.kyori.adventure.text.format.NamedTextColor.DARK_RED));
            used = true;
        }
        // Fist impact: Gojo's bare-handed punch
        if (fistImpact(p)) used = true;
        return used;
    }

    // ------------------------------------------------------------------
    private void blue(Player p) {
        blueFx.cast(p);
    }

    private void implode(Player p, Location c, double radius, double damage) {
        fx().aoe(c, radius, damage, p, false, false, le ->
                fx().knock(le, c.toVector().subtract(le.getLocation().toVector()), 0.8));
        fx().expandingRings(c, BLUE, radius);
        c.getWorld().spawnParticle(Particle.EXPLOSION, c, 2);
        c.getWorld().playSound(c, "entity.generic.explode", 1f, 1.4f);
    }

    private void maximumBlue(Player p) {
        ItemDisplay orb = fx().itemDisplay(p.getEyeLocation(), Material.BLUE_DYE, 3.5f);
        fx().register(p, orb);
        p.playSound(p.getLocation(), "block.beacon.power.select", 1.2f, 0.5f);
        new BukkitRunnable() {
            int ticks = 0;
            float angle = 0;
            @Override public void run() {
                if (!orb.isValid() || ticks++ >= 100 || !p.isOnline() || !plugin.characters().isTransformed(p)) {
                    if (orb.isValid()) orb.remove();
                    cancel();
                    return;
                }
                angle += 0.35f;
                Location dest = p.getEyeLocation().add(p.getEyeLocation().getDirection().multiply(6));
                orb.teleport(dest);
                orb.setTransformation(new org.bukkit.util.Transformation(
                        new org.joml.Vector3f(), new org.joml.AxisAngle4f(),
                        new org.joml.Vector3f(3.5f, 3.5f, 3.5f), new org.joml.AxisAngle4f(angle, 0.3f, 1, 0)));
                fx().dust(dest, BLUE, 2f, 10, 1.8);
                if (ticks % 4 == 0) {
                    fx().aoe(dest, 3.5, 3.0, p, false, false, le ->
                            fx().knock(le, dest.toVector().subtract(le.getLocation().toVector()), 0.5));
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void red(Player p) {
        redFx.cast(p);
    }

    private void teleport(Player p) {
        if (mobilitySealed(p)) return;
        Location from = p.getLocation();
        Location dest = fx().forwardTeleport(p, 25);
        p.getWorld().spawnParticle(Particle.SONIC_BOOM, from.add(0, 1, 0), 1);
        p.teleport(dest);
        p.getWorld().spawnParticle(Particle.SONIC_BOOM, dest.clone().add(0, 1, 0), 1);
        fx().dust(dest.clone().add(0, 1, 0), BLUE, 1.5f, 25, 0.6);
        p.playSound(dest, "entity.enderman.teleport", 1f, 1.2f);
    }

    private void barrage(Player p) {
        LivingEntity target = fx().target(p, 12);
        if (target == null) {
            plugin.energy().flash(p, "Â§cNo target in range for Limitless Barrage");
            plugin.cooldowns().reset(p, "gojo:4");
            return;
        }
        BarrageState st = new BarrageState();
        st.target = target;
        st.endMillis = System.currentTimeMillis() + 2500;
        barrages.put(p.getUniqueId(), st);
        p.sendMessage(net.kyori.adventure.text.Component.text("Left-Click NOW for a Black Flash finisher!", net.kyori.adventure.text.format.NamedTextColor.DARK_RED));
        new BukkitRunnable() {
            int hits = 0;
            @Override public void run() {
                if (!target.isValid() || hits >= 10 || st.finished || !p.isOnline()) {
                    barrages.remove(p.getUniqueId());
                    cancel();
                    return;
                }
                hits++;
                double a = Math.random() * Math.PI * 2;
                Location around = target.getLocation().add(Math.cos(a) * 2, 0.2, Math.sin(a) * 2);
                around.setDirection(target.getLocation().toVector().subtract(around.toVector()));
                p.teleport(around);
                fx().hit(target, 2.0, p, false, false);
                p.getWorld().spawnParticle(Particle.CRIT, target.getLocation().add(0, 1, 0), 6, 0.2, 0.3, 0.2, 0.2);
                fx().dust(target.getLocation().add(0, 1, 0), BLUE, 1f, 4, 0.3);
                p.playSound(p.getLocation(), "entity.player.attack.strong", 0.8f, 1.2f);
            }
        }.runTaskTimer(plugin, 0L, 3L);
    }

    private void scan(Player p, boolean overload) {
        int count = 0;
        for (Entity e : p.getNearbyEntities(30, 30, 30)) {
            if (!(e instanceof LivingEntity le) || e.equals(p)) continue;
            le.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 100, 0));
            if (overload) le.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 100, 1));
            count++;
        }
        p.sendMessage(net.kyori.adventure.text.Component.text("Six Eyes: " + count + " entities analyzed" + (overload ? " and weakened" : "") + ".", net.kyori.adventure.text.format.NamedTextColor.AQUA));
        p.playSound(p.getLocation(), "block.enchantment_table.use", 1f, 1.5f);
    }

    private void infinityPulse(Player p) {
        Location c = p.getLocation().add(0, 1, 0);
        fx().aoe(c, 6, 2.0, p, false, false, le -> {
            fx().knock(le, le.getLocation().toVector().subtract(c.toVector()).setY(0.3), 2.0);
            le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 2));
        });
        fx().expandingRings(c, BLUE, 6);
        p.getWorld().playSound(c, "entity.warden.sonic_boom", 0.6f, 1.8f);
    }

    private void blueScatter(Player p) {
        Vector base = p.getEyeLocation().getDirection();
        for (int i = -1; i <= 1; i++) {
            Vector dir = base.clone().rotateAroundY(Math.toRadians(i * 20));
            Location start = p.getEyeLocation().add(dir.clone().multiply(3));
            ItemDisplay orb = fx().itemDisplay(start, Material.LIGHT_BLUE_DYE, 0.8f);
            fx().register(p, orb);
            new BukkitRunnable() {
                int ticks = 0;
                @Override public void run() {
                    if (!orb.isValid() || ticks++ >= 40) {
                        if (orb.isValid()) {
                            implode(p, orb.getLocation(), 2.5, 4);
                            orb.remove();
                        }
                        cancel();
                        return;
                    }
                    Location c = orb.getLocation();
                    fx().dust(c, BLUE, 0.9f, 2, 0.4);
                    for (Entity e : c.getWorld().getNearbyEntities(c, 5, 5, 5)) {
                        if (e instanceof LivingEntity le && !e.equals(p) && !plugin.summons().isOwnedSummon(p, e)) {
                            le.setVelocity(le.getVelocity().add(c.toVector().subtract(le.getLocation().toVector()).normalize().multiply(0.3)));
                        }
                    }
                }
            }.runTaskTimer(plugin, 1L, 1L);
        }
        p.playSound(p.getLocation(), "block.respawn_anchor.charge", 1f, 1.2f);
    }

    private void redMine(Player p) {
        Location loc = fx().forwardTeleport(p, 12);
        ItemDisplay mine = fx().itemDisplay(loc.clone().add(0, 0.6, 0), Material.RED_DYE, 0.7f);
        fx().register(p, mine);
        p.playSound(loc, "block.respawn_anchor.set_spawn", 1f, 0.7f);
        new BukkitRunnable() {
            int ticks = 0;
            @Override public void run() {
                if (!mine.isValid() || ticks++ >= 600) {
                    if (mine.isValid()) mine.remove();
                    cancel();
                    return;
                }
                Location c = mine.getLocation();
                if (ticks % 10 == 0) fx().dust(c, RED, 1f, 3, 0.2);
                for (Entity e : c.getWorld().getNearbyEntities(c, 2.5, 2.5, 2.5)) {
                    if (e instanceof LivingEntity le && !e.equals(p) && !plugin.summons().isOwnedSummon(p, e)) {
                        fx().aoe(c, 3.5, 9.0, p, false, false, x ->
                                fx().knock(x, x.getLocation().toVector().subtract(c.toVector()).setY(0.4), 2.2));
                        fx().expandingRings(c, RED, 4);
                        c.getWorld().spawnParticle(Particle.EXPLOSION, c, 2);
                        c.getWorld().playSound(c, "entity.generic.explode", 1.2f, 0.9f);
                        mine.remove();
                        cancel();
                        return;
                    }
                }
            }
        }.runTaskTimer(plugin, 5L, 2L);
    }

    private void hollowPurple(Player p) {
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().clone().normalize();
        Vector side = dir.clone().crossProduct(new Vector(0, 1, 0));
        if (side.lengthSquared() < 0.01) side = new Vector(1, 0, 0);
        side.normalize();
        p.playSound(eye, "block.beacon.power.select", 1.5f, 0.4f);
        new BukkitRunnable() {
            int ticks = 0;
            @Override public void run() {
                if (!p.isOnline() || ticks > 70) {
                    cancel();
                    return;
                }
                Location center = p.getEyeLocation().clone().add(dir.clone().multiply(3));
                if (ticks < 15) {
                    sphere(center.clone().add(side.clone().multiply(1.65)), BLUE_DUST, ticks * 0.3, 1.0);
                    sphere(center.clone().add(side.clone().multiply(-1.65)), RED_DUST, -ticks * 0.3, 1.0);
                } else if (ticks < 55) {
                    double t = (ticks - 15) / 40.0;
                    sphere(center.clone().add(side.clone().multiply(1.65 * (1 - t))), BLUE_DUST, ticks * 0.55, 1 - 0.45 * t);
                    sphere(center.clone().add(side.clone().multiply(-1.65 * (1 - t))), RED_DUST, -ticks * 0.55, 1 - 0.45 * t);
                    sphere(center, VIOLET_DUST, ticks * 0.8, 0.35 + 0.65 * t);
                    if (ticks % 2 == 0) center.getWorld().spawnParticle(Particle.DUST, center, 5, .25, .25, .25, 0, MAGENTA_DUST);
                } else if (ticks < 70) {
                    ring(center, dir, 0.7 - (ticks - 55) * .025, ticks * .8, VIOLET_DUST, 36);
                    ring(center, dir, 0.45, -ticks * 1.1, WHITE_DUST, 20);
                    center.getWorld().spawnParticle(Particle.DUST, center, 18, .18, .18, .18, 0, MAGENTA_DUST);
                    if (ticks % 4 == 0) p.playSound(center, "block.amethyst_block.resonate", .8f, .7f + ticks * .01f);
                } else {
                    firePurple(p, center, dir);
                    cancel();
                    return;
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void firePurple(Player p, Location start, Vector dir) {
        p.getWorld().playSound(start, "entity.warden.sonic_boom", 1.5f, 0.5f);
        new BukkitRunnable() {
            int ticks = 0;
            @Override public void run() {
                if (ticks++ >= 40) {
                    cancel();
                    return;
                }
                Location next = start.clone().add(dir.clone().multiply(ticks * 1.5));
                fx().dust(next, PURPLE, 2.5f, 15, 1.2);
                ring(next, dir, 1.2 + .3 * Math.sin(ticks), ticks * .8, MAGENTA_DUST, 26);
                next.getWorld().spawnParticle(Particle.END_ROD, next, 8, .7, .7, .7, .04);
                // True damage + block deletion along the path.
                fx().aoe(next, 3.0, 18.0, p, true, true, null);
                if (plugin.griefing()) fx().deleteSphere(p, next, 2.2);
                if (!next.getBlock().isPassable() && !plugin.griefing()) {
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private static void sphere(Location center, Particle.DustOptions dust, double angle, double scale) {
        for (int i = 0; i < 36; i++) {
            double a = angle + i * Math.PI * 2 / 36.0;
            double b = Math.acos(1 - 2 * (i + .5) / 36.0);
            center.getWorld().spawnParticle(Particle.DUST, center.clone().add(Math.cos(a) * Math.sin(b) * scale,
                    Math.cos(b) * scale, Math.sin(a) * Math.sin(b) * scale), 1, 0, 0, 0, 0, dust);
        }
    }

    private static void ring(Location center, Vector normal, double radius, double angle, Particle.DustOptions dust, int points) {
        Vector u = normal.clone().crossProduct(new Vector(0, 1, 0));
        if (u.lengthSquared() < .01) u = new Vector(1, 0, 0);
        u.normalize();
        Vector v = normal.clone().crossProduct(u).normalize();
        for (int i = 0; i < points; i++) {
            double a = angle + i * Math.PI * 2 / points;
            center.getWorld().spawnParticle(Particle.DUST, center.clone().add(u.clone().multiply(Math.cos(a) * radius)).add(v.clone().multiply(Math.sin(a) * radius)), 1, 0, 0, 0, 0, dust);
        }
    }

    /**
     * Gojo's bare-handed fist punch: mace-smash sound, 3s stun, blind on crit.
     * A crit is triggered when Infinity is enabled (deflecting the punch).
     */
    private boolean fistImpact(Player p) {
        LivingEntity target = fx().target(p, 3.5);
        if (target == null) return false;
        boolean crit = isInfinity(p);
        double dmg = crit ? 12.0 : 5.0;
        fx().hit(target, dmg, p, false, false);
        // Mace smash sound on fist hit
        target.getWorld().playSound(target.getLocation(), "item.armor.equip_netherite", 1.6f, 0.4f);
        p.playSound(p.getLocation(), "entity.player.attack.strong", 0.8f, 1.1f);
        // Particles
        target.getWorld().spawnParticle(Particle.SWEEP_ATTACK, target.getLocation().add(0, 1, 0), 4, 0.4, 0.6, 0.4, 0);
        fx().dust(target.getLocation().add(0, 1, 0), Color.fromRGB(255, 255, 255), 1.5f, 10, 0.3);
        if (crit) {
            // 3 second stun + blindness
            target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 4));
            target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 1));
            target.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 40, 0));
            p.sendActionBar(net.kyori.adventure.text.Component.text("CRITICAL FIST!", net.kyori.adventure.text.format.NamedTextColor.GOLD));
            target.getWorld().spawnParticle(Particle.ENCHANT, target.getLocation().add(0, 1, 0), 30, 0.6, 1.2, 0.6, 0.15);
            target.getWorld().spawnParticle(Particle.REVERSE_PORTAL, target.getLocation().add(0, 1, 0), 20, 0.5, 0.9, 0.5, 0.1);
        }
        return true;
    }
}

