package dev.jjk.combat;

import dev.jjk.JJKPlugin;
import dev.jjk.character.CharacterType;
import dev.jjk.util.FX;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Base class for the five character kits. Registers skills with config-overridable
 * cost / cooldown and exposes them through a uniform key scheme.
 */
public abstract class CharacterController {

    protected final JJKPlugin plugin;
    private final Map<String, SkillDef> normalSkills = new HashMap<>();
    private final Map<String, SkillDef> ultimateSkills = new HashMap<>();

    // Per-player ultimate-form state (controllers are singletons shared by all
    // players of this character, so form must never be a controller-wide field).
    private final Set<UUID> ultimateForm = new HashSet<>();
    private final Map<UUID, org.bukkit.scheduler.BukkitTask> ultimateTimers = new HashMap<>();

    protected CharacterController(JJKPlugin plugin) {
        this.plugin = plugin;
    }

    public abstract CharacterType type();
    /** 4 distinct hotbar materials for normal form (distinct so vanilla cooldown overlays work per skill). */
    public abstract Material[] normalIcons();
    /** 4 distinct hotbar materials for ultimate form (defaults to the normal icons). */
    public Material[] ultimateIcons() { return normalIcons(); }

    /** Backward-compat alias used by the vanilla cooldown overlay. */
    public Material[] icons() { return normalIcons(); }

    // ========== Normal Form Registration ==========
    protected void regNormal(int slot, boolean shift, String name, String anim, double cost, long cdMs, Consumer<Player> exec) {
        regNormal(slot + (shift ? "s" : ""), name, anim, cost, cdMs, exec);
    }

    protected void regNormal(String key, String name, String anim, double cost, long cdMs, Consumer<Player> exec) {
        regNormal(key, name, anim, cost, cdMs, exec, false);
    }

    protected void regNormal(String key, String name, String anim, double cost, long cdMs,
                             Consumer<Player> exec, boolean leftClickVariant) {
        normalSkills.put(key, makeDef(null, key, name, anim, cost, cdMs, exec, leftClickVariant));
    }

    /** Left-click casts this shift variant of the held ability (e.g. Yuji Black Flash). */
    protected void regNormalLeft(int slot, String name, String anim, double cost, long cdMs, Consumer<Player> exec) {
        regNormal(slot + "s", name, anim, cost, cdMs, exec, true);
    }

    /** Builds a SkillDef while honouring per-skill cost/cooldown config overrides. */
    protected SkillDef makeDef(String group, String key, String name, String anim,
                               double cost, long cdMs, Consumer<Player> exec) {
        return makeDef(group, key, name, anim, cost, cdMs, exec, false);
    }

    protected SkillDef makeDef(String group, String key, String name, String anim,
                               double cost, long cdMs, Consumer<Player> exec, boolean leftClickVariant) {
        String path = "skills." + type().id() + (group == null ? "" : "." + group) + "." + key;
        double c = plugin.getConfig().getDouble(path + ".cost", cost);
        long cd = plugin.getConfig().getLong(path + ".cooldown-ms", cdMs);
        return new SkillDef(key, name, anim, c, cd, exec, leftClickVariant);
    }

    /** Backward-compat alias: legacy controllers register normal-form moves with reg(...). */
    protected void reg(int slot, boolean shift, String name, String anim, double cost, long cdMs, Consumer<Player> exec) {
        regNormal(slot, shift, name, anim, cost, cdMs, exec);
    }

    protected void reg(String key, String name, String anim, double cost, long cdMs, Consumer<Player> exec) {
        regNormal(key, name, anim, cost, cdMs, exec);
    }

    // ========== Ultimate Form Registration ==========
    protected void regUltimate(int slot, boolean shift, String name, String anim, double cost, long cdMs, Consumer<Player> exec) {
        regUltimate(slot + (shift ? "s" : ""), name, anim, cost, cdMs, exec);
    }

    protected void regUltimate(String key, String name, String anim, double cost, long cdMs, Consumer<Player> exec) {
        String path = "skills." + type().id() + ".ultimate." + key;
        double c = plugin.getConfig().getDouble(path + ".cost", cost);
        long cd = plugin.getConfig().getLong(path + ".cooldown-ms", cdMs);
        ultimateSkills.put(key, new SkillDef(key, name, anim, c, cd, exec));
    }

    private Map<String, SkillDef> skillsFor(Player p) {
        return (p != null && ultimateForm.contains(p.getUniqueId()) && !ultimateSkills.isEmpty())
                ? ultimateSkills : normalSkills;
    }

    // ========== Skill Access ==========
    /** Per-player lookup: returns the move bound to this hotbar slot in the player's current form. */
    public SkillDef skill(Player p, int slot, boolean shift) {
        Map<String, SkillDef> set = skillsFor(p);
        SkillDef def = set.get(slot + (shift ? "s" : ""));
        if (def == null && shift) def = set.get(String.valueOf(slot)); // fallback to base move
        return def;
    }

    /** Shared (non-weapon, non-form) skill lookup, e.g. Toji keys 5/6. */
    protected SkillDef shared(String key) { return normalSkills.get(key); }

    public SkillDef ultimate(Player p) {
        return isUltimateForm(p) ? ultimateSkills.getOrDefault("q", normalSkills.get("q")) : normalSkills.get("q");
    }
    public SkillDef ultimate() { return normalSkills.get("q"); }
    public SkillDef passive() { return normalSkills.get("f"); }
    public SkillDef domain() { return normalSkills.get("fs"); }
    public SkillDef domain(Player p) {
        return isUltimateForm(p) ? ultimateSkills.getOrDefault("fs", normalSkills.get("fs")) : normalSkills.get("fs");
    }
    public boolean isUltimateSkill(SkillDef def) { return ultimateSkills.containsValue(def); }

    // ========== Form Management ==========
    public boolean isUltimateForm(Player p) {
        return ultimateForm.contains(p.getUniqueId());
    }

    /** The hotbar icons matching the player's current form. */
    public Material[] activeIcons(Player p) {
        return isUltimateForm(p) ? ultimateIcons() : normalIcons();
    }

    public void enterUltimateForm(Player p) {
        if (ultimateSkills.isEmpty() || !ultimateForm.add(p.getUniqueId())) return;
        org.bukkit.scheduler.BukkitTask previous = ultimateTimers.remove(p.getUniqueId());
        if (previous != null) previous.cancel();
        updateHotbarIcons(p);
        onUltimateActivate(p);
        UUID id = p.getUniqueId();
        ultimateTimers.put(id, plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline() && isUltimateForm(p)) {
                exitUltimateForm(p);
                p.sendMessage(net.kyori.adventure.text.Component.text("Ultimate form expired.", net.kyori.adventure.text.format.NamedTextColor.GRAY));
            }
        }, ultimateDurationTicks()));
    }

    public void exitUltimateForm(Player p) {
        if (!ultimateForm.remove(p.getUniqueId())) return;
        org.bukkit.scheduler.BukkitTask timer = ultimateTimers.remove(p.getUniqueId());
        if (timer != null) timer.cancel();
        plugin.cooldowns().clear(p);
        updateHotbarIcons(p);
        onUltimateDeactivate(p);
    }

    protected long ultimateDurationTicks() { return 60L * 20L; }

    /** Redraw the hotbar icons (e.g. after Toji swaps cursed tools). */
    public final void refreshIcons(Player p) { updateHotbarIcons(p); }

    /** Optional notes group (e.g. "weapon.isoh") used to look up ability tooltips. */
    public String iconNoteGroup(Player p) { return null; }

    public static final int HOTBAR_SKILLS = 6;
    public static final int EXIT_SLOT = 8;

    private void updateHotbarIcons(Player p) {
        for (int move = 1; move <= HOTBAR_SKILLS; move++) {
            p.getInventory().setItem(move, hotbarIcon(p, move, skill(p, move, false)));
        }
    }

    /** Builds the icon for a move (1-6). It is placed in hotbar slot = move (slot 1 stays empty). */
    public org.bukkit.inventory.ItemStack hotbarIcon(Player p, int move, SkillDef def) {
        org.bukkit.inventory.ItemStack custom = customIcon(p, move, def);
        if (custom != null) return custom;
        if (def == null) return null;
        Material[] icons = activeIcons(p);
        Material mat = (move - 1) < icons.length ? icons[move - 1] : Material.BARRIER;
        return createAbilityIcon(p, mat, type(), String.valueOf(move), move + 1, "[" + (move + 1) + "] " + def.name, def);
    }

    /** Optional replacement icon for a given key (e.g. a locked follow-up). */
    protected org.bukkit.inventory.ItemStack customIcon(Player p, int key, SkillDef def) { return null; }

    private org.bukkit.inventory.ItemStack createAbilityIcon(Player p, Material mat, CharacterType type,
                                                             String moveKey, int hotbarKey, String name, SkillDef def) {
        var item = new org.bukkit.inventory.ItemStack(mat);
        var meta = item.getItemMeta();
        meta.displayName(net.kyori.adventure.text.Component.text(name, net.kyori.adventure.text.format.NamedTextColor.AQUA).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
        var lore = new java.util.ArrayList<net.kyori.adventure.text.Component>();
        if (def != null) {
            String resource = type.usesStamina() ? "Stamina" : "CE";
            lore.add(net.kyori.adventure.text.Component.text(resource + " cost: " + (int) def.cost + "  |  CD: " + (def.cooldownMs / 1000.0) + "s", net.kyori.adventure.text.format.NamedTextColor.GRAY).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
            lore.add(net.kyori.adventure.text.Component.text("Hotbar key " + hotbarKey + " (move " + moveKey + ")", net.kyori.adventure.text.format.NamedTextColor.DARK_GRAY).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
            for (net.kyori.adventure.text.Component line : plugin.notes().lines(type, iconNoteGroup(p), moveKey)) lore.add(line);
            if (def.leftClickVariant) {
                lore.add(net.kyori.adventure.text.Component.text("Left-Click also casts this variant.", net.kyori.adventure.text.format.NamedTextColor.YELLOW).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
            }
        }
        lore.add(net.kyori.adventure.text.Component.text("Unmovable ability icon", net.kyori.adventure.text.format.NamedTextColor.DARK_PURPLE).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(plugin.abilityKey(), org.bukkit.persistence.PersistentDataType.STRING, type.id() + ":" + moveKey);
        // Per-icon texture pack: only set item model if the server actually has a
        // resource pack defining jjk:<character>_<key>. Otherwise leave it null so
        // the item keeps its material texture and doesn't break.
        if (plugin.getConfig().getBoolean("transform.custom-item-models", false)) {
            org.bukkit.NamespacedKey model = org.bukkit.NamespacedKey.fromString("jjk:" + type.id() + "_" + moveKey);
            if (model != null) meta.setItemModel(model);
        }
        item.setItemMeta(meta);
        return item;
    }

    protected void onUltimateActivate(Player p) { }
    protected void onUltimateDeactivate(Player p) { }

    public void onTransform(Player p) { }
    public void onExit(Player p) {
        org.bukkit.scheduler.BukkitTask timer = ultimateTimers.remove(p.getUniqueId());
        if (timer != null) timer.cancel();
        ultimateForm.remove(p.getUniqueId());
    }

    /** Extra status text for the HUD (e.g. Infinity ON, current weapon). */
    public String status(Player p) { return ""; }

    /** Passive stance CE drain per second while toggled on. */
    public double stanceDrain(Player p) { return 0; }

    /** Called every 10 ticks for each transformed player of this character. */
    public void tick(Player p) { }

    /** Called right before a skill executes (after all checks passed). */
    public void onCast(Player p, SkillDef def) { }

    /** Called on left-click (arm swing) while transformed. @return true if a finisher/hit consumed the click. */
    public boolean onLeftClick(Player p) { return false; }

    protected FX fx() { return plugin.fx(); }

    protected void anim(Player p, String id) { plugin.bridge().play(p, id); }

    protected boolean mobilitySealed(Player p) {
        if (plugin.domains().mobilityLocked(p)) {
            plugin.energy().flash(p, "§cMobility sealed by Domain: Hometown!");
            return true;
        }
        return false;
    }
}
