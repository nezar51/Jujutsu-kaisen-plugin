package dev.jjk.util;

import dev.jjk.JJKPlugin;
import dev.jjk.character.CharacterType;
import org.bukkit.Material;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Locale;

/**
 * Generates a ready-to-upload resource-pack scaffold into
 * plugins/JJK/resourcepack/. It ships:
 *  - pack.mcmeta
 *  - one custom item model per ability icon (using a vanilla texture so it
 *    renders immediately; swap layer0 for jjk:item/... once you add PNGs)
 *  - sounds.json mapping every custom jjk.* event to a vanilla sound
 *  - README.txt explaining how to add real textures / .ogg files
 */
public final class ResourcePack {

    private final JJKPlugin plugin;

    public ResourcePack(JJKPlugin plugin) { this.plugin = plugin; }

    public void generate() {
        if (!plugin.getConfig().getBoolean("resource-pack.generate", true)) return;
        try {
            File root = new File(plugin.getDataFolder(), "resourcepack");
            File itemDir = new File(root, "assets/jjk/models/item");
            itemDir.mkdirs();

            write(new File(root, "pack.mcmeta"),
                    "{\n" +
                    "  \"pack\": {\n" +
                    "    \"pack_format\": 48,\n" +
                    "    \"supported_formats\": [48, 1000],\n" +
                    "    \"description\": \"JJK plugin abilities, models & sounds\"\n" +
                    "  }\n" +
                    "}\n");

            write(new File(root, "assets/jjk/sounds.json"), buildSoundsJson());

            for (CharacterType type : CharacterType.values()) {
                Material[] icons = plugin.controller(type).normalIcons();
                for (int i = 0; i < 4; i++) {
                    String texture = icons[i].name().toLowerCase(Locale.ROOT);
                    writeModel(itemDir, type.id() + "_" + (i + 1), texture);
                    writeModel(itemDir, type.id() + "_" + (i + 1) + "s", texture);
                }
            }

            write(new File(root, "README.txt"), README);
            plugin.getLogger().info("JJK resource pack scaffold written to plugins/JJK/resourcepack/");
        } catch (IOException e) {
            plugin.getLogger().warning("Could not generate JJK resource pack: " + e.getMessage());
        }
    }

    private void writeModel(File dir, String name, String texture) throws IOException {
        write(new File(dir, name + ".json"),
                "{\n" +
                "  \"parent\": \"minecraft:item/generated\",\n" +
                "  \"textures\": { \"layer0\": \"minecraft:item/" + texture + "\" }\n" +
                "}\n");
    }

    private String buildSoundsJson() {
        StringBuilder sb = new StringBuilder("{\n");
        java.util.Map<String, String> sounds = plugin.sounds().all();
        int i = 0;
        for (java.util.Map.Entry<String, String> e : sounds.entrySet()) {
            sb.append("  \"").append(e.getKey()).append("\": {\n")
              .append("    \"sounds\": [ { \"name\": \"").append(e.getValue())
              .append("\", \"volume\": 1.0, \"pitch\": 1.0 } ]\n")
              .append("  }");
            if (++i < sounds.size()) sb.append(',');
            sb.append('\n');
        }
        return sb.append("}\n").toString();
    }

    private static void write(File file, String content) throws IOException {
        Files.createDirectories(file.getParentFile().toPath());
        Files.writeString(file.toPath(), content, StandardCharsets.UTF_8);
    }

    private static final String README =
            "JJK RESOURCE PACK SCAFFOLD\n" +
            "==========================\n\n" +
            "This folder is a ready-to-upload pack for the JJK plugin.\n" +
            "Zip the CONTENTS of this folder (pack.mcmeta + assets/) and import it\n" +
            "as a server resource pack, or place it in your server's resourcepacks folder.\n\n" +
            "WHAT IS INCLUDED\n" +
            "- pack.mcmeta: compatible with 1.21.x (pack_format 48, wide supported range).\n" +
            "- assets/jjk/models/item/<character>_<key>.json: one model per ability icon.\n" +
            "  They currently use vanilla item textures (layer0) so they render immediately.\n" +
            "- assets/jjk/sounds.json: custom sound events (jjk.transform, jjk.dash, etc.)\n" +
            "  mapped to vanilla sounds, so they work before you add real audio.\n\n" +
            "ADDING YOUR OWN TEXTURES\n" +
            "1. Create your PNG art (usually 16x16) at:\n" +
            "   assets/jjk/textures/item/<name>.png\n" +
            "2. In the matching model JSON, change layer0 to \"jjk:item/<name>\".\n" +
            "3. In config.yml set transform.custom-item-models: true so the plugin\n" +
            "   applies jjk:<character>_<key> item models to the ability icons.\n\n" +
            "ADDING YOUR OWN SOUNDS\n" +
            "1. Drop .ogg files at assets/jjk/sounds/<name>.ogg\n" +
            "2. In assets/jjk/sounds.json, change a \"name\" value to \"jjk:<name>\".\n" +
            "3. In config.yml point the matching key to the custom name, e.g.:\n" +
            "   sounds:\n" +
            "     transform: \"jjk.transform\"\n\n" +
            "TIP: Keep the file/model names intact - the plugin references them directly.\n";
}
