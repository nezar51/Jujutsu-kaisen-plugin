package dev.jjk.skills;

import dev.jjk.JJKPlugin;
import dev.jjk.character.CharacterType;
import dev.jjk.combat.CharacterController;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Ryomen Sukuna — Shrine.
 * 1 Dismantle | Shift+1 Dismantle Net | 2 Cleave | 3 World Cutting Slash | 4 RCT
 * 5 Cursed Aura Burst | 6 Slash Dash | 7 Flame Sparks | 8 Shrine Mark
 * Q Divine Flame: Fuga | F Cursed Aura toggle | Shift+F Malevolent Shrine
 */
public final class SukunaController extends CharacterController {

    private static final Color CRIMSON = Color.fromRGB(220, 30, 30);
    private static final Color FLAME = Color.fromRGB(255, 140, 20);

    private final Set<UUID> aura = new HashSet<>();

    public SukunaController(JJKPlugin plugin) {
        super(plugin);

        // === NORMAL FORM — 4 moves (keys 1-4) ===
        regNormal(1, false, "Dismantle", "anim_slash", 30, 2000, this::dismantle);
        regNormalLeft(1, "Dismantle Net (Spiderweb)", "anim_ground_slam", 90, 12000, this::dismantleNet);
        regNormal(2, false, "Cleave", "anim_cleave_grab", 45, 6000, this::cleave);
        regNormal(3, false, "World Cutting Slash", "anim_wcs", 120, 20000, this::worldCuttingSlash);
        regNormal(4, false, "Reverse Cursed Technique", "anim_rct", 60, 15000, this::rct);

        // === ULTIMATE FORM — 4 moves (replaces normal moves) ===
        regUltimate(1, false, "Cursed Aura Burst", "anim_ground_slam", 35, 6000, this::auraBurst);
        regUltimate(2, false, "Slash Dash", "anim_slash", 30, 5000, this::slashDash);
        regUltimate(3, false, "Flame Sparks", "anim_fuga_bow", 40, 7000, this::flameSparks);
        regUltimate(4, false, "Shrine Mark", "anim_cleave_grab", 50, 20000, this::shrineMark);

        // === Techniques shared by both forms ===
        reg("q", "Divine Flame: Fuga (Open)", "anim_fuga_bow", 150, 25000, this::fuga);
        reg("f", "Cursed Aura (Toggle)", "anim_ground_slam", 0, 500, this::toggleAura);
        reg("fs", "Domain Expansion: Malevolent Shrine", "anim_sukuna_domain", 300, 60000, this::malevolentShrine);
    }

    @Override public CharacterType type() { return CharacterType.SUKUNA; }

    @Override public Material[] normalIcons() {
        return new Material[]{Material.IRON_SWORD, Material.COBWEB, Material.GHAST_TEAR, Material.NETHERITE_SWORD};
    }

    @Override public Material[] ultimateIcons() {
        return new Material[]{Material.GLOWSTONE_DUST, Material.FEATHER, Material.FIRE_CHARGE, Material.QUARTZ};
    }

    private void toggleAura(Player p) {
        boolean on = !aura.contains(p.getUniqueId());
        if (on) aura.add(p.getUniqueId()); else aura.remove(p.getUniqueId());
        p.sendMessage(net.kyori.adventure.text.Component.text("Dark cursed energy aura " + (on ? "surges (Strength I)" : "fades"),
                net.kyori.adventure.text.format.NamedTextColor.DARK_RED));
    }

    @Override public String status(Player p) { return aura.contains(p.getUniqueId()) ? "§4Aura ON" : ""; }

    @Override public double stanceDrain(Player p) {
        return aura.contains(p.getUniqueId()) ? plugin.getConfig().getDouble("energy.stance-drain.sukuna", 3) : 0;
    }

    @Override public void tick(Player p) {
        // Sukuna body markings + dark aura.
        Location c = p.getLocation().add(0, 1, 0);
        fx().dust(c, Color.fromRGB(60, 0, 10), 1f, 3, 0.35);
        if (aura.contains(p.getUniqueId())) {
            if (plugin.energy().get(p) <= 0) { aura.remove(p.getUniqueId()); return; }
            p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 30, 0, true, false));
            p.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, c, 2, 0.3, 0.5, 0.3, 0.01);
        }
    }

    @Override public void onExit(Player p) { aura.remove(p.getUniqueId()); }

    // ------------------------------------------------------------------
    private void dismantle(Player p) {
        Location start = p.getEyeLocation().add(p.getEyeLocation().getDirection());
        fx().slashArc(p, start, p.getEyeLocation().getDirection(), 18, 6.0, CRIMSON);
        p.playSound(p.getLocation(), "entity.player.attack.sweep", 1f, 1.3f);
    }

    private void dismantleNet(Player p) {
        Location c = p.getLocation();
        p.getWorld().playSound(c, "entity.generic.explode", 1.2f, 0.6f);
        p.getWorld().spawnParticle(Particle.EXPLOSION, c, 2);
        // Intersecting slash lines across a 10-block radius.
        for (int i = 0; i < 6; i++) {
            double a = Math.PI * i / 6;
            Vector dir = new Vector(Math.cos(a), 0, Math.sin(a));
            fx().line(c.clone().add(dir.clone().multiply(-10)).add(new Vector(0, 0.4, 0)), dir, 20, CRIMSON, 0.5);
            fx().cutSoftLine(p, c.clone().add(dir.clone().multiply(-10)), dir, 20);
        }
        fx().aoe(c, 10, 10.0, p, false, false, le ->
                fx().knock(le, le.getLocation().toVector().subtract(c.toVector()).setY(0.4), 1.4));
        if (plugin.griefing()) {
            fx().deleteSphere(p, c.clone().subtract(0, 1, 0), 3.5);
        }
        fx().expandingRings(c, CRIMSON, 10);
    }

    private void cleave(Player p) {
        LivingEntity target = fx().target(p, 10);
        if (target == null) {
            plugin.energy().flash(p, "§cNo target for Cleave");
            plugin.cooldowns().reset(p, "sukuna:2");
            return;
        }
        if (mobilitySealed(p)) return;
        Location dest = target.getLocation().add(target.getLocation().getDirection().multiply(-1));
        dest.setDirection(target.getLocation().toVector().subtract(dest.toVector()));
        p.teleport(dest);
        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 4));
        new BukkitRunnable() {
            int hits = 0;
            @Override public void run() {
                if (!target.isValid() || hits >= 5 || !p.isOnline()) { cancel(); return; }
                hits++;
                // Scales with enemy armor and missing HP.
                double armor = 0;
                var attr = target.getAttribute(Attribute.ARMOR);
                if (attr != null) armor = attr.getValue();
                double maxHp = target.getAttribute(Attribute.MAX_HEALTH) != null
                        ? target.getAttribute(Attribute.MAX_HEALTH).getValue() : 20;
                double dmg = 3.0 + armor * 0.25 + (maxHp - target.getHealth()) * 0.06;
                fx().hit(target, dmg, p, false, false);
                fx().dust(target.getLocation().add(0, 1, 0), CRIMSON, 1.2f, 6, 0.35);
                target.getWorld().spawnParticle(Particle.SWEEP_ATTACK, target.getLocation().add(0, 1, 0), 2, 0.3, 0.4, 0.3, 0);
                p.playSound(p.getLocation(), "entity.player.attack.sweep", 0.8f, 1.4f);
            }
        }.runTaskTimer(plugin, 2L, 4L);
    }

    private void worldCuttingSlash(Player p) {
        p.sendMessage(net.kyori.adventure.text.Component.text("「Scale of the Dragon. Recoil. Twin Meteors.」", net.kyori.adventure.text.format.NamedTextColor.DARK_RED));
        p.playSound(p.getLocation(), "entity.warden.heartbeat", 1f, 0.7f);
        new BukkitRunnable() {
            @Override public void run() {
                if (!p.isOnline()) return;
                Location start = p.getEyeLocation();
                Vector dir = start.getDirection();
                // Giant unblockable spatial slash: bypasses Infinity, shields and armor.
                Location cur = start.clone();
                Set<UUID> hit = new HashSet<>();
                for (double t = 0; t < 30; t += 0.6) {
                    fx().dust(cur, Color.fromRGB(255, 255, 255), 1.6f, 2, 0.1);
                    fx().dust(cur, CRIMSON, 1.2f, 2, 0.4);
                    for (Entity e : cur.getWorld().getNearbyEntities(cur, 2.5, 2.5, 2.5)) {
                        if (!(e instanceof LivingEntity le) || e.equals(p) || hit.contains(e.getUniqueId())) continue;
                        if (plugin.summons().isOwnedSummon(p, e)) continue;
                        hit.add(e.getUniqueId());
                        fx().hit(le, 16.0, p, true, true);
                        fx().knock(le, dir.clone().setY(0.3), 1.8);
                    }
                    fx().cutSoftLine(p, cur, dir, 0.8);
                    cur.add(dir.clone().multiply(0.6));
                }
                p.getWorld().playSound(p.getLocation(), "entity.warden.sonic_boom", 1.5f, 0.6f);
                p.getWorld().spawnParticle(Particle.SONIC_BOOM, start.clone().add(dir.multiply(4)), 1);
            }
        }.runTaskLater(plugin, 15L);
    }

    private void rct(Player p) {
        new BukkitRunnable() {
            int ticks = 0;
            @Override public void run() {
                if (!p.isOnline() || ticks++ >= 10) { cancel(); return; }
                p.setHealth(Math.min(p.getAttribute(Attribute.MAX_HEALTH).getValue(), p.getHealth() + 2));
                p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation().add(0, 1, 0), 8, 0.3, 0.5, 0.3, 0.02);
                p.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, p.getLocation().add(0, 1, 0), 4, 0.3, 0.5, 0.3, 0.01);
            }
        }.runTaskTimer(plugin, 0L, 4L);
        clearDebuffs(p);
        p.playSound(p.getLocation(), "block.beacon.ambient", 1f, 1.6f);
    }

    private void clearDebuffs(Player p) {
        for (PotionEffectType type : new PotionEffectType[]{PotionEffectType.POISON, PotionEffectType.WITHER,
                PotionEffectType.SLOWNESS, PotionEffectType.WEAKNESS, PotionEffectType.BLINDNESS,
                PotionEffectType.NAUSEA, PotionEffectType.LEVITATION, PotionEffectType.HUNGER}) {
            p.removePotionEffect(type);
        }
    }

    private void auraBurst(Player p) {
        Location c = p.getLocation().add(0, 1, 0);
        fx().aoe(c, 5, 5.0, p, false, false, le -> {
            le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 1));
            fx().knock(le, le.getLocation().toVector().subtract(c.toVector()), 1.0);
        });
        fx().expandingRings(c, Color.fromRGB(80, 0, 20), 5);
        p.getWorld().playSound(c, "entity.warden.roar", 0.7f, 1.5f);
    }

    private void slashDash(Player p) {
        if (mobilitySealed(p)) return;
        Vector dir = p.getEyeLocation().getDirection().setY(0).normalize();
        Location cur = p.getLocation();
        Set<UUID> hit = new HashSet<>();
        for (int i = 0; i < 8; i++) {
            cur.add(dir);
            if (!cur.getBlock().isPassable()) break;
            for (Entity e : cur.getWorld().getNearbyEntities(cur, 1.5, 1.5, 1.5)) {
                if (e instanceof LivingEntity le && !e.equals(p) && !hit.contains(e.getUniqueId())
                        && !plugin.summons().isOwnedSummon(p, e)) {
                    hit.add(e.getUniqueId());
                    fx().hit(le, 6.0, p, false, false);
                    fx().dust(le.getLocation().add(0, 1, 0), CRIMSON, 1.2f, 5, 0.3);
                }
            }
        }
        cur.setDirection(dir);
        p.teleport(cur);
        fx().line(p.getLocation().add(0, 1, 0), dir.multiply(-1), 8, CRIMSON, 0.5);
        p.playSound(p.getLocation(), "entity.player.attack.sweep", 1f, 0.9f);
    }

    private void flameSparks(Player p) {
        Vector base = p.getEyeLocation().getDirection();
        for (int i = -2; i <= 2; i++) {
            Vector dir = base.clone().rotateAroundY(Math.toRadians(i * 12));
            ItemDisplay spark = fx().itemDisplay(p.getEyeLocation().add(dir), Material.FIRE_CHARGE, 0.5f);
            fx().register(p, spark);
            fx().orbProjectile(p, spark, dir, 1.4, 30, 0.9,
                    le -> {
                        fx().hit(le, 3.0, p, false, false);
                        le.setFireTicks(80);
                        le.getWorld().spawnParticle(Particle.FLAME, le.getLocation(), 15, 0.3, 0.5, 0.3, 0.05);
                    },
                    () -> spark.getWorld().spawnParticle(Particle.FLAME, spark.getLocation(), 10, 0.2, 0.2, 0.2, 0.03),
                    d -> d.getWorld().spawnParticle(Particle.FLAME, d.getLocation(), 2, 0.05, 0.05, 0.05, 0.01));
        }
        p.playSound(p.getLocation(), "entity.blaze.shoot", 1f, 1.2f);
    }

    private void shrineMark(Player p) {
        p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 160, 0));
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 160, 0));
        fx().dust(p.getLocation().add(0, 1, 0), Color.BLACK, 1.4f, 20, 0.4);
        p.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, p.getLocation().add(0, 1, 0), 15, 0.4, 0.8, 0.4, 0.02);
        p.playSound(p.getLocation(), "entity.warden.heartbeat", 1f, 1.2f);
    }

    private void fuga(Player p) {
        p.sendMessage(net.kyori.adventure.text.Component.text("「Open.」 — Divine Flame draws...", net.kyori.adventure.text.format.NamedTextColor.GOLD));
        p.playSound(p.getLocation(), "item.crossbow.loading_start", 1f, 0.6f);
        new BukkitRunnable() {
            @Override public void run() {
                if (!p.isOnline()) return;
                ItemDisplay arrow = fx().itemDisplay(p.getEyeLocation().add(p.getEyeLocation().getDirection()), Material.ARROW, 1.2f);
                fx().register(p, arrow);
                p.playSound(p.getLocation(), "item.crossbow.shoot", 1.5f, 0.5f);
                Runnable erupt = () -> {
                    Location c = arrow.getLocation();
                    // Towering pillar of inferno.
                    for (double y = 0; y < 12; y += 0.5) {
                        Location pt = c.clone().add(0, y, 0);
                        c.getWorld().spawnParticle(Particle.FLAME, pt, 12, 0.8, 0.2, 0.8, 0.04);
                        if (y < 3) c.getWorld().spawnParticle(Particle.LAVA, pt, 3, 0.5, 0.2, 0.5, 0);
                    }
                    fx().aoe(c.clone().add(0, 3, 0), 4.5, 14.0, p, false, true, le -> le.setFireTicks(120));
                    c.getWorld().playSound(c, "entity.generic.explode", 2f, 0.5f);
                    c.getWorld().playSound(c, "entity.blaze.death", 1.5f, 0.5f);
                    fx().expandingRings(c, FLAME, 5);
                    if (plugin.griefing()) {
                        for (int i = 0; i < 8; i++) {
                            Location fl = c.clone().add((Math.random() - 0.5) * 6, 0, (Math.random() - 0.5) * 6);
                            var b = fl.getBlock();
                            if (b.getType().isAir() && !b.getRelative(org.bukkit.block.BlockFace.DOWN).getType().isAir()
                                    && fx().canBreak(p, b)) {
                                b.setType(Material.FIRE, false);
                            }
                        }
                    }
                };
                fx().orbProjectile(p, arrow, p.getEyeLocation().getDirection(), 2.2, 40, 1.2,
                        le -> erupt.run(), erupt,
                        d -> d.getWorld().spawnParticle(Particle.FLAME, d.getLocation(), 4, 0.1, 0.1, 0.1, 0.02));
            }
        }.runTaskLater(plugin, 15L);
    }

    private void malevolentShrine(Player p) {
        // 3D shrine structure behind Sukuna (BetterModel or BlockDisplay fallback).
        Location behind = p.getLocation().subtract(p.getLocation().getDirection().setY(0).normalize().multiply(4));
        Entity model = plugin.bridge().spawnModel(behind, "sukuna_shrine", "anim_sukuna_domain");
        if (model == null) {
            var skull = fx().blockDisplay(behind.clone().add(0, 4, 0), Material.WITHER_SKELETON_SKULL, 2.5f);
            var base = fx().blockDisplay(behind.clone().add(0, 1, 0), Material.BONE_BLOCK, 2.0f);
            var base2 = fx().blockDisplay(behind.clone().add(0, 2.5, 0), Material.RED_NETHER_BRICKS, 1.6f);
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (skull.isValid()) skull.remove();
                if (base.isValid()) base.remove();
                if (base2.isValid()) base2.remove();
            }, plugin.getConfig().getLong("domains.duration-seconds", 10) * 20L);
        }
        plugin.domains().start(p, CharacterType.SUKUNA);
    }
}
