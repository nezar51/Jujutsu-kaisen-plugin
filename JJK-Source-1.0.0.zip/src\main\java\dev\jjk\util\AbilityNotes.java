package dev.jjk.util;

import dev.jjk.JJKPlugin;
import dev.jjk.character.CharacterType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;

import java.util.ArrayList;
import java.util.List;

/** Resolves the short "what / how / variant" tooltip for each ability icon. */
public final class AbilityNotes {

    private final JJKPlugin plugin;

    public AbilityNotes(JJKPlugin plugin) { this.plugin = plugin; }

    /** Lore lines for an ability. Falls back from a group-specific note to the character note. */
    public List<Component> lines(CharacterType type, String group, String key) {
        String value = null;
        if (group != null && !group.isEmpty()) {
            value = plugin.messages().raw("notes." + type.id() + "." + group + "." + key);
        }
        if (value == null) value = plugin.messages().raw("notes." + type.id() + "." + key);

        List<String> parts = new ArrayList<>();
        if (value == null || value.isBlank()) {
            parts.add("&7Press " + key + " or right-click the icon to cast.");
            parts.add("&8Shift+" + key + " = variant (if available).");
        } else {
            for (String part : value.split("\\|")) {
                if (!part.isBlank()) parts.add(part.trim());
            }
        }
        List<Component> out = new ArrayList<>();
        out.add(Component.text(" ", NamedTextColor.DARK_GRAY));
        for (String part : parts) {
            out.add(plugin.messages().component(part)
                    .decoration(TextDecoration.ITALIC, false));
        }
        return out;
    }
}
