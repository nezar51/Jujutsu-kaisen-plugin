package dev.jjk.combat;

import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Millisecond-precision cooldown tracking: Map<UUID, Map<String, Long>>.
 */
public final class CooldownManager {

    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();

    public long remaining(Player p, String key) {
        Map<String, Long> map = cooldowns.get(p.getUniqueId());
        if (map == null) return 0;
        Long until = map.get(key);
        if (until == null) return 0;
        long rem = until - System.currentTimeMillis();
        return Math.max(0, rem);
    }

    public void set(Player p, String key, long durationMs) {
        if (durationMs <= 0) return;
        cooldowns.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>())
                .put(key, System.currentTimeMillis() + durationMs);
    }

    public void clear(Player p) { cooldowns.remove(p.getUniqueId()); }

    /** Refunds a cooldown (e.g. a skill found no valid target). */
    public void reset(Player p, String key) {
        Map<String, Long> map = cooldowns.get(p.getUniqueId());
        if (map != null) map.remove(key);
    }
}
