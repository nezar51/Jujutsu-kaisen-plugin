$ErrorActionPreference = 'Stop'
$jdk = 'C:\Users\Amugos\AppData\Local\Programs\Eclipse Adoptium\jdk-21.0.11.10-hotspot'
$javac = "$jdk\bin\javac.exe"
$jar = "$jdk\bin\jar.exe"

# Build classpath from local maven repo (compile-scope deps)
$m2 = "$env:USERPROFILE\.m2\repository"
$deps = @(
  "$m2\io\papermc\paper\paper-api\1.21.11-R0.1-SNAPSHOT\paper-api-1.21.11-R0.1-SNAPSHOT.jar",
  "$m2\net\kyori\adventure-api\4.26.1\adventure-api-4.26.1.jar",
  "$m2\net\kyori\adventure-key\4.26.1\adventure-key-4.26.1.jar",
  "$m2\net\kyori\adventure-text-minimessage\4.26.1\adventure-text-minimessage-4.26.1.jar",
  "$m2\net\kyori\adventure-text-serializer-gson\4.26.1\adventure-text-serializer-gson-4.26.1.jar",
  "$m2\net\kyori\adventure-text-serializer-legacy\4.26.1\adventure-text-serializer-legacy-4.26.1.jar",
  "$m2\net\kyori\adventure-text-serializer-json\4.26.1\adventure-text-serializer-json-4.26.1.jar",
  "$m2\net\kyori\adventure-text-serializer-plain\4.26.1\adventure-text-serializer-plain-4.26.1.jar",
  "$m2\net\kyori\adventure-text-serializer-commons\4.26.1\adventure-text-serializer-commons-4.26.1.jar",
  "$m2\net\kyori\adventure-text-logger-slf4j\4.26.1\adventure-text-logger-slf4j-4.26.1.jar",
  "$m2\net\kyori\examination-api\1.3.0\examination-api-1.3.0.jar",
  "$m2\net\kyori\examination-string\1.3.0\examination-string-1.3.0.jar",
  "$m2\org\joml\joml\1.10.8\joml-1.10.8.jar",
  "$m2\org\checkerframework\checker-qual\3.49.2\checker-qual-3.49.2.jar",
  "$m2\org\jetbrains\annotations\26.0.2-1\annotations-26.0.2-1.jar",
  "$m2\com\google\guava\guava\33.3.1-jre\guava-33.3.1-jre.jar",
  "$m2\com\google\errorprone\error_prone_annotations\2.28.0\error_prone_annotations-2.28.0.jar",
  "$m2\com\google\j2objc\j2objc-annotations\3.0.0\j2objc-annotations-3.0.0.jar",
  "$m2\com\google\auto\service\auto-service-annotations\1.1.1\auto-service-annotations-1.1.1.jar",
  "$m2\com\google\guava\failureaccess\1.0.2\failureaccess-1.0.2.jar",
  "$m2\com\google\guava\listenablefuture\9999.0-empty-to-avoid-conflict-with-guava\listenablefuture-9999.0-empty-to-avoid-conflict-with-guava.jar",
  "$m2\net\md-5\bungeecord-chat\1.21-R0.2-deprecated+build.21\bungeecord-chat-1.21-R0.2-deprecated+build.21.jar"
)
$cp = ($deps | Where-Object { Test-Path $_ }) -join ';'
Write-Host "Classpath jars: $(($cp -split ';').Count)"

# Collect sources
$sources = Get-ChildItem -Path src/main/java -Recurse -Filter *.java | ForEach-Object { $_.FullName }
Write-Host "Source files: $($sources.Count)"

# Clean & compile
Remove-Item -Recurse -Force target/classes -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path target/classes -Force | Out-Null
& $javac -nowarn -encoding UTF-8 -cp $cp -d target/classes @sources
if ($LASTEXITCODE -ne 0) { Write-Error "Compilation FAILED"; exit 1 }
Write-Host "Compilation OK"

# Package: classes + resources
Copy-Item -Path src/main/resources/* -Destination target/classes -Recurse -Force
$version = "1.0.beta.6"
$artifact = "target/JJK-$version.jar"
& $jar --create --file $artifact -C target/classes .
Write-Host "Built $artifact"
Get-Item $artifact | Select-Object Name, Length, LastWriteTime | Format-List
