package dev.jjk.character;

import dev.jjk.JJKPlugin;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Base64;

/**
 * Crash-safe backup of a player's exact survival inventory, armor, offhand and XP.
 * Held in memory AND written to plugins/JJK/backups/<uuid>.yml on transform.
 */
public final class InventoryBackup {

    private final ItemStack[] contents; // full 41-slot contents incl. armor + offhand
    private final int level;
    private final float exp;
    private final int heldSlot;
    private final long timestamp;

    private InventoryBackup(ItemStack[] contents, int level, float exp, int heldSlot) {
        this.contents = contents;
        this.level = level;
        this.exp = exp;
        this.heldSlot = heldSlot;
        this.timestamp = System.currentTimeMillis();
    }

    public static InventoryBackup capture(Player p) {
        return new InventoryBackup(
                p.getInventory().getContents().clone(),
                p.getLevel(), p.getExp(),
                p.getInventory().getHeldItemSlot());
    }

    public void restore(Player p) {
        p.getInventory().setContents(contents);
        p.setLevel(level);
        p.setExp(exp);
        p.getInventory().setHeldItemSlot(Math.max(0, Math.min(8, heldSlot)));
        p.updateInventory();
    }

    public void writeToDisk(JJKPlugin plugin, Player p) {
        try {
            File f = file(plugin, p);
            YamlConfiguration yml = new YamlConfiguration();
            yml.set("uuid", p.getUniqueId().toString());
            yml.set("name", p.getName());
            yml.set("timestamp", timestamp);
            yml.set("level", level);
            yml.set("exp", (double) exp);
            yml.set("held-slot", heldSlot);
            yml.set("items-base64", serialize(contents));
            yml.save(f);
        } catch (Exception e) {
            plugin.getLogger().severe("FAILED to write inventory backup for " + p.getName() + ": " + e.getMessage());
        }
    }

    public static InventoryBackup readFromDisk(JJKPlugin plugin, Player p) {
        File f = file(plugin, p);
        if (!f.exists()) return null;
        try {
            YamlConfiguration yml = YamlConfiguration.loadConfiguration(f);
            ItemStack[] items = deserialize(yml.getString("items-base64", ""));
            return new InventoryBackup(items,
                    yml.getInt("level"),
                    (float) yml.getDouble("exp"),
                    yml.getInt("held-slot"));
        } catch (Exception e) {
            plugin.getLogger().severe("FAILED to read inventory backup for " + p.getName() + ": " + e.getMessage());
            return null;
        }
    }

    public static void deleteFromDisk(JJKPlugin plugin, Player p) {
        File f = file(plugin, p);
        if (f.exists() && !f.delete()) f.deleteOnExit();
    }

    public static boolean existsOnDisk(JJKPlugin plugin, Player p) {
        return file(plugin, p).exists();
    }

    private static File file(JJKPlugin plugin, Player p) {
        return new File(plugin.getDataFolder(), "backups/" + p.getUniqueId() + ".yml");
    }

    private static String serialize(ItemStack[] items) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (BukkitObjectOutputStream oos = new BukkitObjectOutputStream(bos)) {
            oos.writeInt(items.length);
            for (ItemStack item : items) oos.writeObject(item);
        }
        return Base64.getEncoder().encodeToString(bos.toByteArray());
    }

    private static ItemStack[] deserialize(String data) throws Exception {
        ByteArrayInputStream bis = new ByteArrayInputStream(Base64.getDecoder().decode(data));
        try (BukkitObjectInputStream ois = new BukkitObjectInputStream(bis)) {
            ItemStack[] items = new ItemStack[ois.readInt()];
            for (int i = 0; i < items.length; i++) items[i] = (ItemStack) ois.readObject();
            return items;
        }
    }
}
