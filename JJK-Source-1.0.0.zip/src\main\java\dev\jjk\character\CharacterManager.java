package dev.jjk.character;

import dev.jjk.JJKPlugin;
import dev.jjk.combat.CharacterController;
import dev.jjk.combat.SkillDef;
import dev.jjk.util.Sounds;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.persistence.PersistentDataType;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Handles entering / exiting character mode:
 *  - safe inventory backup (memory + YAML)
 *  - visual / stat swap + BetterModel rig
 *  - locked hotbar (slots 1-8 abilities, slot 9 exit)
 *  - crash recovery, death & quit safety
 */
public final class CharacterManager implements Listener {

    private final JJKPlugin plugin;
    private final Map<UUID, CharacterType> active = new HashMap<>();
    private final Map<UUID, InventoryBackup> backups = new HashMap<>();
    private final Map<UUID, CharacterType> pendingRespawnRestore = new HashMap<>();
    private final java.util.Set<UUID> switching = new java.util.HashSet<>();

    public CharacterManager(JJKPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isTransformed(Player p) { return active.containsKey(p.getUniqueId()); }

    /** True while a transform/exit is mutating the inventory (suppress synthetic input events). */
    public boolean isSwitching(Player p) { return switching.contains(p.getUniqueId()); }
    public CharacterType type(Player p) { return active.get(p.getUniqueId()); }

    public CharacterController controller(Player p) {
        CharacterType t = type(p);
        return t == null ? null : plugin.controller(t);
    }

    // ------------------------------------------------------------------
    // Transform
    // ------------------------------------------------------------------
    public void transform(Player p, CharacterType type) {
        if (!p.hasPermission("jjk.use")) {
            p.sendMessage(Component.text("You lack permission to use JJK.", NamedTextColor.RED));
            return;
        }
        switching.add(p.getUniqueId());
        try {
            doTransform(p, type);
        } finally {
            switching.remove(p.getUniqueId());
        }
    }

    private void doTransform(Player p, CharacterType type) {
        CharacterType current = type(p);
        if (current == type) {
            p.sendMessage(Component.text("You are already " + type.displayName() + ".", NamedTextColor.YELLOW));
            return;
        }
        if (current == null) {
            // 1. Safe backup BEFORE touching anything.
            InventoryBackup backup = InventoryBackup.capture(p);
            backups.put(p.getUniqueId(), backup);
            if (plugin.getConfig().getBoolean("transform.async-backup-write", true)) {
                plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> backup.writeToDisk(plugin, p));
            } else {
                backup.writeToDisk(plugin, p);
            }
            p.getInventory().clear();
        } else {
            plugin.controller(current).onExit(p);
            plugin.bridge().removeModel(p);
            plugin.domains().endFor(p);
            plugin.summons().despawnAll(p);
            plugin.fx().dispel(p);
        }
        apply(p, type);
    }

    private void apply(Player p, CharacterType type) {
        active.put(p.getUniqueId(), type);
        CharacterController ctrl = plugin.controller(type);

        // Hotbar: keys 1-6 ability icons (current form/weapon), key 9 exit button.
        for (int i = 0; i < 9; i++) p.getInventory().setItem(i, null);
        // Slot 1 (index 0) is deliberately left empty so key 1 is a harmless buffer.
        for (int move = 1; move <= CharacterController.HOTBAR_SKILLS; move++) {
            p.getInventory().setItem(move, ctrl.hotbarIcon(p, move, ctrl.skill(p, move, false)));
        }
        p.getInventory().setItem(CharacterController.EXIT_SLOT, exitIcon());
        p.getInventory().setHeldItemSlot(0);

        // Character outfit visuals (dyed leather, tagged so they never drop).
        if (plugin.getConfig().getBoolean("transform.character-armor-visuals", true)) {
            Color color = outfitColor(type);
            p.getInventory().setHelmet(visualArmor(Material.LEATHER_HELMET, color, type));
            p.getInventory().setChestplate(visualArmor(Material.LEATHER_CHESTPLATE, color, type));
            p.getInventory().setLeggings(visualArmor(Material.LEATHER_LEGGINGS, color, type));
            p.getInventory().setBoots(visualArmor(Material.LEATHER_BOOTS, color, type));
        }

        plugin.energy().set(p, plugin.energy().max(p));
        plugin.bridge().applyModel(p, type);
        ctrl.onTransform(p);
        plugin.energy().showHud(p);

        p.showTitle(Title.title(
                Component.text(type.displayName(), NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD),
                Component.text("Domain Expansion ready — Shift+F", NamedTextColor.GRAY),
                Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(1500), Duration.ofMillis(400))));
        plugin.sounds().play(p, Sounds.TRANSFORM, 1f, 0.8f);
        p.sendMessage(Component.text("You are now " + type.displayName() + ". 1-6 cast (Shift = variant), Q ultimate, Shift+Q dash, F passive, Shift+F domain, 9 exit.", NamedTextColor.AQUA));
        p.sendMessage(Component.text("Type /jjk help for your full moveset and keybinds.", NamedTextColor.GRAY));
    }

    // ------------------------------------------------------------------
    // Exit
    // ------------------------------------------------------------------
    public void exit(Player p, String reason) {
        switching.add(p.getUniqueId());
        try {
            doExit(p, reason);
        } finally {
            switching.remove(p.getUniqueId());
        }
    }

    private void doExit(Player p, String reason) {
        CharacterType type = active.remove(p.getUniqueId());
        if (type == null) return;
        CharacterController ctrl = plugin.controller(type);
        ctrl.onExit(p);
        plugin.bridge().removeModel(p);
        plugin.domains().endFor(p);
        plugin.summons().despawnAll(p);
        plugin.fx().dispel(p);
        plugin.energy().hideHud(p);
        plugin.energy().clear(p);
        plugin.cooldowns().clear(p);

        // Strip ability icons / visual armor, then restore the exact backup.
        clearJJKItems(p);
        InventoryBackup backup = backups.remove(p.getUniqueId());
        if (backup == null) backup = InventoryBackup.readFromDisk(plugin, p);
        if (backup != null) {
            backup.restore(p);
            InventoryBackup.deleteFromDisk(plugin, p);
        } else {
            p.getInventory().clear();
            plugin.getLogger().warning("No inventory backup found for " + p.getName() + " on exit!");
        }
        plugin.sounds().play(p, Sounds.EXIT, 1f, 0.8f);
        if (reason != null) p.sendMessage(Component.text("Transformation ended: " + reason + ". Inventory restored.", NamedTextColor.YELLOW));
    }

    public void exitAll(String reason) {
        for (UUID id : new ArrayList<>(active.keySet())) {
            Player p = plugin.getServer().getPlayer(id);
            if (p != null) exit(p, reason);
        }
    }

    private void clearJJKItems(Player p) {
        ItemStack[] contents = p.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            if (isJJKItem(contents[i])) contents[i] = null;
        }
        p.getInventory().setContents(contents);
    }

    public boolean isJJKItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        var pdc = item.getItemMeta().getPersistentDataContainer();
        return pdc.has(plugin.abilityKey(), PersistentDataType.STRING)
                || pdc.has(plugin.visualKey(), PersistentDataType.STRING);
    }

    public boolean isAbilityItem(ItemStack item) {
        return item != null && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(plugin.abilityKey(), PersistentDataType.STRING);
    }

    // ------------------------------------------------------------------
    // Icons
    // ------------------------------------------------------------------
    private ItemStack abilityIcon(Player p, Material mat, CharacterType type, String key, String name, SkillDef def) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name, NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        if (def != null) {
            String resource = type.usesStamina() ? "Stamina" : "CE";
            lore.add(Component.text(resource + " cost: " + (int) def.cost + "  |  CD: " + (def.cooldownMs / 1000.0) + "s", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
            CharacterController ctrl = plugin.controller(type);
            for (Component line : plugin.notes().lines(type, ctrl == null ? null : ctrl.iconNoteGroup(p), key)) lore.add(line);
            if (def.leftClickVariant) {
                lore.add(Component.text("Left-Click also casts this variant.", NamedTextColor.YELLOW).decoration(TextDecoration.ITALIC, false));
            }
        }
        lore.add(Component.text("Unmovable ability icon", NamedTextColor.DARK_PURPLE).decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(plugin.abilityKey(), PersistentDataType.STRING, type.id() + ":" + key);
        if (plugin.getConfig().getBoolean("transform.custom-item-models", false)) {
            NamespacedKey model = NamespacedKey.fromString("jjk:" + type.id() + "_" + key);
            if (model != null) meta.setItemModel(model);
        }
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack exitIcon() {
        ItemStack item = new ItemStack(Material.BARRIER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("[9] Exit Transformation", NamedTextColor.RED).decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Press 9 or type /jjk leave", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.text("Type /jjk help for all controls", NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false)));
        meta.getPersistentDataContainer().set(plugin.abilityKey(), PersistentDataType.STRING, "exit");
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack visualArmor(Material mat, Color color, CharacterType type) {
        ItemStack item = new ItemStack(mat);
        LeatherArmorMeta meta = (LeatherArmorMeta) item.getItemMeta();
        meta.setColor(color);
        meta.displayName(Component.text(type.displayName() + " Outfit", NamedTextColor.LIGHT_PURPLE).decoration(TextDecoration.ITALIC, false));
        meta.getPersistentDataContainer().set(plugin.visualKey(), PersistentDataType.STRING, type.id());
        meta.setUnbreakable(true);
        item.setItemMeta(meta);
        return item;
    }

    private Color outfitColor(CharacterType type) {
        return switch (type) {
            case GOJO -> Color.fromRGB(20, 20, 30);       // black uniform, white hair
            case SUKUNA -> Color.fromRGB(120, 20, 30);    // dark crimson markings
            case MEGUMI -> Color.fromRGB(15, 25, 45);     // navy shadow
            case YUJI -> Color.fromRGB(180, 40, 50);      // red hoodie
            case TOJI -> Color.fromRGB(30, 30, 32);       // black fit
        };
    }

    // ------------------------------------------------------------------
    // Safety listeners: death, respawn, quit, crash recovery
    // ------------------------------------------------------------------
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        if (!isTransformed(p)) return;
        e.getDrops().removeIf(this::isJJKItem);
        CharacterType type = active.remove(p.getUniqueId());
        plugin.controller(type).onExit(p);
        plugin.bridge().removeModel(p);
        plugin.domains().endFor(p);
        plugin.summons().despawnAll(p);
        plugin.fx().dispel(p);
        plugin.energy().hideHud(p);
        plugin.energy().clear(p);
        pendingRespawnRestore.put(p.getUniqueId(), type);
        // Backup stays in memory + on disk until respawn restores it.
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        if (!pendingRespawnRestore.containsKey(p.getUniqueId())) return;
        pendingRespawnRestore.remove(p.getUniqueId());
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            InventoryBackup backup = backups.remove(p.getUniqueId());
            if (backup == null) backup = InventoryBackup.readFromDisk(plugin, p);
            if (backup != null) {
                clearJJKItems(p);
                backup.restore(p);
                InventoryBackup.deleteFromDisk(plugin, p);
                p.sendMessage(Component.text("Your survival inventory was restored after death.", NamedTextColor.GREEN));
            }
        }, 2L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        if (isTransformed(p)) exit(p, null);
        pendingRespawnRestore.remove(p.getUniqueId());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!plugin.getConfig().getBoolean("transform.restore-on-join", true)) return;
        // Crash recovery: a leftover backup file means the server died mid-transformation.
        if (!isTransformed(p) && InventoryBackup.existsOnDisk(plugin, p)) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                InventoryBackup backup = InventoryBackup.readFromDisk(plugin, p);
                if (backup != null) {
                    clearJJKItems(p);
                    backup.restore(p);
                    InventoryBackup.deleteFromDisk(plugin, p);
                    p.sendMessage(Component.text("Recovered your survival inventory from a JJK backup (crash recovery).", NamedTextColor.GREEN));
                }
            }, 10L);
        }
    }
}
