package dev.jjk.util;

import dev.jjk.JJKPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

/** Shows the clickable patch note on join (and on /jjk reload via broadcastToOnline). */
public final class PatchNotifier implements Listener {

    private final JJKPlugin plugin;

    public PatchNotifier(JJKPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        plugin.getServer().getScheduler().runTaskLater(plugin,
                () -> plugin.patchNotes().notify(e.getPlayer()), 20L);
    }
}
