package dev.jjk.skills;

import dev.jjk.JJKPlugin;
import dev.jjk.character.CharacterType;
import dev.jjk.combat.CharacterController;
import dev.jjk.combat.SkillDef;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Yuji Itadori — Divergent Fist, Blood Manipulation & Shrine.
 * Passive: Speed II, Jump Boost II, Resistance I; Black Flash timing window.
 * 1 Divergent Fist | Shift+1 Guaranteed Black Flash | 2 Manji Kick | 3 Piercing Blood
 * 4 Blood Stitch (RCT) | 5 Cursed Strikes | 6 Blood Edge | 7 Blood Burst | 8 Shrine Awakening
 * Q Soul-Seizing Dismantle | F Focus stance | Shift+F Domain: Hometown
 */
public final class YujiController extends CharacterController {

    private static final Color BLOOD = Color.fromRGB(190, 20, 40);
    private static final Color CE_BLUE = Color.fromRGB(70, 130, 255);

    private final Map<UUID, Long> lastCast = new HashMap<>();
    private final Map<UUID, Long> focusUntil = new HashMap<>();
    private final Map<UUID, Long> manjiUntil = new HashMap<>();
    private final Map<UUID, Long> guaranteedUntil = new HashMap<>();
    private final Map<UUID, Long> shrineUntil = new HashMap<>();

    public YujiController(JJKPlugin plugin) {
        super(plugin);

        // === NORMAL FORM — 4 moves (keys 1-4) ===
        regNormal(1, false, "Divergent Fist", "anim_divergent_fist", 25, 2000, this::divergentFist);
        regNormalLeft(1, "Black Flash (Guaranteed Focus)", "anim_black_flash", 80, 12000, this::guaranteedBlackFlash);
        regNormal(2, false, "Manji Kick (Counter)", "anim_manji_kick", 30, 8000, this::manjiKick);
        regNormal(3, false, "Blood Manipulation: Piercing Blood", "anim_piercing_blood", 45, 7000, this::piercingBlood);
        regNormal(4, false, "Reverse Cursed Technique (Blood Stitch)", "anim_rct", 50, 12000, this::bloodStitch);

        // === ULTIMATE FORM — 4 moves (replaces normal moves) ===
        regUltimate(1, false, "Cursed Strikes", "anim_divergent_fist", 30, 5000, this::cursedStrikes);
        regUltimate(2, false, "Blood Edge", "anim_piercing_blood", 40, 15000, this::bloodEdge);
        regUltimate(3, false, "Blood Burst", "anim_ground_slam", 55, 10000, this::bloodBurst);
        regUltimate(4, false, "Shrine Awakening", "anim_soul_dismantle", 70, 25000, this::shrineAwakening);

        // === Techniques shared by both forms ===
        reg("q", "Soul-Seizing Dismantle", "anim_soul_dismantle", 90, 18000, this::soulDismantle);
        reg("f", "Focus Stance", "anim_black_flash", 0, 5000, this::focus);
        reg("fs", "Domain Expansion: Hometown", "anim_yuji_domain", 220, 60000,
                p -> plugin.domains().start(p, CharacterType.YUJI));
    }

    @Override public CharacterType type() { return CharacterType.YUJI; }

    @Override public Material[] normalIcons() {
        return new Material[]{Material.BRICK, Material.COAL, Material.SHIELD, Material.RED_DYE};
    }

    @Override public Material[] ultimateIcons() {
        return new Material[]{Material.NETHERITE_SCRAP, Material.FERMENTED_SPIDER_EYE, Material.REDSTONE_BLOCK, Material.SOUL_SAND};
    }

    // --- state used by PassiveListener --------------------------------
    public boolean inBlackFlashWindow(Player p) {
        Long last = lastCast.get(p.getUniqueId());
        if (last == null) return false;
        long window = isFocused(p)
                ? plugin.getConfig().getLong("black-flash.focus-window-ms", 500)
                : plugin.getConfig().getLong("black-flash.window-ms", 250);
        return System.currentTimeMillis() - last <= window;
    }

    public void resetWindow(Player p) { lastCast.remove(p.getUniqueId()); }

    public boolean consumeGuaranteedBlackFlash(Player p) {
        Long until = guaranteedUntil.get(p.getUniqueId());
        if (until != null && until > System.currentTimeMillis()) {
            guaranteedUntil.remove(p.getUniqueId());
            return true;
        }
        return false;
    }

    public boolean consumeManjiStance(Player p) {
        Long until = manjiUntil.get(p.getUniqueId());
        if (until != null && until > System.currentTimeMillis()) {
            manjiUntil.remove(p.getUniqueId());
            return true;
        }
        return false;
    }

    public boolean shrineAwakened(Player p) {
        Long until = shrineUntil.get(p.getUniqueId());
        return until != null && until > System.currentTimeMillis();
    }

    private boolean isFocused(Player p) {
        Long until = focusUntil.get(p.getUniqueId());
        return until != null && until > System.currentTimeMillis();
    }

    @Override public void onCast(Player p, SkillDef def) {
        // Every skill opens the 0.25s Black Flash window for the next left-click hit.
        lastCast.put(p.getUniqueId(), System.currentTimeMillis());
    }

    /** Left-click inside the window (or with a guaranteed charge) lands the Black Flash. */
    @Override public boolean onLeftClick(Player p) {
        boolean guaranteed = consumeGuaranteedBlackFlash(p);
        if (!guaranteed && !inBlackFlashWindow(p)) return false;
        LivingEntity t = fx().target(p, 4.0);
        if (t == null) return false; // keep the window open until they aim at a target

        // Consume the window before damaging, otherwise the damage event would
        // trigger PassiveListener's Black Flash a second time.
        resetWindow(p);
        double mult = plugin.getConfig().getDouble("black-flash.damage-multiplier", 2.5);
        fx().hit(t, 12.0 * mult, p, false, false);
        plugin.energy().add(p, plugin.getConfig().getDouble("black-flash.ce-refill", 40));
        plugin.bridge().play(p, "anim_black_flash");
        p.playSound(p.getLocation(), "entity.warden.sonic_boom", 0.8f, 1.6f);
        t.getWorld().spawnParticle(Particle.SONIC_BOOM, t.getLocation().add(0, 1, 0), 1);
        fx().dust(t.getLocation().add(0, 1, 0), Color.BLACK, 2f, 12, 0.4);
        fx().dust(t.getLocation().add(0, 1, 0), BLOOD, 1.6f, 12, 0.4);
        p.sendActionBar(Component.text(" BLACK FLASH ", NamedTextColor.DARK_RED));
        return true;
    }

    @Override public void onTransform(Player p) { applyPassives(p); }

    private void applyPassives(Player p) {
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, PotionEffect.INFINITE_DURATION, 1, true, false));
        p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, PotionEffect.INFINITE_DURATION, 1, true, false));
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, PotionEffect.INFINITE_DURATION, 0, true, false));
    }

    @Override public void tick(Player p) {
        // Re-apply permanent passives if cleared (milk bucket / death).
        if (!p.hasPotionEffect(PotionEffectType.SPEED)) applyPassives(p);
    }

    @Override public void onExit(Player p) {
        for (PotionEffectType t : new PotionEffectType[]{PotionEffectType.SPEED, PotionEffectType.JUMP_BOOST, PotionEffectType.RESISTANCE}) {
            p.removePotionEffect(t);
        }
        lastCast.remove(p.getUniqueId());
        focusUntil.remove(p.getUniqueId());
        manjiUntil.remove(p.getUniqueId());
        guaranteedUntil.remove(p.getUniqueId());
        shrineUntil.remove(p.getUniqueId());
    }

    @Override public String status(Player p) {
        if (isFocused(p)) return "§4Focus";
        if (shrineAwakened(p)) return "§cShrine";
        return "";
    }

    // ------------------------------------------------------------------
    private void divergentFist(Player p) {
        LivingEntity target = fx().target(p, 4.5);
        if (target == null) {
            plugin.energy().flash(p, "§cGet closer — Divergent Fist is melee range");
            plugin.cooldowns().reset(p, "yuji:1");
            return;
        }
        fx().hit(target, 5.0, p, false, false);
        fx().knock(target, p.getEyeLocation().getDirection().setY(0.3), 1.2);
        p.getWorld().spawnParticle(Particle.CRIT, target.getLocation().add(0, 1, 0), 10, 0.2, 0.3, 0.2, 0.2);
        p.playSound(p.getLocation(), "entity.player.attack.strong", 1f, 0.8f);
        // Delayed cursed energy impact 0.4s later.
        new BukkitRunnable() {
            @Override public void run() {
                if (!target.isValid()) return;
                fx().hit(target, 4.0, p, false, false);
                fx().dust(target.getLocation().add(0, 1, 0), CE_BLUE, 1.8f, 15, 0.4);
                target.getWorld().spawnParticle(Particle.SONIC_BOOM, target.getLocation().add(0, 1, 0), 1);
                target.getWorld().playSound(target.getLocation(), "entity.player.attack.knockback", 1f, 0.7f);
            }
        }.runTaskLater(plugin, 8L);
    }

    private void guaranteedBlackFlash(Player p) {
        guaranteedUntil.put(p.getUniqueId(), System.currentTimeMillis() + 2000);
        fx().dust(p.getLocation().add(0, 1, 0), Color.BLACK, 1.6f, 12, 0.4);
        p.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, p.getLocation().add(0, 1, 0), 12, 0.3, 0.6, 0.3, 0.1);
        p.playSound(p.getLocation(), "entity.warden.heartbeat", 1f, 1.5f);
        LivingEntity target = fx().target(p, 4.5);
        if (target != null) {
            // Instant uppercut if already in range.
            guaranteedUntil.remove(p.getUniqueId());
            double mult = plugin.getConfig().getDouble("black-flash.damage-multiplier", 2.5);
            fx().hit(target, 5.0 * mult, p, false, true);
            fx().knock(target, p.getEyeLocation().getDirection().setY(0.8), 2.8);
            target.getWorld().spawnParticle(Particle.SONIC_BOOM, target.getLocation().add(0, 1, 0), 1);
            fx().dust(target.getLocation().add(0, 1, 0), Color.BLACK, 2.2f, 15, 0.5);
            fx().dust(target.getLocation().add(0, 1, 0), BLOOD, 1.8f, 15, 0.5);
            plugin.energy().add(p, plugin.getConfig().getDouble("black-flash.ce-refill", 40));
            p.playSound(p.getLocation(), "entity.warden.sonic_boom", 0.8f, 1.6f);
        } else {
            p.sendMessage(net.kyori.adventure.text.Component.text("Black Flash charged — land a hit within 2s!", net.kyori.adventure.text.format.NamedTextColor.DARK_RED));
        }
    }

    private void manjiKick(Player p) {
        manjiUntil.put(p.getUniqueId(), System.currentTimeMillis() + 1500);
        p.sendMessage(net.kyori.adventure.text.Component.text("Manji stance — incoming melee will be countered (1.5s)", net.kyori.adventure.text.format.NamedTextColor.YELLOW));
        fx().ring(p.getLocation(), 1.2, Color.fromRGB(255, 200, 60), 12);
        p.playSound(p.getLocation(), "item.trident.return", 1f, 1.4f);
    }

    private void piercingBlood(Player p) {
        fx().beam(p, 20, 7.0, BLOOD, false, false);
        p.playSound(p.getLocation(), "entity.firework_rocket.launch", 1f, 1.8f);
        fx().dust(p.getEyeLocation(), BLOOD, 1.4f, 8, 0.2);
    }

    private void bloodStitch(Player p) {
        new BukkitRunnable() {
            int ticks = 0;
            @Override public void run() {
                if (!p.isOnline() || ticks++ >= 8) { cancel(); return; }
                p.setHealth(Math.min(p.getAttribute(Attribute.MAX_HEALTH).getValue(), p.getHealth() + 2));
                fx().dust(p.getLocation().add(0, 1, 0), BLOOD, 1.2f, 8, 0.35);
            }
        }.runTaskTimer(plugin, 0L, 4L);
        p.removePotionEffect(PotionEffectType.POISON);
        p.removePotionEffect(PotionEffectType.WITHER);
        p.removePotionEffect(PotionEffectType.SLOWNESS);
        p.playSound(p.getLocation(), "block.beacon.ambient", 1f, 1.8f);
    }

    private void cursedStrikes(Player p) {
        LivingEntity target = fx().target(p, 4.5);
        if (target == null) {
            plugin.energy().flash(p, "§cNo target in melee range");
            plugin.cooldowns().reset(p, "yuji:5");
            return;
        }
        new BukkitRunnable() {
            int hits = 0;
            @Override public void run() {
                if (!target.isValid() || hits >= 3 || !p.isOnline()) { cancel(); return; }
                hits++;
                fx().hit(target, 3.0, p, false, false);
                p.getWorld().spawnParticle(Particle.CRIT, target.getLocation().add(0, 1, 0), 8, 0.2, 0.3, 0.2, 0.3);
                p.playSound(p.getLocation(), "entity.player.attack.strong", 0.9f, 1 + hits * 0.2f);
                if (hits == 3) fx().knock(target, p.getEyeLocation().getDirection().setY(0.4), 1.6);
            }
        }.runTaskTimer(plugin, 0L, 4L);
    }

    private void bloodEdge(Player p) {
        p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 120, 0));
        fx().dust(p.getLocation().add(0, 1, 0), BLOOD, 1.4f, 15, 0.4);
        p.playSound(p.getLocation(), "entity.evoker.cast_spell", 1f, 1.6f);
    }

    private void bloodBurst(Player p) {
        Location c = p.getLocation().add(0, 1, 0);
        fx().aoe(c, 4, 6.0, p, false, false, le ->
                fx().knock(le, le.getLocation().toVector().subtract(c.toVector()).setY(0.3), 1.3));
        fx().expandingRings(c, BLOOD, 4);
        p.setHealth(Math.min(p.getAttribute(Attribute.MAX_HEALTH).getValue(), p.getHealth() + 2));
        p.getWorld().playSound(c, "entity.generic.explode", 0.8f, 1.4f);
    }

    private void shrineAwakening(Player p) {
        shrineUntil.put(p.getUniqueId(), System.currentTimeMillis() + 8000);
        p.sendMessage(net.kyori.adventure.text.Component.text("Shrine awakens — your melee hits carry soul cuts for 8s", net.kyori.adventure.text.format.NamedTextColor.DARK_RED));
        p.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, p.getLocation().add(0, 1, 0), 20, 0.4, 0.8, 0.4, 0.02);
        p.playSound(p.getLocation(), "entity.warden.heartbeat", 1f, 0.8f);
    }

    private void soulDismantle(Player p) {
        LivingEntity target = fx().target(p, 4.5);
        if (target == null) {
            plugin.energy().flash(p, "§cSoul-Seizing Dismantle needs a target in reach");
            plugin.cooldowns().reset(p, "yuji:q");
            return;
        }
        // Scissor-line cuts directly on the target: armor bypass + CE drain.
        Location c = target.getLocation().add(0, 1, 0);
        fx().line(c.clone().add(-1, 1, 0), new org.bukkit.util.Vector(1, -1, 0), 2.8, BLOOD, 0.2);
        fx().line(c.clone().add(1, 1, 0), new org.bukkit.util.Vector(-1, -1, 0), 2.8, BLOOD, 0.2);
        fx().hit(target, 10.0, p, true, true);
        target.getWorld().spawnParticle(Particle.SWEEP_ATTACK, c, 3, 0.3, 0.4, 0.3, 0);
        if (target instanceof Player tp && plugin.characters().isTransformed(tp)) {
            double drained = Math.min(50, plugin.energy().get(tp));
            plugin.energy().consume(tp, drained);
            plugin.energy().add(p, drained / 2);
            tp.sendMessage(net.kyori.adventure.text.Component.text("Yuji seized your soul — " + (int) drained + " CE drained!", net.kyori.adventure.text.format.NamedTextColor.DARK_RED));
        }
        p.playSound(p.getLocation(), "entity.player.attack.sweep", 1f, 0.6f);
    }

    private void focus(Player p) {
        focusUntil.put(p.getUniqueId(), System.currentTimeMillis() + 5000);
        p.sendMessage(net.kyori.adventure.text.Component.text("Focus — Black Flash window doubled to 0.5s for 5s", net.kyori.adventure.text.format.NamedTextColor.DARK_RED));
        fx().dust(p.getEyeLocation(), Color.BLACK, 1f, 6, 0.2);
    }
}
