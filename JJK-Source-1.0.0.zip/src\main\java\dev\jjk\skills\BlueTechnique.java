package dev.jjk.skills;

import dev.jjk.JJKPlugin;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Gojo - Cursed Technique Lapse: Blue, built entirely from particles.
 * No display entities, models or resource packs are used.
 *
 *   ticks  0-15  bright blue/cyan sphere at the target point
 *   ticks 15-40  tightening inward spiral vortex (two blue shades)
 *   ticks 40-55  gravity pull on nearby entities + core burst / slam damage
 *   ticks 55-75  fading blue particles with a resonant sound
 */
public final class BlueTechnique {

    private static final Particle.DustOptions BLUE =
            new Particle.DustOptions(Color.fromRGB(40, 120, 255), 1.7f);
    private static final Particle.DustOptions CYAN =
            new Particle.DustOptions(Color.fromRGB(80, 220, 255), 1.3f);
    private static final Particle.DustOptions LIGHT =
            new Particle.DustOptions(Color.fromRGB(180, 235, 255), 1.0f);
    private static final Particle.DustOptions WHITE =
            new Particle.DustOptions(Color.fromRGB(245, 250, 255), 2.0f);

    private final JJKPlugin plugin;
    private final java.util.Map<UUID, BukkitRunnable> active = new java.util.HashMap<>();

    public BlueTechnique(JJKPlugin plugin) { this.plugin = plugin; }

    public void cast(Player caster) {
        Vector dir = caster.getEyeLocation().getDirection().clone().normalize();
        LivingEntity target = plugin.fx().target(caster, 8);
        Location center = target != null ? target.getLocation().clone().add(0, 1, 0)
                : caster.getEyeLocation().clone().add(dir.multiply(8));

        caster.getWorld().playSound(center, "block.respawn_anchor.charge", 1f, 0.6f);
        Set<java.util.UUID> pulledTargets = new HashSet<>();

        BukkitRunnable animation = new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                if (!caster.isOnline() || center.getWorld() == null) {
                    active.remove(caster.getUniqueId());
                    cancel();
                    return;
                }
                World world = center.getWorld();

                if (tick < 15) {
                    phaseSphere(world, center, tick);
                } else if (tick < 40) {
                    phaseVortex(world, center, tick);
                } else if (tick < 55) {
                    phasePull(world, center, caster, tick, pulledTargets);
                } else {
                    phaseDissipation(world, center, tick);
                }

                tick++;
                if (tick > 75) {
                    world.spawnParticle(Particle.SMOKE, center, 8, .25, .25, .25, .01);
                    active.remove(caster.getUniqueId());
                    cancel();
                }
            }
        };
        BukkitRunnable previous = active.put(caster.getUniqueId(), animation);
        if (previous != null) previous.cancel();
        animation.runTaskTimer(plugin, 0L, 1L);
    }

    // ------------------------------------------------------------------
    // Phase 1 - bright pulsing sphere (ticks 0-15)
    // ------------------------------------------------------------------
    private void phaseSphere(World world, Location center, int tick) {
        double progress = tick / 15.0;
        double radius = 1.4 + 0.35 * Math.sin(tick * 0.8) + 0.3 * progress;
        for (int i = 0; i < 100; i++) {
            Location p = center.clone().add(randomUnit().multiply(radius));
            world.spawnParticle(Particle.DUST, p, 1, 0.02, 0.02, 0.02, 0, BLUE);
        }
        world.spawnParticle(Particle.DUST, center, 10, 0.2, 0.2, 0.2, 0, CYAN);
        plugin.fx().sharp(center, new Vector(0, 1, 0), 8);
    }

    // ------------------------------------------------------------------
    // Phase 2 - two-tone inward spiral (ticks 15-40)
    // ------------------------------------------------------------------
    private void phaseVortex(World world, Location center, int tick) {
        double progress = (tick - 15) / 25.0;
        double radius = 2.6 - 2.15 * progress;
        int rings = 5;
        int points = 16;
        for (int r = 0; r < rings; r++) {
            double base = tick * 0.42 + r * (2 * Math.PI / rings);
            for (int i = 0; i < points; i++) {
                double a = base + i * (2 * Math.PI / points);
                double y = Math.sin(a * 2 + r) * 0.55 * (1 - progress) + (r - 2) * 0.2;
                Location p = center.clone().add(Math.cos(a) * radius, y, Math.sin(a) * radius);
                Particle.DustOptions shade = (i + r) % 3 == 0 ? LIGHT : BLUE;
                world.spawnParticle(Particle.DUST, p, 1, 0, 0, 0, 0, shade);
            }
        }
        world.spawnParticle(Particle.DUST, center, 14, 0.25, 0.25, 0.25, 0, CYAN);
        plugin.fx().sharp(center, new Vector(0, 1, 0), 8);
    }

    // ------------------------------------------------------------------
    // Phase 3 - gravity pull, core burst and slam damage (ticks 40-55)
    // ------------------------------------------------------------------
    private void phasePull(World world, Location center, Player caster, int tick, Set<java.util.UUID> pulledTargets) {
        double pullStrength = plugin.getConfig().getDouble("blue.pull", 0.42);
        double radius = plugin.getConfig().getDouble("blue.radius", 8.0);

        for (Entity e : world.getNearbyEntities(center, radius, radius, radius)) {
            if (!(e instanceof LivingEntity le) || e.equals(caster)) continue;
            if (plugin.summons().isOwnedSummon(caster, e)) continue;
            if (!pulledTargets.contains(le.getUniqueId()) && pulledTargets.size() >= 3) continue;
            pulledTargets.add(le.getUniqueId());
            Vector toward = center.toVector().subtract(le.getLocation().toVector());
            double dist = toward.length();
            if (dist < 0.4) continue;
            toward.normalize().multiply(pullStrength * (1.0 + 0.6 * (1.0 - Math.min(1.0, dist / radius))));
            le.setVelocity(le.getVelocity().add(toward));
        }

        if (tick == 40) {
            world.spawnParticle(Particle.FLASH, center, 30, 0.2, 0.2, 0.2, 0);
            world.spawnParticle(Particle.DUST, center, 120, 0.35, 0.35, 0.35, 0, WHITE);
            world.spawnParticle(Particle.DUST, center, 90, 0.8, 0.8, 0.8, 0.2, CYAN);
            world.playSound(center, "entity.generic.explode", 1f, 1.4f);
        } else {
            world.spawnParticle(Particle.DUST, center, 40, 0.45, 0.45, 0.45, 0, BLUE);
        }

        // Final compression slam at tick 54, caster is never included.
        if (tick == 54) {
            double damage = plugin.getConfig().getDouble("blue.damage", 8.0);
            for (Entity e : world.getNearbyEntities(center, 4.5, 4.5, 4.5)) {
                if (!(e instanceof LivingEntity le) || e.equals(caster)) continue;
                if (plugin.summons().isOwnedSummon(caster, e)) continue;
                Vector toward = center.toVector().subtract(le.getLocation().toVector()).normalize();
                le.setVelocity(le.getVelocity().add(toward.multiply(0.6).setY(0.8)));
                plugin.fx().hit(le, damage, caster, false, false);
            }
            world.spawnParticle(Particle.EXPLOSION_EMITTER, center, 1);
        }
    }

    // ------------------------------------------------------------------
    // Phase 4 - fading particles + resonant sound (ticks 55-75)
    // ------------------------------------------------------------------
    private void phaseDissipation(World world, Location center, int tick) {
        double progress = (tick - 55) / 20.0;
        double radius = 0.8 + 2.0 * progress;
        int count = Math.max(4, (int) (70 * (1 - progress)));
        Particle.DustOptions shade = progress < 0.5 ? CYAN : LIGHT;
        for (int i = 0; i < count; i++) {
            Location p = center.clone().add(randomUnit().multiply(radius));
            world.spawnParticle(Particle.DUST, p, 1, 0.03, 0.03, 0.03, 0, shade);
        }
        if (tick == 55) world.playSound(center, "block.amethyst_block.resonate", 0.9f, 1.2f);
    }

    private static Vector randomUnit() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double u = r.nextDouble(-1, 1);
        double theta = r.nextDouble(0, 2 * Math.PI);
        double s = Math.sqrt(1 - u * u);
        return new Vector(s * Math.cos(theta), u, s * Math.sin(theta));
    }
}
