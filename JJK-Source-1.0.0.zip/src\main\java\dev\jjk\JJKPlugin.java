package dev.jjk;

import dev.jjk.character.CharacterManager;
import dev.jjk.combat.CharacterController;
import dev.jjk.combat.CombatInputListener;
import dev.jjk.combat.ChainManager;
import dev.jjk.combat.CooldownManager;
import dev.jjk.combat.EnergyManager;
import dev.jjk.combat.PassiveListener;
import dev.jjk.command.JJKCommand;
import dev.jjk.domain.DomainManager;
import dev.jjk.gui.CharacterMenu;
import dev.jjk.item.CursedItems;
import dev.jjk.skills.GojoController;
import dev.jjk.skills.MegumiController;
import dev.jjk.skills.SukunaController;
import dev.jjk.skills.TojiController;
import dev.jjk.skills.YujiController;
import dev.jjk.summon.SummonManager;
import dev.jjk.util.AbilityNotes;
import dev.jjk.util.BetterModelBridge;
import dev.jjk.util.FX;
import dev.jjk.util.Messages;
import dev.jjk.util.PatchNotifier;
import dev.jjk.util.PatchNotes;
import dev.jjk.util.ResourcePack;
import dev.jjk.util.Sounds;
import dev.jjk.character.CharacterType;
import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.EnumMap;
import java.util.Map;

public final class JJKPlugin extends JavaPlugin {

    private static JJKPlugin instance;

    private CharacterManager characters;
    private EnergyManager energy;
    private CooldownManager cooldowns;
    private ChainManager chains;
    private DomainManager domains;
    private SummonManager summons;
    private FX fx;
    private BetterModelBridge bridge;
    private CursedItems cursedItems;
    private CharacterMenu menu;
    private CombatInputListener gate;
    private Messages messages;
    private Sounds sounds;
    private ResourcePack resourcePack;
    private AbilityNotes notes;
    private PatchNotes patchNotes;
    private final Map<CharacterType, CharacterController> controllers = new EnumMap<>(CharacterType.class);

    private NamespacedKey abilityKey;
    private NamespacedKey visualKey;
    private NamespacedKey cursedObjectKey;
    private NamespacedKey summonKey;

    public static JJKPlugin get() { return instance; }

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        messages = new Messages(this);
        sounds = new Sounds(this);
        resourcePack = new ResourcePack(this);
        notes = new AbilityNotes(this);
        patchNotes = new PatchNotes(this);

        abilityKey = new NamespacedKey(this, "ability");
        visualKey = new NamespacedKey(this, "visual");
        cursedObjectKey = new NamespacedKey(this, "cursed_object");
        summonKey = new NamespacedKey(this, "summon");

        new File(getDataFolder(), "backups").mkdirs();
        exportModelFiles();

        fx = new FX(this);
        bridge = new BetterModelBridge(this);
        cooldowns = new CooldownManager();
        chains = new ChainManager(this);
        domains = new DomainManager(this);
        summons = new SummonManager(this);
        energy = new EnergyManager(this);
        characters = new CharacterManager(this);
        cursedItems = new CursedItems(this);
        menu = new CharacterMenu(this);
        gate = new CombatInputListener(this);

        controllers.put(CharacterType.GOJO, new GojoController(this));
        controllers.put(CharacterType.SUKUNA, new SukunaController(this));
        controllers.put(CharacterType.MEGUMI, new MegumiController(this));
        controllers.put(CharacterType.YUJI, new YujiController(this));
        controllers.put(CharacterType.TOJI, new TojiController(this));

        getServer().getPluginManager().registerEvents(gate, this);
        getServer().getPluginManager().registerEvents(chains, this);
        getServer().getPluginManager().registerEvents(new PassiveListener(this), this);
        getServer().getPluginManager().registerEvents(characters, this);
        getServer().getPluginManager().registerEvents(cursedItems, this);
        getServer().getPluginManager().registerEvents(menu, this);
        getServer().getPluginManager().registerEvents(new PatchNotifier(this), this);

        JJKCommand cmd = new JJKCommand(this);
        getCommand("jjk").setExecutor(cmd);
        getCommand("jjk").setTabCompleter(cmd);

        resourcePack.generate();

        energy.startTicker();
        domains.startTicker();
        fx.startReaper();
        chains.startTicker();
        patchNotes.broadcastToOnline();

        getLogger().info("JJK enabled. BetterModel hook: " + (bridge.isAvailable() ? "ACTIVE" : "particle fallback"));
    }

    @Override
    public void onDisable() {
        // Restore every transformed player so no survival item is ever lost.
        if (characters != null) characters.exitAll("Server shutting down");
        if (domains != null) domains.shutdown();
        if (summons != null) summons.shutdown();
        if (chains != null) chains.shutdown();
        if (fx != null) fx.shutdown();
        if (energy != null) energy.shutdown();
    }

    private void exportModelFiles() {
        String[] models = {
                "jjk_player.bbmodel", "divine_dog.bbmodel", "nue.bbmodel", "mahoraga.bbmodel",
                "sukuna_shrine.bbmodel", "inverted_spear.bbmodel", "inverted_spear_of_heaven.bbmodel",
                "playful_cloud.bbmodel", "split_soul_katana.bbmodel"
        };
        for (String m : models) {
            File out = new File(getDataFolder(), "models/" + m);
            if (!out.exists()) {
                try { saveResource("models/" + m, false); } catch (Exception ignored) { }
            }
        }
    }

    public CharacterManager characters() { return characters; }
    public EnergyManager energy() { return energy; }
    public CooldownManager cooldowns() { return cooldowns; }
    public ChainManager chains() { return chains; }
    public DomainManager domains() { return domains; }
    public SummonManager summons() { return summons; }
    public FX fx() { return fx; }
    public BetterModelBridge bridge() { return bridge; }
    public CursedItems cursedItems() { return cursedItems; }
    public CharacterMenu menu() { return menu; }
    public CombatInputListener gate() { return gate; }
    public Messages messages() { return messages; }
    public Sounds sounds() { return sounds; }
    public ResourcePack resourcePack() { return resourcePack; }
    public AbilityNotes notes() { return notes; }
    public PatchNotes patchNotes() { return patchNotes; }
    public CharacterController controller(CharacterType type) { return controllers.get(type); }

    public NamespacedKey abilityKey() { return abilityKey; }
    public NamespacedKey visualKey() { return visualKey; }
    public NamespacedKey cursedObjectKey() { return cursedObjectKey; }
    public NamespacedKey summonKey() { return summonKey; }

    public boolean griefing() { return getConfig().getBoolean("griefing.enabled", true); }
}
