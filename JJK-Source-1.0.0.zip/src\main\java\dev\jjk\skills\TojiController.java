package dev.jjk.skills;

import dev.jjk.JJKPlugin;
import dev.jjk.character.CharacterType;
import dev.jjk.combat.CharacterController;
import dev.jjk.combat.DamageFlags;
import dev.jjk.combat.SkillDef;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Toji Fushiguro â€” Heavenly Restriction (zero cursed energy).
 * Stamina / Momentum gauge; walks through domains; sees invisible players.
 * 1 ISOH Nullify Thrust | Shift+1 Chain of a Thousand Miles | 2 Playful Cloud
 * 3 Split Soul Katana | 4 Heavenly Blitz (3 charges) | 5 Cursed Tool Throw
 * 6 Momentum Surge | 7 Stealth Strike | 8 Inventory Curse snack
 * Q Fly Head Smokescreen | F Weapon cycle + Inventory Curse | Shift+F Predator Instinct
 */
public final class TojiController extends CharacterController {

    public enum Weapon {
        INVERTED_SPEAR("Inverted Spear of Heaven", "isoh", Material.TRIDENT,
                new Material[]{Material.TRIDENT, Material.LEAD, Material.END_ROD, Material.FEATHER,
                        Material.LEAD, Material.ANVIL}),
        PLAYFUL_CLOUD("Playful Cloud", "playful", Material.BLAZE_ROD,
                new Material[]{Material.BLAZE_ROD, Material.ANVIL, Material.SLIME_BLOCK, Material.FEATHER,
                        Material.OBSIDIAN, Material.ANVIL}),
        SPLIT_SOUL_KATANA("Split Soul Katana", "soul", Material.IRON_SWORD,
                new Material[]{Material.IRON_SWORD, Material.NETHERITE_SWORD, Material.DIAMOND_SWORD, Material.FEATHER,
                        Material.OBSIDIAN, Material.ANVIL});
        public final String label;
        public final String note;
        public final Material icon;
        public final Material[] icons;
        Weapon(String label, String note, Material icon, Material[] icons) {
            this.label = label; this.note = note; this.icon = icon; this.icons = icons;
        }
    }

    private final Map<Weapon, Map<String, SkillDef>> weaponSkills = new java.util.EnumMap<>(Weapon.class);
    private final Map<UUID, Integer> weaponIndex = new HashMap<>();
    private final Map<UUID, Integer> blitzCharges = new HashMap<>();
    private final Map<UUID, Long> blitzRecharge = new HashMap<>();
    private final Map<UUID, Long> noFallUntil = new HashMap<>();
    private final Map<UUID, ItemDisplay> inventoryCurse = new HashMap<>();

    public TojiController(JJKPlugin plugin) {
        super(plugin);

        // === WEAPON MOVESETS: cycling cursed tools swaps keys 1-4 ===
        for (Weapon w : Weapon.values()) {
            Map<String, SkillDef> set = new HashMap<>();
            String g = "weapon." + w.note;
            switch (w) {
                case INVERTED_SPEAR -> {
                    set.put("1", makeDef(g, "1", "Inverted Spear: Nullify Thrust", "anim_isoh_thrust", 15, 1500, this::isohThrust));
                    set.put("1s", makeDef(g, "1s", "Chain of a Thousand Miles", "anim_chain_whip", 25, 8000, this::chainWhip));
                    set.put("2", makeDef(g, "2", "Spear Sweep", "anim_slash", 25, 5000, this::spearSweep));
                    set.put("3", makeDef(g, "3", "Soul Lock", "anim_isoh_thrust", 45, 9000, this::soulLock));
                }
                case PLAYFUL_CLOUD -> {
                    set.put("1", makeDef(g, "1", "Playful Cloud: Cataclysm Smash", "anim_playful_cloud", 30, 8000, this::playfulCloud));
                    set.put("1s", makeDef(g, "1s", "Cloud Whirl", "anim_playful_cloud", 40, 9000, this::cloudWhirl));
                    set.put("2", makeDef(g, "2", "Momentum Surge", "anim_toji_blitz", 20, 6000, this::momentumSurge));
                    set.put("3", makeDef(g, "3", "Ground Shatter", "anim_ground_slam", 45, 10000, this::groundShatter));
                }
                case SPLIT_SOUL_KATANA -> {
                    set.put("1", makeDef(g, "1", "Split Soul Katana: True Slash", "anim_slash", 25, 5000, this::splitSoulKatana));
                    set.put("1s", makeDef(g, "1s", "Soul Rend", "anim_slash", 40, 8000, this::soulRend));
                    set.put("2", makeDef(g, "2", "Iaijutsu Dash", "anim_dash", 35, 7000, this::iaijutsuDash));
                    set.put("3", makeDef(g, "3", "Soul Sever", "anim_slash", 55, 12000, this::soulSever));
                }
            }
            set.put("4", makeDef(g, "4", "Heavenly Blitz (Air Step)", "anim_toji_blitz", 20, 1000, this::heavenlyBlitz));
            weaponSkills.put(w, set);
        }

        // === ULTIMATE FORM â€” 4 moves (replaces normal moves) ===
        regUltimate(1, false, "Cursed Tool Throw", "anim_isoh_thrust", 15, 6000, this::toolThrow);
        regUltimate(2, false, "Momentum Surge", "anim_toji_blitz", 30, 10000, this::momentumSurge);
        regUltimate(3, false, "Stealth Strike", "anim_slash", 20, 8000, this::stealthStrike);
        regUltimate(4, false, "Inventory Curse (Snack)", "anim_rct", 25, 15000, this::inventorySnack);

        // === Techniques shared by both forms ===
        reg("5", "Spear Pierce: Chain Shot", "anim_isoh_thrust", 25, 6000, p -> spearPierce(p, false));
        reg("5s", "Spear Pierce: Chain Snare", "anim_isoh_thrust", 40, 9000, p -> spearPierce(p, true));
        reg("6", "Chain Slam: Mace Breaker", "anim_ground_slam", 60, 12000, this::chainSlam);
        reg("6s", "Chain Throw", "anim_isoh_thrust", 20, 6000, this::chainThrow);
        reg("q", "Fly Head Smokescreen", "anim_fly_head_swarm", 40, 20000, this::flyHead);
        reg("f", "Cycle Cursed Tool", "anim_clasp", 0, 300, this::cycleWeapon);
        reg("fs", "Predator Instinct (Domain Breaker)", "anim_dash", 50, 30000, this::predatorInstinct);
    }

    @Override public CharacterType type() { return CharacterType.TOJI; }

    @Override public Material[] normalIcons() {
        return new Material[]{Material.TRIDENT, Material.BLAZE_ROD, Material.IRON_SWORD, Material.FEATHER};
    }

    @Override public Material[] ultimateIcons() {
        return new Material[]{Material.ARROW, Material.SUGAR, Material.INK_SAC, Material.APPLE,
                Material.LEAD, Material.ANVIL};
    }

    @Override public SkillDef skill(Player p, int slot, boolean shift) {
        if (slot >= 5) {
            if (slot == 6 && !plugin.chains().hasVictim(p.getUniqueId())) return null;
            return shared(slot + (shift ? "s" : ""));
        }
        if (isUltimateForm(p)) return super.skill(p, slot, shift);
        Map<String, SkillDef> set = weaponSkills.get(weapon(p));
        String key = slot + (shift ? "s" : "");
        SkillDef def = set.get(key);
        if (def == null && shift) def = set.get(String.valueOf(slot));
        return def;
    }

    @Override public Material[] activeIcons(Player p) {
        return isUltimateForm(p) ? ultimateIcons() : weapon(p).icons;
    }

    @Override public String iconNoteGroup(Player p) {
        return "weapon." + weapon(p).note;
    }

    @Override protected ItemStack customIcon(Player p, int key, SkillDef def) {
        if (key == 6 && def == null && !plugin.chains().hasVictim(p.getUniqueId())) {
            ItemStack locked = new ItemStack(Material.BARRIER);
            ItemMeta meta = locked.getItemMeta();
            meta.displayName(Component.text("[7] CHAIN SLAM - LOCKED", NamedTextColor.RED, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(
                    Component.text("Land Spear Pierce (key 6) to unlock this follow-up.", NamedTextColor.GRAY)
                            .decoration(TextDecoration.ITALIC, false),
                    Component.text("You then have 10s to slam or throw your target.", NamedTextColor.DARK_GRAY)
                            .decoration(TextDecoration.ITALIC, false)));
            meta.getPersistentDataContainer().set(plugin.abilityKey(), PersistentDataType.STRING, "toji:6locked");
            locked.setItemMeta(meta);
            return locked;
        }
        return null;
    }

    public Weapon weapon(Player p) {
        return Weapon.values()[weaponIndex.getOrDefault(p.getUniqueId(), 0)];
    }

    public boolean noFall(Player p) {
        Long until = noFallUntil.get(p.getUniqueId());
        return until != null && until > System.currentTimeMillis();
    }

    @Override public String status(Player p) {
        return "Â§a" + weapon(p).label + " Â§7| Blitz x" + charges(p);
    }

    private int charges(Player p) { return blitzCharges.getOrDefault(p.getUniqueId(), 3); }

    private long cuffMs() { return plugin.getConfig().getLong("toji-chain.cuff-seconds", 10) * 1000L; }
    private int bleedTicks() { return plugin.getConfig().getInt("toji-chain.bleed-ticks", 5); }
    private double critChance() { return plugin.getConfig().getDouble("toji-chain.crit-chance", 0.20); }
    private int debuffSeconds(boolean crit) {
        return crit ? plugin.getConfig().getInt("toji-chain.crit-debuff-seconds", 30)
                    : plugin.getConfig().getInt("toji-chain.normal-debuff-seconds", 5);
    }

    @Override public void onTransform(Player p) {
        weaponIndex.put(p.getUniqueId(), 0);
        blitzCharges.put(p.getUniqueId(), 3);
        spawnInventoryCurse(p);
        // Toji's Heavenly Restriction: permanent buffs.
        p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, PotionEffect.INFINITE_DURATION, 2));
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, PotionEffect.INFINITE_DURATION, 2));
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, PotionEffect.INFINITE_DURATION, 1));
    }

    @Override public void onExit(Player p) {
        plugin.chains().release(p.getUniqueId());
        weaponIndex.remove(p.getUniqueId());
        blitzCharges.remove(p.getUniqueId());
        noFallUntil.remove(p.getUniqueId());
        ItemDisplay curse = inventoryCurse.remove(p.getUniqueId());
        if (curse != null && curse.isValid()) curse.remove();
        // Remove permanent buffs.
        p.removePotionEffect(PotionEffectType.STRENGTH);
        p.removePotionEffect(PotionEffectType.RESISTANCE);
        p.removePotionEffect(PotionEffectType.SPEED);
    }

    @Override public void tick(Player p) {
        // Blitz charge recharge: 1 charge / 4s up to 3.
        int c = charges(p);
        if (c < 3) {
            long last = blitzRecharge.getOrDefault(p.getUniqueId(), System.currentTimeMillis());
            if (System.currentTimeMillis() - last >= 4000) {
                blitzCharges.put(p.getUniqueId(), c + 1);
                blitzRecharge.put(p.getUniqueId(), System.currentTimeMillis());
            }
        } else {
            blitzRecharge.put(p.getUniqueId(), System.currentTimeMillis());
        }
        // Heavenly Restriction: see invisible players through walls.
        for (Entity e : p.getNearbyEntities(20, 12, 20)) {
            if (e instanceof Player other && !other.equals(p) && other.hasPotionEffect(PotionEffectType.INVISIBILITY)) {
                other.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 30, 0, true, false));
            }
        }
        // Inventory curse follows overhead.
        ItemDisplay curse = inventoryCurse.get(p.getUniqueId());
        if (curse != null && curse.isValid()) {
            curse.teleport(p.getLocation().add(0, 2.6, 0));
        } else {
            spawnInventoryCurse(p);
        }
    }

    private void spawnInventoryCurse(Player p) {
        ItemDisplay curse = fx().itemDisplay(p.getLocation().add(0, 2.6, 0), Material.CHEST, 0.6f);
        inventoryCurse.put(p.getUniqueId(), curse);
        plugin.bridge().spawnModel(p.getLocation(), "inventory_curse", "anim_idle");
    }

    private void cycleWeapon(Player p) {
        int next = (weaponIndex.getOrDefault(p.getUniqueId(), 0) + 1) % Weapon.values().length;
        weaponIndex.put(p.getUniqueId(), next);
        Weapon w = Weapon.values()[next];
        refreshIcons(p);
        p.sendMessage(net.kyori.adventure.text.Component.text("Cursed Tool: " + w.label + " - moveset swapped (keys 1-4). Hover the icons for details.", net.kyori.adventure.text.format.NamedTextColor.GREEN));
        p.playSound(p.getLocation(), "item.armor.equip_netherite", 1f, 1.2f);
        plugin.bridge().spawnModel(p.getLocation(), switch (next) {
            case 0 -> "inverted_spear_of_heaven";
            case 1 -> "playful_cloud";
            default -> "split_soul_katana";
        }, "anim_draw");
    }

    // ------------------------------------------------------------------
    private void isohThrust(Player p) {
        if (mobilitySealed(p)) return;
        Vector dir = p.getEyeLocation().getDirection().setY(0).normalize();
        Location cur = p.getLocation();
        for (int i = 0; i < 5; i++) {
            Location next = cur.clone().add(dir);
            if (!next.getBlock().isPassable()) break;
            cur = next;
        }
        cur.setDirection(dir);
        p.teleport(cur);
        fx().afterimage(p);
        LivingEntity target = fx().target(p, 4.5);
        if (target != null) {
            DamageFlags.markIsoh(target.getUniqueId());
            fx().hit(target, 6.0, p, false, true);
            target.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, target.getLocation().add(0, 1, 0), 15, 0.3, 0.5, 0.3, 0.15);
        }
        p.playSound(p.getLocation(), "item.trident.throw", 1f, 1.6f);
    }

    private void chainWhip(Player p) {
        LivingEntity target = fx().target(p, 22);
        if (target != null) {
            // Whip: pull the enemy to Toji.
            fx().line(p.getEyeLocation(), target.getLocation().toVector().subtract(p.getEyeLocation().toVector()),
                    target.getLocation().distance(p.getLocation()), Color.fromRGB(160, 160, 170), 0.4);
            Vector pull = p.getLocation().toVector().subtract(target.getLocation().toVector()).normalize().multiply(1.8);
            target.setVelocity(pull.setY(0.4));
            fx().hit(target, 3.0, p, false, false);
            p.playSound(p.getLocation(), "entity.fishing_bobber.retrieve", 1f, 0.6f);
        } else {
            // Grapple to a wall / ledge.
            if (mobilitySealed(p)) return;
            RayTraceResult rt = p.getWorld().rayTraceBlocks(p.getEyeLocation(), p.getEyeLocation().getDirection(), 22);
            if (rt == null || rt.getHitPosition() == null) {
                plugin.energy().flash(p, "Â§cChain found no anchor within 22 blocks");
                plugin.cooldowns().reset(p, "toji:1s");
                return;
            }
            Location anchor = rt.getHitPosition().toLocation(p.getWorld());
            fx().line(p.getEyeLocation(), anchor.toVector().subtract(p.getEyeLocation().toVector()),
                    anchor.distance(p.getLocation()), Color.fromRGB(160, 160, 170), 0.4);
            Vector pull = anchor.toVector().subtract(p.getLocation().toVector()).normalize().multiply(2.2);
            p.setVelocity(pull.setY(Math.max(0.35, pull.getY())));
            noFallUntil.put(p.getUniqueId(), System.currentTimeMillis() + 4000);
            p.playSound(p.getLocation(), "entity.fishing_bobber.throw", 1f, 0.8f);
        }
    }

    // ------------------------------------------------------------------
    // Chains: move 5 (bind) + move 6 (follow-up)
    // ------------------------------------------------------------------
    private void spearPierce(Player p, boolean longBind) {
        LivingEntity t = fx().target(p, 24);
        if (t == null) {
            plugin.energy().flash(p, "§cSpear Pierce found no target in sight");
            plugin.cooldowns().reset(p, longBind ? "toji:5s" : "toji:5");
            return;
        }
        Vector dir = t.getEyeLocation().toVector().subtract(p.getEyeLocation().toVector());
        double len = dir.length();
        fx().line(p.getEyeLocation(), dir.clone().normalize(), len, Color.fromRGB(190, 195, 205), 0.35);
        fx().hit(t, 4.0, p, false, false);

        int sec = plugin.getConfig().getInt("toji-chain.debuff-seconds", 8);
        t.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, sec * 20, 1));
        t.addPotionEffect(new PotionEffect(PotionEffectType.HUNGER, sec * 20, 1));

        UUID victimId = t.getUniqueId();
        for (int i = 1; i <= bleedTicks(); i++) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (Bukkit.getEntity(victimId) instanceof LivingEntity le && le.isValid()) {
                    fx().hit(le, 0.8, p, true, false);
                    le.getWorld().spawnParticle(Particle.DUST, le.getLocation().add(0, 1, 0), 4,
                            0.2, 0.3, 0.2, new Particle.DustOptions(Color.fromRGB(160, 20, 20), 1f));
                }
            }, i * 20L);
        }

        plugin.chains().bind(p, t, cuffMs() * (longBind ? 2L : 1L));
        refreshIcons(p);
        p.sendMessage(Component.text("Target chained! ", NamedTextColor.GOLD)
                .append(Component.text("[7] Slam  |  Shift+[7] Throw  |  look around to drag them", NamedTextColor.GRAY)));
        p.playSound(p.getLocation(), "entity.fishing_bobber.retrieve", 1f, 0.7f);
    }

    private void chainSlam(Player p) {
        LivingEntity t = plugin.chains().victim(p);
        if (t == null) {
            plugin.energy().flash(p, "§cNo chained target - land Spear Pierce first");
            plugin.cooldowns().reset(p, "toji:6");
            return;
        }
        if (mobilitySealed(p)) return;

        Vector to = t.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
        if (to.lengthSquared() < 0.01) to = p.getEyeLocation().getDirection().setY(0).clone();
        to.normalize();
        Location land = t.getLocation().clone().subtract(to.clone().multiply(1.0));
        land.setDirection(to);
        p.teleport(land);
        p.setVelocity(new Vector(0, 1.1, 0));
        fx().afterimage(p);

        UUID victimId = t.getUniqueId();
        UUID ownerId = p.getUniqueId();
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!plugin.chains().hasVictim(ownerId)) return;
            if (!(Bukkit.getEntity(victimId) instanceof LivingEntity le) || !le.isValid()) return;
            boolean crit = Math.random() < critChance();
            double damage = crit ? le.getHealth() * 0.95 : 18.0;
            fx().hit(le, damage, p, true, true);

            le.getWorld().playSound(le.getLocation(), "item.mace.smash", 1.6f, 0.6f);
            p.playSound(p.getLocation(), "entity.player.attack.strong", 1f, 0.8f);
            le.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, le.getLocation().add(0, 1, 0), 1);
            fx().expandingRings(le.getLocation(), crit ? Color.fromRGB(220, 40, 40) : Color.GRAY, 4);

            int sec = debuffSeconds(crit);
            int amp = crit ? 2 : 0;
            le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, sec * 20, amp));
            le.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, sec * 20, amp));
            le.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, sec * 20, amp));
            if (crit) {
                p.sendMessage(Component.text("CRITICAL CHAIN SLAM! ", NamedTextColor.GOLD, TextDecoration.BOLD)
                        .append(Component.text("95% HP + level 3 debuffs for 30s", NamedTextColor.RED)));
            }
            plugin.chains().release(ownerId);
            refreshIcons(p);
        }, 8L);
    }

    private void chainThrow(Player p) {
        LivingEntity t = plugin.chains().victim(p);
        if (t == null) {
            plugin.energy().flash(p, "§cNo chained target to throw");
            plugin.cooldowns().reset(p, "toji:6s");
            return;
        }
        Vector dir = p.getEyeLocation().getDirection();
        t.setVelocity(dir.clone().multiply(3.2).setY(1.1));
        fx().hit(t, 6.0, p, true, false);
        fx().dust(t.getLocation().add(0, 1, 0), Color.GRAY, 1.2f, 12, 0.5);
        p.playSound(p.getLocation(), "entity.generic.explode", 1f, 0.8f);
        p.sendMessage(Component.text("Chained target thrown away.", NamedTextColor.YELLOW));
        plugin.chains().release(p.getUniqueId());
        refreshIcons(p);
    }

    // ------------------------------------------------------------------
    // Weapon-specific strikes
    // ------------------------------------------------------------------
    private void spearSweep(Player p) {
        Vector dir = p.getEyeLocation().getDirection().setY(0).normalize();
        Location c = p.getLocation().add(dir.clone().multiply(2));
        fx().line(p.getEyeLocation(), dir, 7, Color.fromRGB(120, 210, 255), 0.4);
        fx().aoe(c, 4.5, 7.0, p, false, false, le -> le.setVelocity(
                le.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0).normalize().multiply(1.6).setY(0.7)));
        p.playSound(p.getLocation(), "item.trident.throw", 1f, 1.3f);
    }

    private void soulLock(Player p) {
        LivingEntity t = fx().target(p, 10);
        if (t == null) {
            plugin.energy().flash(p, "§cSoul Lock found no target");
            plugin.cooldowns().reset(p, "toji:3");
            return;
        }
        DamageFlags.markIsoh(t.getUniqueId());
        fx().hit(t, 11.0, p, true, true);
        fx().dust(t.getLocation().add(0, 1, 0), Color.fromRGB(200, 230, 255), 1.4f, 14, 0.4);
        p.playSound(p.getLocation(), "entity.warden.sonic_boom", 1f, 1.5f);
    }

    private void cloudWhirl(Player p) {
        fx().aoe(p.getLocation(), 6, 9.0, p, false, false, le -> le.setVelocity(
                le.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0).normalize().multiply(2.2).setY(1.4)));
        fx().expandingRings(p.getLocation(), Color.fromRGB(210, 210, 220), 6);
        p.playSound(p.getLocation(), "entity.generic.explode", 1.2f, 0.7f);
    }

    private void groundShatter(Player p) {
        Vector dir = p.getLocation().getDirection().setY(0).normalize();
        Location c = p.getLocation().add(dir.clone().multiply(3));
        fx().aoe(c, 5, 11.0, p, false, false, le -> le.setVelocity(
                le.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0).normalize().multiply(1.4).setY(0.9)));
        if (plugin.griefing()) fx().cutSoftLine(p, c, dir, 6);
        c.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, c, 1);
        p.playSound(c, "block.anvil.land", 1.4f, 0.5f);
    }

    private void soulRend(Player p) {
        LivingEntity t = fx().target(p, 8);
        if (t == null) {
            plugin.energy().flash(p, "§cSoul Rend found no target");
            plugin.cooldowns().reset(p, "toji:1s");
            return;
        }
        for (int i = 0; i < 4; i++) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (t.isValid()) fx().hit(t, 3.5, p, true, true);
            }, i * 3L);
        }
        fx().dust(t.getLocation().add(0, 1, 0), Color.WHITE, 1.2f, 12, 0.4);
        p.playSound(p.getLocation(), "entity.player.attack.sweep", 0.6f, 1.6f);
    }

    private void iaijutsuDash(Player p) {
        if (mobilitySealed(p)) return;
        Vector dir = p.getEyeLocation().getDirection();
        fx().line(p.getEyeLocation(), dir, 9, Color.WHITE, 0.3);
        fx().afterimage(p);
        p.teleport(fx().forwardTeleport(p, 8));
        LivingEntity t = fx().target(p, 5);
        if (t != null) fx().hit(t, 10.0, p, true, true);
        p.playSound(p.getLocation(), "entity.player.attack.strong", 0.5f, 1.8f);
    }

    private void soulSever(Player p) {
        Vector dir = p.getEyeLocation().getDirection().setY(0).normalize();
        Location c = p.getLocation().add(dir.clone().multiply(2));
        fx().line(p.getEyeLocation(), dir, 8, Color.fromRGB(255, 220, 240), 0.3);
        fx().aoe(c, 5.5, 12.0, p, true, true, null);
        p.playSound(p.getLocation(), "entity.player.attack.sweep", 0.7f, 0.8f);
    }

    private void playfulCloud(Player p) {
        Location c = p.getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(2));
        p.getWorld().spawnParticle(Particle.EXPLOSION, c, 2);
        p.getWorld().playSound(c, "entity.generic.explode", 1.5f, 0.6f);
        p.getWorld().playSound(c, "block.anvil.land", 1.5f, 0.5f);
        fx().aoe(c, 4, 12.0, p, false, false, le -> {
            Vector away = le.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0).normalize();
            le.setVelocity(away.multiply(2.6).setY(1.2)); // launched through walls
        });
        fx().expandingRings(c, Color.fromRGB(200, 200, 210), 4);
        if (plugin.griefing()) fx().cutSoftLine(p, c, p.getLocation().getDirection(), 5);
    }

    private void splitSoulKatana(Player p) {
        LivingEntity target = fx().target(p, 8);
        // Silent iaijutsu vacuum blade: ignores 100% of armor and resistance.
        Location start = p.getEyeLocation();
        fx().line(start, start.getDirection(), 8, Color.fromRGB(230, 230, 240), 0.3);
        if (target != null) {
            fx().hit(target, 9.0, p, true, true);
            fx().dust(target.getLocation().add(0, 1, 0), Color.WHITE, 1f, 8, 0.3);
        }
        p.playSound(p.getLocation(), "entity.player.attack.sweep", 0.4f, 1.9f);
    }

    private void heavenlyBlitz(Player p) {
        if (mobilitySealed(p)) return;
        int c = charges(p);
        if (c <= 0) {
            plugin.energy().flash(p, "Â§cNo Blitz charges â€” recharging...");
            plugin.cooldowns().reset(p, "toji:4");
            return;
        }
        blitzCharges.put(p.getUniqueId(), c - 1);
        Vector dir = p.getEyeLocation().getDirection();
        fx().afterimage(p);
        p.setVelocity(dir.multiply(2.4).setY(Math.max(-0.2, dir.getY() * 2.4)));
        noFallUntil.put(p.getUniqueId(), System.currentTimeMillis() + 3000);
        p.getWorld().spawnParticle(Particle.SONIC_BOOM, p.getLocation().add(0, 1, 0), 1);
        p.playSound(p.getLocation(), "entity.breeze.wind_burst", 1f, 0.7f);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> fx().afterimage(p), 3L);
    }

    private void toolThrow(Player p) {
        Weapon w = weapon(p);
        ItemDisplay tool = fx().itemDisplay(p.getEyeLocation().add(p.getEyeLocation().getDirection()), w.icon, 0.9f);
        fx().register(p, tool);
        fx().orbProjectile(p, tool, p.getEyeLocation().getDirection(), 1.7, 30, 1.0,
                le -> {
                    fx().hit(le, 6.0, p, w == Weapon.SPLIT_SOUL_KATANA, false);
                    if (w == Weapon.INVERTED_SPEAR) {
                        DamageFlags.markIsoh(le.getUniqueId());
                        fx().hit(le, 0.1, p, false, true); // trigger nullification
                    }
                },
                null,
                d -> d.getWorld().spawnParticle(Particle.CRIT, d.getLocation(), 1));
        p.playSound(p.getLocation(), "item.trident.throw", 1f, 1.1f);
    }

    private void momentumSurge(Player p) {
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 80, 2));
        fx().line(p.getLocation().add(0, 1, 0), p.getLocation().getDirection().multiply(-1), 4, Color.fromRGB(120, 255, 140), 0.4);
        p.playSound(p.getLocation(), "entity.breeze.charge", 1f, 1.2f);
    }

    private void stealthStrike(Player p) {
        LivingEntity target = fx().target(p, 5);
        if (target == null) {
            plugin.energy().flash(p, "Â§cNo target for Stealth Strike");
            plugin.cooldowns().reset(p, "toji:7");
            return;
        }
        Vector targetLook = target.getLocation().getDirection().setY(0).normalize();
        Vector toToji = p.getLocation().toVector().subtract(target.getLocation().toVector()).setY(0).normalize();
        boolean behind = targetLook.dot(toToji) < -0.2;
        double dmg = behind ? 12.0 : 4.0;
        fx().hit(target, dmg, p, behind, false);
        if (behind) {
            p.sendActionBar(net.kyori.adventure.text.Component.text("BACKSTAB", net.kyori.adventure.text.format.NamedTextColor.DARK_GREEN));
            target.getWorld().spawnParticle(Particle.CRIT, target.getLocation().add(0, 1, 0), 20, 0.3, 0.4, 0.3, 0.3);
        }
        p.playSound(p.getLocation(), "entity.player.attack.strong", 0.7f, behind ? 0.6f : 1.2f);
    }

    private void inventorySnack(Player p) {
        p.setHealth(Math.min(p.getAttribute(Attribute.MAX_HEALTH).getValue(), p.getHealth() + 6));
        p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 200, 1));
        p.playSound(p.getLocation(), "entity.player.burp", 1f, 1f);
        p.getWorld().spawnParticle(Particle.HEART, p.getLocation().add(0, 2, 0), 3, 0.3, 0.2, 0.3, 0);
    }

    private void flyHead(Player p) {
        Location c = p.getLocation();
        // Hundreds of tiny cursed spirits: dense swarm of displays + particles.
        for (int i = 0; i < 12; i++) {
            Location loc = c.clone().add((Math.random() - 0.5) * 14, Math.random() * 3, (Math.random() - 0.5) * 14);
            ItemDisplay head = fx().itemDisplay(loc, Material.ROTTEN_FLESH, 0.35f);
            fx().register(p, head);
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> { if (head.isValid()) head.remove(); }, 100L);
        }
        new BukkitRunnable() {
            int ticks = 0;
            @Override public void run() {
                if (ticks++ >= 10) { cancel(); return; }
                for (int i = 0; i < 20; i++) {
                    Location loc = c.clone().add((Math.random() - 0.5) * 30, Math.random() * 4, (Math.random() - 0.5) * 30);
                    fx().dust(loc, Color.fromRGB(90, 60, 90), 1.4f, 1, 0.1);
                }
                c.getWorld().spawnParticle(Particle.SMOKE, c.clone().add(0, 1.5, 0), 60, 7, 2, 7, 0.02);
            }
        }.runTaskTimer(plugin, 0L, 5L);
        for (Entity e : p.getNearbyEntities(15, 8, 15)) {
            if (e instanceof LivingEntity le && !e.equals(p) && !plugin.summons().isOwnedSummon(p, e)) {
                if (le instanceof Player pl && plugin.characters().isTransformed(pl)) {
                    pl.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 100, 0));
                    pl.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 120, 0));
                } else if (e instanceof Mob mob) {
                    mob.setTarget(null); // break target locks
                    mob.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 100, 0));
                }
            }
        }
        p.playSound(c, "entity.vex.ambient", 2f, 0.5f);
    }

    private void predatorInstinct(Player p) {
        long ms = plugin.getConfig().getLong("domains.toji-predator-seconds", 8) * 1000L;
        plugin.domains().grantPredator(p, ms);
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, (int) (ms / 50), 4));
        for (Entity e : p.getNearbyEntities(30, 16, 30)) {
            if (e instanceof LivingEntity le && !e.equals(p)) {
                le.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, (int) (ms / 50), 0));
            }
        }
        p.sendMessage(net.kyori.adventure.text.Component.text("Predator Instinct â€” domain sure-hits cannot touch you (8s)", net.kyori.adventure.text.format.NamedTextColor.DARK_GREEN));
        p.playSound(p.getLocation(), "entity.warden.agitated", 1f, 1.6f);
        fx().dust(p.getLocation().add(0, 1, 0), Color.fromRGB(60, 200, 90), 1.6f, 20, 0.5);
    }

    @Override public boolean onLeftClick(Player p) {
        // Toji's bare-handed fist punch: mace-smash sound, 3s stun, blind on crit.
        return fistImpact(p);
    }

    /**
     * Toji's bare-handed fist punch: mace-smash sound, 3s stun, blind on crit.
     * A crit is triggered when the target is already slowed or stunned.
     */
    private boolean fistImpact(Player p) {
        LivingEntity target = fx().target(p, 3.5);
        if (target == null) return false;
        boolean crit = target.hasPotionEffect(PotionEffectType.SLOWNESS)
                || target.hasPotionEffect(PotionEffectType.BLINDNESS)
                || (target instanceof Player pl && plugin.domains().isStunned(pl));
        double dmg = crit ? 12.0 : 5.0;
        fx().hit(target, dmg, p, false, false);
        // Mace smash sound on fist hit
        target.getWorld().playSound(target.getLocation(), "item.armor.equip_netherite", 1.6f, 0.4f);
        p.playSound(p.getLocation(), "entity.player.attack.strong", 0.8f, 1.1f);
        // Particles
        target.getWorld().spawnParticle(Particle.SWEEP_ATTACK, target.getLocation().add(0, 1, 0), 4, 0.4, 0.6, 0.4, 0);
        fx().dust(target.getLocation().add(0, 1, 0), Color.fromRGB(255, 255, 255), 1.5f, 10, 0.3);
        if (crit) {
            // 3 second stun + blindness
            target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 4));
            target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 1));
            target.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 40, 0));
            p.sendActionBar(net.kyori.adventure.text.Component.text("CRITICAL FIST!", net.kyori.adventure.text.format.NamedTextColor.GOLD));
            target.getWorld().spawnParticle(Particle.ENCHANT, target.getLocation().add(0, 1, 0), 30, 0.6, 1.2, 0.6, 0.15);
            target.getWorld().spawnParticle(Particle.REVERSE_PORTAL, target.getLocation().add(0, 1, 0), 20, 0.5, 0.9, 0.5, 0.1);
        }
        return true;
    }
}

