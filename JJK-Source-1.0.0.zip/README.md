# JJK — Jujutsu Kaisen Combat Plugin

**Paper 1.21.11 · Java 21 · 5 characters · 60+ skills · Domains · Summons · BetterModel-ready**

A complete character-combat plugin implementing Satoru Gojo, Ryomen Sukuna, Megumi
Fushiguro, Yuji Itadori and Toji Fushiguro with a shared instant-cast core:
locked hotbar abilities, Shift variants, silent command keybinds, Cursed
Energy / Stamina gauges, millisecond cooldowns, crash-safe inventory backups
and Display-entity VFX synced with BetterModel animation IDs.

---

## 1. Requirements & Install

| Requirement | Version |
|---|---|
| Server | Paper **1.21.11** (or compatible 1.21.x build) |
| Java | **21+** |
| Optional | [BetterModel](https://github.com/toxicity188/BetterModel) for 3D rigs/animations |

1. Drop `JJK-1.0.beta.6.jar` into `plugins/`.
2. Start the server. Config, model files and the backup folder are generated:
   ```
   plugins/JJK/config.yml
   plugins/JJK/messages.yml            (all help text + ability tooltips, see §6b)
   plugins/JJK/patches.yml             (patch-note book contents)
   plugins/JJK/backups/<uuid>.yml      (created per transformation)
   plugins/JJK/models/*.bbmodel        (placeholder rigs, see §7)
   plugins/JJK/resourcepack/           (upload as a server resource pack, see §6b)
   ```
3. Optional: install BetterModel and copy the `.bbmodel` files into its model
   folder. Without BetterModel everything still works with particle/Display
   fallbacks.

## 2. Quick Start

```
/jjk menu                          ← click a character icon
/jjk transform gojo                ← or type it directly
/jjk give finger Steve             ← admin: give a Cursed Object (right-click to transform)
/jjk leave                         ← exit & restore your exact survival inventory
```

On transform your inventory/armor/offhand/XP are backed up **to memory and to
`plugins/JJK/backups/<uuid>.yml` before anything is touched** (disk write is
async by default). Keys **1–6** become unmovable ability icons, **key 9** is
the exit button, and a BossBar + ActionBar gauge shows your Cursed Energy
(Stamina for Toji). Every icon has a tooltip explaining **what it does, how to
cast it, and its variant**. Type `/jjk help` for the full control list and
`/jjk help <character>` for a character's moveset. On join (and on reload) a
gold clickable **"Patchs & Feed Backs"** message appears — click it to open an
in-game book of the latest changes.

Exiting (key **9**, `/jjk leave`, quit, death, or server shutdown) restores
your exact items. If the server **crashes** mid-transformation, the leftover
YAML backup is auto-restored on your next join. Admins can force it with
`/jjk restore <player>`.

## 3. Dual Keybind System

### Method A — Vanilla inputs (no client mods)

| Input | Paper event | Result |
|---|---|---|
| `1–4` | `PlayerItemHeldEvent` (cancelled) | Instant-cast Skill 1–4 (normal form, or ultimate form when active) |
| `Shift + 1–4` | same + `isSneaking()` | Amplified / variant move |
| `5–6` | same | Extra moves (Toji: Spear Pierce + Chain Slam) |
| `9` | `PlayerItemHeldEvent` (slot index 8) | Exit transformation |
| `F` | `PlayerSwapHandItemsEvent` (cancelled) | Passive / stance toggle |
| `Shift + F` | same + `isSneaking()` | **Domain Expansion** (Toji: Predator Instinct) |
| `Q` | `PlayerDropItemEvent` (cancelled) | **Character ultimate technique** (Purple, Fuga, Mahoraga, Soul Dismantle, Fly Head) |
| `Shift + Q` | same + `isSneaking()` | Forward mobility dash (10 blocks, afterimage) |
| `Right-Click icon` | `PlayerInteractEvent` | Re-cast the currently held ability |
| `Left-Click` | `PlayerAnimationEvent` / damage events | Combo hooks, Yuji Black Flash window, Gojo barrage finisher |
| **`Shift + G`** | `/jjk ultimate` (CommandKeys mod) **or** `/jjk ultimate` | **Ultimate Form toggle** — replaces your 4 normal moves with 4 new ultimate moves |

`/jjk help <character>` and `/jjk controls` print the same information in game;
all text lives in `plugins/JJK/messages.yml` and is editable without a rebuild.

### Normal Form vs Ultimate Form

- **Normal form**: you have exactly **4 moves** (keys 1–4).
- **Ultimate form**: activate via **Shift+G** (client keybind → `/jjk ultimate`)
  — your 4 normal moves are **replaced** by the form's 4 new moves, and the
  hotbar icons switch to the ultimate form's item set.
- When you deactivate the form (press Shift+G again, or it ends), the **old
  normal moves return** and the hotbar restores the normal icons.
- The same key slot can hold both a normal and an ultimate move; the controller
  swaps which `SkillDef` is active per form.

### Method B — Client command-keybind mods (R, G, V, X, Z, C…)

Bind any key in a mod like **CommandKeys** (Fabric/NeoForge) to these silent
commands. They print nothing in chat and run through the **exact same cast
gate** as the hotbar keys:

| Suggested key | Command |
|---|---|
| R | `/jjk skill 1` (Shift+R → `/jjk skill 1 shift`) |
| G | `/jjk skill 2` |
| V | `/jjk skill 3` |
| B | `/jjk skill 4` |
| T | `/jjk skill q` (ultimate technique) |
| X | `/jjk skill fs` (domain) |
| Z | `/jjk skill f` (passive) |
| C | `/jjk ultimate` (form toggle) |
| Shift | `/jjk dash` |

### BindCommands Beta Profile

BindCommands can invoke the same silent commands directly. Add these commands
to its key columns:

| Key | Command |
|---|---|
| R | `/jjk skill 1` |
| G | `/jjk skill 2` |
| V | `/jjk skill 3` |
| B | `/jjk skill 4` |
| T | `/jjk skill q` |
| X | `/jjk skill fs` |
| Z | `/jjk skill f` |
| C | `/jjk ultimate` |
| Shift+Q | `/jjk dash` |

The beta build also adds dense CRIT, SWEEP_ATTACK, and DAMAGE_INDICATOR
sharp-particle bursts to attack and projectile paths.

### The 4-step cast gate (every press)

1. **Stun / domain check** — frozen in Unlimited Void? Blocked (Toji ignores it).
2. **Cooldown check** — `Map<UUID, Map<String, Long>>` ms timestamps + vanilla
   item cooldown overlay via `player.setCooldown(material, ticks)`.
3. **CE / Stamina check** — deducts cost (Gojo gets the Six Eyes discount);
   failure = error sound + red ActionBar flash.
4. **Execution & sync** — BetterModel animation ID → Display-entity
   projectile/domain shell → damage/knockback.

## 4. Character Kits

### Satoru Gojo — Limitless & Six Eyes (1000 CE, ultra-low drain)
| Key | Skill |
|---|---|
| 1 | **Blue** — spinning orb pulls entities & loose blocks inward 3s, then implodes |
| Shift+1 | **Maximum Output: Blue** — 3.5× orbiting sphere follows your crosshair, shredding everything |
| 2 | **Red** — high-speed crimson orb, massive knockback + shockwave rings on impact |
| 3 | **Teleportation** — up to 25b toward crosshair, sonic boom + distortion |
| 4 | **Limitless Barrage** — teleport-punches; **Left-Click mid-barrage = Black Flash finisher** |
| 5 / Shift+5 | Six Eyes Scan / Overload — glowing reveal (+ Weakness) |
| 6 | Infinity Pulse — radial knockback + slow |
| 7 | Blue Scatter — triple mini-Blue implosions |
| 8 | Red Mine — proximity-detonated crimson orb |
| Q | **Hollow Purple** — Blue+Red merge; violet orb deletes blocks, true damage |
| F | **Infinity toggle** — particle barrier; deflects projectiles, slows melee (5 CE/hit) |
| Shift+F | **Unlimited Void** — 20b cosmic sphere, 10s stun + blindness inside |

### Ryomen Sukuna — Shrine (1000 CE, dark aura + markings)
| Key | Skill |
|---|---|
| 1 | **Dismantle** — razor-thin slash arcs slice enemies & cut foliage in a line |
| Shift+1 | **Dismantle Net** — palm slam, 10b intersecting slash grid + terrain shatter |
| 2 | **Cleave** — dash-grab, 5 rapid cuts scaling with enemy armor & missing HP |
| 3 | **World Cutting Slash** — chant, then unblockable spatial slash (bypasses Infinity/armor) |
| 4 | **RCT** — white steam + soul-fire regen, clears debuffs |
| 5–8 | Aura Burst / Slash Dash / Flame Sparks / Shrine Mark (Str+Spd) |
| Q | **Fuga「Open」** — flaming bow → condensed arrow → towering inferno pillar |
| F | Cursed aura toggle (Strength I, 3 CE/s) |
| Shift+F | **Malevolent Shrine** — 3D shrine behind you; sure-hit slashes every 0.25s, 25b |

### Megumi Fushiguro — Ten Shadows (800 CE, liquid shadow at feet)
| Key | Skill |
|---|---|
| 1 | **Divine Dogs: Totality** — wolf shikigami, lunges + bleed |
| 2 | **Nue** — flying shikigami, lightning strikes + paralysis on hit |
| 3 | **Toad** — tongue tether pulls enemies to you |
| 4 | **Shadow Step** — shadow pool, invisibility + Speed IV 4s |
| 5–8 | Rabbit Escape / Max Elephant / Piercing Ox / Round Deer (ally heal aura) |
| Q | **Mahoraga** — Divine General with spinning Dharma wheel; **adapts to repeated damage types** (−15%/hit, min 10%) |
| F | Shadow Veil toggle (Speed II) |
| Shift+F | **Chimera Shadow Garden** — 20b darkness, shadow clones, **double summons** |

### Yuji Itadori — Divergent Fist / Blood / Shrine (600 CE)
Passive: permanent **Speed II, Jump Boost II, Resistance I**. Any skill cast
opens a **0.25s Black Flash window** — land a left-click hit inside it for
**2.5× damage**, black-red lightning sparks and a CE refill.

| Key | Skill |
|---|---|
| 1 | **Divergent Fist** — physical knockback, then delayed CE shockwave 0.4s later |
| Shift+1 | **Guaranteed Black Flash** — heavy CE uppercut, forced spatial distortion |
| 2 | **Manji Kick** — 1.5s stance: negates melee, counters with a flying kick |
| 3 | **Piercing Blood** — pressurized crimson beam, pierces multiple targets |
| 4 | **Blood Stitch (RCT)** — regen + clears poison/wither/slowness |
| 5–8 | Cursed Strikes / Blood Edge / Blood Burst / Shrine Awakening (soul cuts on melee) |
| Q | **Soul-Seizing Dismantle** — armor-bypassing palm grab, drains 50 enemy CE |
| F | Focus — Black Flash window doubled to 0.5s for 5s |
| Shift+F | **Hometown** — snowy domain: enemy mobility skills sealed, your hits guaranteed |

### Toji Fushiguro — Heavenly Restriction (0 CE → 100 Stamina)
Stamina recharges while **sprinting** and **landing hits**. Walks through domain
barriers, immune to Unlimited Void stun, sees invisible players (glowing).
**Pressing F cycles his cursed tool AND swaps the entire 1–4 moveset and icons:**

| Tool | 1 | Shift+1 | 2 | 3 |
|---|---|---|---|---|
| Inverted Spear | Nullify Thrust | Chain of a Thousand Miles | Spear Sweep | Soul Lock |
| Playful Cloud | Cataclysm Smash | Cloud Whirl | Momentum Surge | Ground Shatter |
| Split Soul Katana | True Slash | Soul Rend | Iaijutsu Dash | Soul Sever |

Key 4 (Heavenly Blitz), Q, F and Shift+F stay the same across tools. The
Inventory Curse floats overhead.

**New chain combo (keys 5 & 6, shared by every tool):**

| Key | Skill |
|---|---|
| `5` | **Spear Pierce** — fast chain shot. On hit: bleed, Weakness, Hunger and a **10s cuff** (target cannot move, use items or cast). Move your view to **drag** them toward your crosshair. Shift+5 = 20s snare. |
| `6` | **Chain Slam** — *locked until key 5 hits*. Lunge, leap, then a mace heavy strike that **ignores armor entirely**. 20% crit: **95% of their HP** plus level-3 Slow/Weak/Blind for 30s. Shift+6 = throw them away. |

Tune the chain mechanics under `toji-chain:` in `config.yml`.

| Key | Skill |
|---|---|
| 1 | **ISOH Nullify Thrust** — stab dispels techniques: Infinity, orbs, summons, domains |
| Shift+1 | **Chain of a Thousand Miles** — 22b whip: pull enemies or grapple to walls |
| 2 | **Playful Cloud** — AoE blunt slam, launches enemies through walls |
| 3 | **Split Soul Katana** — silent iaijutsu, ignores 100% of armor & resistance |
| 4 | **Heavenly Blitz** — air/ground dash, 3 charges (1/4s recharge), afterimages, no fall damage |
| 5 / Shift+5 | **Spear Pierce / Chain Snare** — chain shot, bleed + 10s cuff (above) |
| 6 / Shift+6 | **Chain Slam / Chain Throw** — locked until Spear Pierce hits (above) |
| Ultimate form | Tool Throw / Momentum Surge / Stealth Strike (backstab ×3) / Inventory snack |
| Q | **Fly Head Smokescreen** — 15b swarm cloud: blindness + mob target-locks broken |
| F | Cycle cursed tool (ISOH → Playful Cloud → Split Soul Katana) |
| Shift+F | **Predator Instinct** — 8s Speed V, full domain sure-hit immunity, wallhack glow |

## 5. Commands & Permissions

```
/jjk transform <gojo|sukuna|megumi|yuji|toji>   jjk.use
/jjk leave | /jjk menu | /jjk help | /jjk controls      jjk.use
/jjk help <character>        (full character moveset)    jjk.use
/jjk patches                 (open the patch notes book)  jjk.use
/jjk skill <1-6|q|f|fs> [shift] | domain | passive | ultimate | dash   (silent)
/jjk reload                  (config + messages)         jjk.admin
/jjk give <finger|blindfold|seal|blood|curse> [player]   jjk.admin
/jjk restore <player>        (force backup recovery)     jjk.admin
```

## 6. Configuration Highlights (`config.yml`)

- Per-character CE pools & regen, Six Eyes cost multiplier, stance drains.
- Black Flash window / multiplier / refill.
- Domain radii, duration, shrine slash damage & period, shell density.
- `griefing.enabled` — gate for all terrain modification (Purple, Net, Fuga).
  Protection plugins are respected via synthetic `BlockBreakEvent`s.
- `skills.<char>.<key>.cost / .cooldown-ms` — override **any** skill, e.g.:
  ```yaml
  skills:
    gojo:
      q: { cost: 250, cooldown-ms: 45000 }
  ```
- HUD toggles, pickup blocking, armor visuals, crash recovery, optional
  resource-pack item models (`jjk:<char>_<key>`).
- `sounds.*` — remap every sound event to a vanilla or custom resource-pack
  sound; `sounds.enabled` toggles them globally.
- `resource-pack.generate` — write a ready-to-upload pack scaffold on startup.
- `transform.async-backup-write` — keep backup disk writes off the main thread.

## 6b. Messages, Sounds & Resource Pack

- **Help / messages:** everything `/jjk help` prints, plus every ability
  tooltip (`notes.<char>.<key>`, split with `|` into What / How / Variant), is in
  `plugins/JJK/messages.yml` (`&`-colour codes). `/jjk reload` reloads it.
- **Patch notes:** `plugins/JJK/patches.yml` holds the book pages shown by the
  clickable "Patchs & Feed Backs" word on join/reload. Set `enabled: false` to
  hide it, or edit `latest.version` / `latest.pages` for your own server.
- **Sounds:** `util/Sounds.java` centralises every sound event. Defaults are
  vanilla sounds; set e.g. `sounds.transform: "jjk.transform"` to use a custom
  pack sound. Skill damage/VFX itself still lives in `util/FX.java`.
- **Resource pack:** on first start the plugin writes
  `plugins/JJK/resourcepack/` containing `pack.mcmeta`, one item model per
  ability (`jjk/<char>_<key>.json`), and `sounds.json` mapping the `jjk.*`
  events to vanilla sounds. Zip the folder contents and upload it as a server
  pack. See `plugins/JJK/resourcepack/README.txt` for adding your own PNG/OGG
  assets. Set `transform.custom-item-models: true` to apply the item models.

## 7. BetterModel & the .bbmodel Assets

`plugins/JJK/models/` ships **placeholder rigs** (valid Blockbench JSON) with
every animation ID wired in the code:

`jjk_player` (all 30 cast animations), `divine_dog`, `nue`, `mahoraga`,
`sukuna_shrine`, `inverted_spear`, `playful_cloud`, `split_soul_katana`.

They are grey-box placeholders — replace them with your finished rigs in
Blockbench, keeping the animation names. The plugin talks to BetterModel
through `util/BetterModelBridge.java` (reflective soft-depend). If the API
can't be bound it logs once and falls back to particles + Display entities,
so combat never breaks. To hard-bind your exact BetterModel version, replace
the reflective calls in that one class with direct API calls.

## 8. Building From Source

```
cd jjk-plugin
   mvn package          # requires JDK 21; produces target/JJK-1.0.beta.6.jar
```

Project layout:
```
dev.jjk
├── JJKPlugin            bootstrap / wiring
├── character/           CharacterType, CharacterManager, InventoryBackup
├── combat/              cast gate, input listener, passives, energy, cooldowns
├── domain/              DomainManager (void stun, shrine, garden, hometown)
├── skills/              Gojo / Sukuna / Megumi / Yuji / Toji controllers
├── summon/              shikigami AI, Mahoraga adaptation, shadow clones
├── util/                FX (Display VFX engine), BetterModelBridge
├── gui/ command/ item/  menu, /jjk router, cursed objects
```

## 9. Design Notes & Limits

- All numbers (damage/cost/cooldown/radius) are first-pass balance values —
  tune them in `config.yml` without recompiling.
- Summon AI uses real mobs (wolf/vex/slime/golem) so pathfinding & targeting
  are vanilla-quality; BetterModel rigs are cosmetic overlays.
- "Pulls blocks" (Blue) converts loose terrain to FallingBlocks only when
  griefing is enabled and protection plugins allow it.
- Placeholder rigs are grey boxes; final character art is your asset pipeline.
- The plugin never touches the backup YAML except on transform/exit/recovery,
  so items survive crashes, deaths, quits and `/reload`-style shutdowns.
