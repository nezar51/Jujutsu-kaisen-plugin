package dev.jjk.combat;

import dev.jjk.JJKPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Toji's chain cuff: a hit with Spear Pierce binds the victim for a short
 * window. The victim cannot walk or use items, and looking around with Toji
 * drags the chained player toward his crosshair.
 */
public final class ChainManager implements Listener {

    private final JJKPlugin plugin;
    private final Map<UUID, Chain> byVictim = new HashMap<>();
    private final Map<UUID, UUID> victimByOwner = new HashMap<>();

    private static final class Chain {
        final UUID owner;
        final UUID victim;
        final long until;
        float yaw;
        float pitch;
        Chain(UUID owner, UUID victim, long until, float yaw, float pitch) {
            this.owner = owner; this.victim = victim; this.until = until;
            this.yaw = yaw; this.pitch = pitch;
        }
    }

    public ChainManager(JJKPlugin plugin) { this.plugin = plugin; }

    public void bind(Player owner, LivingEntity victim, long durationMs) {
        release(owner.getUniqueId());
        long until = System.currentTimeMillis() + durationMs;
        byVictim.put(victim.getUniqueId(),
                new Chain(owner.getUniqueId(), victim.getUniqueId(), until,
                        owner.getLocation().getYaw(), owner.getLocation().getPitch()));
        victimByOwner.put(owner.getUniqueId(), victim.getUniqueId());
    }

    public boolean isChained(UUID victim) {
        Chain c = byVictim.get(victim);
        return c != null && c.until > System.currentTimeMillis();
    }

    public boolean hasVictim(UUID owner) {
        UUID v = victimByOwner.get(owner);
        return v != null && isChained(v);
    }

    public LivingEntity victim(Player owner) {
        UUID id = victimByOwner.get(owner.getUniqueId());
        if (id == null || !isChained(id)) return null;
        if (Bukkit.getEntity(id) instanceof LivingEntity le && le.isValid()) return le;
        return null;
    }

    public void release(UUID owner) {
        UUID v = victimByOwner.remove(owner);
        if (v != null) byVictim.remove(v);
    }

    public long remaining(UUID owner) {
        UUID v = victimByOwner.get(owner);
        if (v == null) return 0;
        Chain c = byVictim.get(v);
        return c == null ? 0 : Math.max(0, c.until - System.currentTimeMillis());
    }

    public void startTicker() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            long now = System.currentTimeMillis();
            List<Chain> expired = new ArrayList<>();
            for (Chain c : new ArrayList<>(byVictim.values())) if (c.until <= now) expired.add(c);
            for (Chain c : expired) {
                byVictim.remove(c.victim);
                victimByOwner.remove(c.owner);
                Player owner = Bukkit.getPlayer(c.owner);
                if (owner == null) continue;
                CharacterController ctrl = plugin.characters().controller(owner);
                if (ctrl != null) ctrl.refreshIcons(owner);
            }
            victimByOwner.values().removeIf(id -> !byVictim.containsKey(id));
            for (Chain c : byVictim.values()) {
                Player owner = Bukkit.getPlayer(c.owner);
                LivingEntity v = Bukkit.getEntity(c.victim) instanceof LivingEntity le ? le : null;
                if (owner == null || v == null || !v.isValid()) continue;
                Location a = owner.getLocation().add(0, 1.1, 0);
                Location b = v.getLocation().add(0, 1.0, 0);
                if (a.getWorld() != b.getWorld() || a.distance(b) > 30) continue;
                Vector step = b.toVector().subtract(a.toVector()).multiply(0.12);
                Location cur = a.clone();
                for (int i = 0; i < 8; i++) {
                    cur.getWorld().spawnParticle(Particle.DUST, cur, 1, 0, 0, 0,
                            new Particle.DustOptions(Color.fromRGB(180, 190, 205), 1f));
                    cur.add(step);
                }
            }
        }, 2L, 2L);
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        if (isChained(p.getUniqueId())) {
            Location from = e.getFrom();
            Location to = e.getTo();
            if (to == null) return;
            if (from.getBlockX() != to.getBlockX() || from.getBlockY() != to.getBlockY()
                    || from.getBlockZ() != to.getBlockZ()) {
                e.setCancelled(true);
                p.sendActionBar(net.kyori.adventure.text.Component
                        .text("CHAINED - you cannot move", net.kyori.adventure.text.format.NamedTextColor.RED));
            }
            return;
        }
        if (!hasVictim(p.getUniqueId())) return;
        LivingEntity v = victim(p);
        if (v == null || v.getWorld() != p.getWorld()) return;

        Chain c = byVictim.get(v.getUniqueId());
        Location to = e.getTo();
        if (to == null) return;
        boolean turned = Math.abs(to.getYaw() - c.yaw) > 4f || Math.abs(to.getPitch() - c.pitch) > 4f;
        if (!turned) return;
        c.yaw = to.getYaw();
        c.pitch = to.getPitch();
        if (p.getLocation().distance(v.getLocation()) > 30) return;

        Vector dir = p.getEyeLocation().getDirection();
        double dist = Math.min(20, v.getLocation().distance(p.getLocation()));
        Location dest = p.getEyeLocation().clone().add(dir.clone().multiply(dist));
        Vector pull = dest.toVector().subtract(v.getLocation().toVector());
        if (pull.length() > 0.6) {
            double step = Math.min(2.0, pull.length());
            v.teleport(v.getLocation().clone().add(pull.normalize().multiply(step)));
            v.getWorld().spawnParticle(Particle.CRIT, v.getLocation().add(0, 1, 0), 6, 0.3, 0.5, 0.3, 0.05);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (isChained(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (isChained(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        release(e.getPlayer().getUniqueId());
        byVictim.remove(e.getPlayer().getUniqueId());
    }

    public void shutdown() {
        byVictim.clear();
        victimByOwner.clear();
    }
}
