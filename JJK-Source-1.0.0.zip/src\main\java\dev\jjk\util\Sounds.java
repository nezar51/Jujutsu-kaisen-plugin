package dev.jjk.util;

import dev.jjk.JJKPlugin;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;

/**
 * Central sound registry. Each semantic key maps to a vanilla sound by default
 * and can be overridden in config.yml (`sounds.<key>`) to any sound name,
 * including custom ones from the generated JJK resource pack (e.g.
 * `jjk.transform`). See the resource pack README for adding your own .ogg files.
 */
public final class Sounds {

    public static final String TRANSFORM = "transform";
    public static final String EXIT = "exit";
    public static final String DASH = "dash";
    public static final String CAST = "cast";
    public static final String ULTIMATE = "ultimate";
    public static final String DOMAIN = "domain";
    public static final String BLACK_FLASH = "black_flash";

    private static final java.util.Map<String, String> DEFAULTS = java.util.Map.of(
            TRANSFORM, "block.beacon.activate",
            EXIT, "block.beacon.deactivate",
            DASH, "entity.enderman.teleport",
            CAST, "entity.player.attack.strong",
            ULTIMATE, "entity.warden.sonic_boom",
            DOMAIN, "entity.warden.sonic_boom",
            BLACK_FLASH, "entity.lightning_bolt.thunder"
    );

    private final JJKPlugin plugin;

    public Sounds(JJKPlugin plugin) { this.plugin = plugin; }

    public String resolve(String key) {
        return plugin.getConfig().getString("sounds." + key,
                DEFAULTS.getOrDefault(key, "block.note_block.bell"));
    }

    public void play(Player p, String key, float volume, float pitch) {
        if (!plugin.getConfig().getBoolean("sounds.enabled", true)) return;
        p.playSound(p.getLocation(), resolve(key), SoundCategory.PLAYERS, volume, pitch);
    }

    public void play(Player p, String key) { play(p, key, 1f, 1f); }

    /** Every sound key and its resolved value - used to document/generate the pack. */
    public java.util.Map<String, String> all() {
        java.util.Map<String, String> out = new java.util.LinkedHashMap<>();
        DEFAULTS.forEach((k, v) -> out.put(k, resolve(k)));
        return out;
    }
}
