package dev.jjk.util;

import dev.jjk.JJKPlugin;
import dev.jjk.character.CharacterType;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Soft-dependency bridge to BetterModel (https://github.com/toxicity188/BetterModel).
 *
 * BetterModel's API surface changes between builds, so this bridge binds
 * reflectively and degrades gracefully: if BetterModel is missing (or its API
 * moved), every animation falls back to vanilla arm-swing + particles and every
 * model falls back to Display entities, so combat never breaks.
 *
 * To hard-bind a specific BetterModel version, replace the reflective calls in
 * applyModel / play / spawnModel with direct API calls — the rest of the plugin
 * only talks to this class.
 */
public final class BetterModelBridge {

    private final JJKPlugin plugin;
    private final boolean available;
    private boolean warned = false;
    private final Map<UUID, String> appliedModels = new HashMap<>();

    private Object apiEntry;      // BetterModel API root, if resolved
    private Method playMethod;    // resolved animation method, if any

    public BetterModelBridge(JJKPlugin plugin) {
        this.plugin = plugin;
        boolean present = plugin.getServer().getPluginManager().getPlugin("BetterModel") != null
                && plugin.getConfig().getBoolean("bettermodel.enabled", true);
        boolean bound = false;
        if (present) {
            try {
                // Known entry points across BetterModel builds.
                String[] candidates = {
                        "kr.toxicity.model.api.BetterModel",
                        "kr.toxicity.model.api.BetterModelApi",
                        "kr.toxicity.model.api.BetterModelProvider"
                };
                for (String cn : candidates) {
                    try {
                        Class<?> clazz = Class.forName(cn);
                        apiEntry = clazz;
                        bound = true;
                        break;
                    } catch (ClassNotFoundException ignored) { }
                }
            } catch (Throwable t) {
                bound = false;
            }
        }
        this.available = bound;
    }

    public boolean isAvailable() { return available; }

    /** Applies the character rig/outfit to the player. */
    public void applyModel(Player p, CharacterType type) {
        String model = plugin.getConfig().getString("bettermodel.player-model", "jjk_player");
        appliedModels.put(p.getUniqueId(), model + ":" + type.id());
        if (available) {
            try {
                // BetterModel: register/apply the player model variant. Reflective best-effort.
                Method m = findStatic((Class<?>) apiEntry, "model", Player.class);
                if (m != null) {
                    Object tracker = m.invoke(null, p);
                    if (tracker != null) {
                        Method create = findStatic((Class<?>) apiEntry, "create", String.class);
                        if (create != null) create.invoke(null, model);
                    }
                }
                return;
            } catch (Throwable t) {
                warnOnce(t);
            }
        }
        // Fallback: aura burst so the transformation still reads visually.
        p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1, 0), 30, 0.4, 0.8, 0.4, 0.05);
    }

    public void removeModel(Player p) {
        appliedModels.remove(p.getUniqueId());
        if (available) {
            try {
                Method m = findStatic((Class<?>) apiEntry, "remove", Player.class);
                if (m != null) m.invoke(null, p);
                return;
            } catch (Throwable t) {
                warnOnce(t);
            }
        }
    }

    /** Plays a named animation (anim_point, anim_flick, ...) on the player. */
    public void play(Player p, String animationId) {
        if (animationId == null) return;
        if (available) {
            try {
                if (playMethod == null) {
                    playMethod = findStatic((Class<?>) apiEntry, "playAnimation", Player.class, String.class);
                }
                if (playMethod != null) {
                    playMethod.invoke(null, p, animationId);
                    return;
                }
            } catch (Throwable t) {
                warnOnce(t);
            }
        }
        if (plugin.getConfig().getBoolean("bettermodel.fallback-particles", true)) {
            p.swingMainHand();
            p.getWorld().spawnParticle(Particle.CRIT, p.getEyeLocation().add(p.getEyeLocation().getDirection()),
                    6, 0.2, 0.2, 0.2, 0.1);
        }
    }

    /**
     * Spawns a 3D summon/weapon/structure model (divine_dog.bbmodel,
     * sukuna_shrine.bbmodel, ...) at a location. Returns the BetterModel-backed
     * entity if bound, otherwise null (callers keep their Display fallback).
     */
    public Entity spawnModel(Location loc, String modelName, String animationId) {
        if (available) {
            try {
                Method m = findStatic((Class<?>) apiEntry, "spawn", Location.class, String.class);
                if (m != null) {
                    Object e = m.invoke(null, loc, modelName);
                    if (e instanceof Entity ent) {
                        play(ent, animationId);
                        return ent;
                    }
                }
            } catch (Throwable t) {
                warnOnce(t);
            }
        }
        return null;
    }

    private void play(Entity e, String animationId) {
        try {
            Method m = findStatic((Class<?>) apiEntry, "playAnimation", Entity.class, String.class);
            if (m != null) m.invoke(null, e, animationId);
        } catch (Throwable ignored) { }
    }

    private Method findStatic(Class<?> clazz, String name, Class<?>... params) {
        try {
            return clazz.getMethod(name, params);
        } catch (NoSuchMethodException e) {
            return null;
        }
    }

    private void warnOnce(Throwable t) {
        if (warned) return;
        warned = true;
        plugin.getLogger().warning("BetterModel detected but its API could not be bound ("
                + t.getClass().getSimpleName() + "). Using particle/Display fallbacks. "
                + "See README for hard-binding instructions.");
    }
}
