package dev.jjk.skills;

import dev.jjk.JJKPlugin;
import dev.jjk.character.CharacterType;
import dev.jjk.combat.CharacterController;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Megumi Fushiguro — Ten Shadows Technique.
 * 1 Divine Dogs | 2 Nue | 3 Toad | 4 Shadow Step | 5 Rabbit Escape
 * 6 Max Elephant | 7 Piercing Ox | 8 Round Deer
 * Q Mahoraga | F Shadow Veil toggle | Shift+F Chimera Shadow Garden
 */
public final class MegumiController extends CharacterController {

    private static final Color SHADOW = Color.fromRGB(10, 10, 25);
    private static final Color WATER = Color.fromRGB(40, 90, 220);

    private final Set<UUID> veil = new HashSet<>();

    public MegumiController(JJKPlugin plugin) {
        super(plugin);

        // === NORMAL FORM — 4 moves (keys 1-4) ===
        regNormal(1, false, "Divine Dogs: Totality", "anim_dog_sign", 50, 8000, this::divineDogs);
        regNormal(2, false, "Nue (Winged Shikigami)", "anim_nue_sign", 60, 10000, this::nue);
        regNormal(3, false, "Toad (Binding)", "anim_toad_sign", 45, 8000, this::toad);
        regNormal(4, false, "Shadow Step (Chimera Shadow)", "anim_dash", 40, 10000, this::shadowStep);

        // === ULTIMATE FORM — 4 moves (replaces normal moves) ===
        regUltimate(1, false, "Rabbit Escape", "anim_dog_sign", 45, 12000, this::rabbitEscape);
        regUltimate(2, false, "Max Elephant", "anim_toad_sign", 80, 15000, this::maxElephant);
        regUltimate(3, false, "Piercing Ox", "anim_dash", 55, 12000, this::piercingOx);
        regUltimate(4, false, "Round Deer (Healing Aura)", "anim_rct", 60, 15000, this::roundDeer);

        // === Techniques shared by both forms ===
        reg("q", "Eight-Handled Sword: Mahoraga", "anim_mahoraga_ritual", 250, 90000, this::mahoraga);
        reg("f", "Shadow Veil (Toggle)", "anim_dash", 0, 500, this::toggleVeil);
        reg("fs", "Domain Expansion: Chimera Shadow Garden", "anim_megumi_domain", 250, 60000,
                p -> plugin.domains().start(p, CharacterType.MEGUMI));
    }

    @Override public CharacterType type() { return CharacterType.MEGUMI; }

    @Override public Material[] normalIcons() {
        return new Material[]{Material.WOLF_SPAWN_EGG, Material.PHANTOM_MEMBRANE, Material.SLIME_BALL, Material.BLACK_DYE};
    }

    @Override public Material[] ultimateIcons() {
        return new Material[]{Material.RABBIT_FOOT, Material.WATER_BUCKET, Material.BEEF, Material.GHAST_TEAR};
    }

    private void toggleVeil(Player p) {
        boolean on = !veil.contains(p.getUniqueId());
        if (on) veil.add(p.getUniqueId()); else veil.remove(p.getUniqueId());
        p.sendMessage(net.kyori.adventure.text.Component.text("Shadow Veil " + (on ? "wraps your feet (Speed II)" : "dissipates"),
                net.kyori.adventure.text.format.NamedTextColor.DARK_PURPLE));
    }

    @Override public String status(Player p) { return veil.contains(p.getUniqueId()) ? "§5Shadow Veil" : ""; }

    @Override public double stanceDrain(Player p) {
        return veil.contains(p.getUniqueId()) ? plugin.getConfig().getDouble("energy.stance-drain.megumi", 2) : 0;
    }

    @Override public void tick(Player p) {
        // Liquid shadow particles at the feet.
        fx().dust(p.getLocation().add(0, 0.15, 0), SHADOW, 1.6f, 5, 0.35);
        if (veil.contains(p.getUniqueId())) {
            if (plugin.energy().get(p) <= 0) { veil.remove(p.getUniqueId()); return; }
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 30, 1, true, false));
        }
    }

    @Override public void onExit(Player p) { veil.remove(p.getUniqueId()); }

    // ------------------------------------------------------------------
    private void divineDogs(Player p) {
        Location loc = p.getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(2));
        plugin.summons().spawnDivineDog(p, loc);
        shadowPool(p, loc);
        p.playSound(loc, "entity.wolf.howl", 1f, 0.7f);
    }

    private void nue(Player p) {
        plugin.summons().spawnNue(p, p.getLocation());
        shadowPool(p, p.getLocation());
        p.playSound(p.getLocation(), "entity.phantom.ambient", 1f, 0.6f);
    }

    private void toad(Player p) {
        Location loc = p.getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(3));
        plugin.summons().spawnToad(p, loc);
        shadowPool(p, loc);
        LivingEntity target = fx().target(p, 15);
        if (target != null) {
            // ItemDisplay tongue tether pulls the target toward Megumi.
            ItemDisplay tongue = fx().itemDisplay(loc.clone().add(0, 1, 0), Material.SLIME_BALL, 0.6f);
            fx().register(p, tongue);
            new BukkitRunnable() {
                int ticks = 0;
                @Override public void run() {
                    if (!tongue.isValid() || !target.isValid() || ticks++ >= 12) {
                        if (tongue.isValid()) tongue.remove();
                        cancel();
                        return;
                    }
                    Location mid = loc.clone().add(target.getLocation().toVector().subtract(loc.toVector()).multiply(ticks / 12.0));
                    tongue.teleport(mid.clone().add(0, 1, 0));
                    fx().dust(mid.clone().add(0, 1, 0), Color.fromRGB(200, 60, 90), 1f, 2, 0.1);
                    Vector pull = p.getLocation().toVector().subtract(target.getLocation().toVector()).normalize().multiply(0.55);
                    target.setVelocity(target.getVelocity().add(pull.setY(0.15)));
                }
            }.runTaskTimer(plugin, 1L, 1L);
            p.playSound(loc, "entity.slime.attack", 1f, 0.6f);
        }
    }

    private void shadowStep(Player p) {
        if (mobilitySealed(p)) return;
        shadowPool(p, p.getLocation());
        p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 80, 0));
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 80, 3));
        p.playSound(p.getLocation(), "entity.enderman.teleport", 0.8f, 0.5f);
        p.getWorld().spawnParticle(Particle.SMOKE, p.getLocation(), 20, 0.3, 0.5, 0.3, 0.03);
    }

    private void rabbitEscape(Player p) {
        plugin.summons().spawnRabbitEscape(p, p.getLocation());
        for (Entity e : p.getNearbyEntities(8, 5, 8)) {
            if (e instanceof LivingEntity le && !e.equals(p) && !plugin.summons().isOwnedSummon(p, e)) {
                le.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0));
                le.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 80, 0));
            }
        }
        p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 30, 1.5, 0.8, 1.5, 0.05);
        p.playSound(p.getLocation(), "entity.rabbit.ambient", 1.5f, 1.2f);
    }

    private void maxElephant(Player p) {
        LivingEntity target = fx().target(p, 15);
        Location c = target != null ? target.getLocation() : fx().forwardTeleport(p, 10);
        Location above = c.clone().add(0, 6, 0);
        // Crushing torrent from above.
        new BukkitRunnable() {
            int ticks = 0;
            @Override public void run() {
                if (ticks++ >= 10) {
                    fx().aoe(c, 4, 8.0, p, false, false, le -> {
                        le.setVelocity(le.getVelocity().setY(-0.8));
                        le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 2));
                    });
                    fx().expandingRings(c, WATER, 4);
                    c.getWorld().playSound(c, "entity.generic.splash", 2f, 0.5f);
                    cancel();
                    return;
                }
                Location layer = above.clone().subtract(0, ticks * 0.6, 0);
                fx().dust(layer, WATER, 2f, 25, 1.6);
                c.getWorld().spawnParticle(Particle.SPLASH, layer, 20, 1.5, 0.2, 1.5, 0);
            }
        }.runTaskTimer(plugin, 0L, 2L);
        p.playSound(p.getLocation(), "entity.ravager.roar", 1f, 0.5f);
    }

    private void piercingOx(Player p) {
        if (mobilitySealed(p)) return;
        Vector dir = p.getEyeLocation().getDirection().setY(0).normalize();
        Location cur = p.getLocation();
        LivingEntity hitTarget = null;
        for (int i = 0; i < 12 && hitTarget == null; i++) {
            cur.add(dir);
            if (!cur.getBlock().isPassable()) break;
            for (Entity e : cur.getWorld().getNearbyEntities(cur, 1.6, 1.6, 1.6)) {
                if (e instanceof LivingEntity le && !e.equals(p) && !plugin.summons().isOwnedSummon(p, e)) {
                    hitTarget = le;
                    break;
                }
            }
        }
        cur.setDirection(dir);
        p.teleport(cur);
        fx().line(p.getLocation().add(0, 1, 0), dir.clone().multiply(-1), 12, SHADOW, 0.4);
        if (hitTarget != null) {
            fx().hit(hitTarget, 10.0, p, false, false);
            fx().knock(hitTarget, dir.clone().setY(0.4), 2.4);
            p.getWorld().spawnParticle(Particle.EXPLOSION, hitTarget.getLocation(), 1);
        }
        p.playSound(p.getLocation(), "entity.ravager.step", 1.5f, 0.5f);
    }

    private void roundDeer(Player p) {
        new BukkitRunnable() {
            int ticks = 0;
            @Override public void run() {
                if (!p.isOnline() || ticks++ >= 10) { cancel(); return; }
                for (Entity e : p.getNearbyEntities(6, 4, 6)) {
                    if (e instanceof Player ally) {
                        ally.setHealth(Math.min(ally.getAttribute(Attribute.MAX_HEALTH).getValue(), ally.getHealth() + 1));
                        ally.removePotionEffect(PotionEffectType.POISON);
                        ally.removePotionEffect(PotionEffectType.WITHER);
                        ally.getWorld().spawnParticle(Particle.HEART, ally.getLocation().add(0, 2, 0), 1, 0.2, 0.2, 0.2, 0);
                    }
                }
                p.setHealth(Math.min(p.getAttribute(Attribute.MAX_HEALTH).getValue(), p.getHealth() + 1));
                fx().ring(p.getLocation(), 6, Color.fromRGB(180, 255, 200), 24);
            }
        }.runTaskTimer(plugin, 0L, 5L);
        p.playSound(p.getLocation(), "entity.allay.ambient_with_item", 1f, 1.4f);
    }

    private void mahoraga(Player p) {
        p.sendMessage(net.kyori.adventure.text.Component.text(
                "「With this treasure, I summon...」 — Eight-Handled Sword Divergent Sila Divine General Mahoraga!",
                net.kyori.adventure.text.format.NamedTextColor.GOLD));
        Location loc = p.getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(3));
        shadowPool(p, loc);
        plugin.summons().spawnMahoraga(p, loc);
        p.getWorld().playSound(loc, "entity.warden.emerge", 1.5f, 0.6f);
        p.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, loc, 40, 1, 1.5, 1, 0.03);
    }

    private void shadowPool(Player p, Location loc) {
        var pool = fx().blockDisplay(loc.clone().subtract(0, 0.9, 0), Material.BLACK_CONCRETE, 1.6f);
        fx().register(p, pool);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> { if (pool.isValid()) pool.remove(); }, 60L);
        fx().dust(loc.clone().add(0, 0.3, 0), SHADOW, 2f, 15, 0.8);
    }
}
