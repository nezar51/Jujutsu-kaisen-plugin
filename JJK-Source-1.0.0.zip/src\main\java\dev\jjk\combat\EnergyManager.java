package dev.jjk.combat;

import dev.jjk.JJKPlugin;
import dev.jjk.character.CharacterType;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Cursed Energy (or Toji's Stamina / Momentum) gauge, regeneration,
 * BossBar + ActionBar HUD and error flashes.
 */
public final class EnergyManager {

    private final JJKPlugin plugin;
    private final Map<UUID, Double> values = new HashMap<>();
    private final Map<UUID, BossBar> bars = new HashMap<>();
    private BukkitTask task;

    public EnergyManager(JJKPlugin plugin) { this.plugin = plugin; }

    public double max(Player p) {
        CharacterType t = plugin.characters().type(p);
        if (t == null) return 0;
        return plugin.getConfig().getDouble("energy." + t.id(), t.usesStamina() ? 100 : 1000);
    }

    public double get(Player p) { return values.getOrDefault(p.getUniqueId(), 0.0); }
    public void set(Player p, double v) { values.put(p.getUniqueId(), Math.max(0, Math.min(max(p), v))); }
    public void add(Player p, double v) { set(p, get(p) + v); }
    public void clear(Player p) { values.remove(p.getUniqueId()); }

    public boolean consume(Player p, double amount) {
        if (amount <= 0) return true;
        double cur = get(p);
        if (cur < amount) return false;
        values.put(p.getUniqueId(), cur - amount);
        return true;
    }

    public void flash(Player p, String legacyMessage) {
        p.sendActionBar(LegacyComponentSerializer.legacySection().deserialize(legacyMessage));
        p.playSound(p.getLocation(), "entity.villager.no", 0.7f, 0.7f);
    }

    public void showHud(Player p) {
        if (!plugin.getConfig().getBoolean("hud.use-bossbar", true)) return;
        CharacterType t = plugin.characters().type(p);
        if (t == null) return;
        BossBar bar = BossBar.bossBar(Component.text(t.displayName()), 1f,
                barColor(t), BossBar.Overlay.PROGRESS);
        bars.put(p.getUniqueId(), bar);
        p.showBossBar(bar);
    }

    public void hideHud(Player p) {
        BossBar bar = bars.remove(p.getUniqueId());
        if (bar != null) p.hideBossBar(bar);
    }

    private BossBar.Color barColor(CharacterType t) {
        return switch (t) {
            case GOJO -> BossBar.Color.BLUE;
            case SUKUNA -> BossBar.Color.RED;
            case MEGUMI -> BossBar.Color.PURPLE;
            case YUJI -> BossBar.Color.PINK;
            case TOJI -> BossBar.Color.GREEN;
        };
    }

    public void startTicker() {
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 10L, 10L);
    }

    public void shutdown() {
        if (task != null) task.cancel();
        for (UUID id : new HashMap<>(bars).keySet()) {
            Player p = plugin.getServer().getPlayer(id);
            if (p != null) hideHud(p);
        }
        bars.clear();
        values.clear();
    }

    private void tick() {
        double half = 0.5; // tick runs every 10 ticks = 0.5s
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            CharacterType t = plugin.characters().type(p);
            if (t == null) continue;
            CharacterController ctrl = plugin.controller(t);

            // Regeneration
            double regen;
            if (t.usesStamina()) {
                regen = plugin.getConfig().getDouble(
                        p.isSprinting() ? "energy.regen-per-second.toji-sprinting" : "energy.regen-per-second.toji-idle",
                        p.isSprinting() ? 8 : 2);
            } else {
                regen = plugin.getConfig().getDouble("energy.regen-per-second." + t.id(), 10);
            }
            add(p, regen * half);

            // Stance drain (Infinity, cursed aura, shadow veil)
            double drain = ctrl.stanceDrain(p);
            if (drain > 0) {
                if (!consume(p, drain * half)) {
                    // Out of energy: stance collapses. Controller handles via tick().
                }
            }

            ctrl.tick(p);
            updateHud(p, t, ctrl);
        }
    }

    private void updateHud(Player p, CharacterType t, CharacterController ctrl) {
        double cur = get(p), max = max(p);
        float progress = max <= 0 ? 0 : (float) (cur / max);
        String label = t.usesStamina() ? "Stamina" : "Cursed Energy";
        String status = ctrl.status(p);

        BossBar bar = bars.get(p.getUniqueId());
        if (bar != null) {
            bar.name(Component.text(t.displayName() + "  •  " + label + " " + (int) cur + "/" + (int) max
                    + (status.isEmpty() ? "" : "  •  " + status)));
            bar.progress(Math.max(0f, Math.min(1f, progress)));
        }
        if (plugin.getConfig().getBoolean("hud.actionbar", true)) {
            int filled = (int) Math.round(progress * 20);
            StringBuilder gauge = new StringBuilder();
            for (int i = 0; i < 20; i++) gauge.append(i < filled ? '|' : '.');
            String color = t.usesStamina() ? "§a" : "§b";
            String msg = color + label + " " + gauge + " " + (int) cur + "/" + (int) max
                    + (status.isEmpty() ? "" : " §7• " + status);
            p.sendActionBar(LegacyComponentSerializer.legacySection().deserialize(msg));
        }
    }
}
