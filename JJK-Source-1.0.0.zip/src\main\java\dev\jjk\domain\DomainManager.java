package dev.jjk.domain;

import dev.jjk.JJKPlugin;
import dev.jjk.character.CharacterType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Domain Expansions:
 *  - Gojo: Unlimited Void (20b cosmic sphere, 10s stun + blindness)
 *  - Sukuna: Malevolent Shrine (25b, sure-hit slashes every 0.25s)
 *  - Megumi: Chimera Shadow Garden (20b liquid shadow, clones, double summons)
 *  - Yuji: Hometown (20b snowy town, mobility seal + guaranteed hits)
 * Toji (Heavenly Restriction) walks through all barriers and is immune to
 * stun / sure-hit effects; Predator Instinct extends that immunity.
 */
public final class DomainManager {

    private final JJKPlugin plugin;
    private final Map<UUID, ActiveDomain> domains = new HashMap<>();
    private final Map<UUID, Long> stunnedUntil = new HashMap<>();
    private final Map<UUID, Long> predatorUntil = new HashMap<>();
    private final Map<UUID, Boolean> aiRestore = new HashMap<>();
    private BukkitTask ticker;

    public DomainManager(JJKPlugin plugin) { this.plugin = plugin; }

    public static final class ActiveDomain {
        public final UUID owner;
        public final CharacterType type;
        public final Location center;
        public final double radius;
        public final long endMillis;
        public final List<Entity> shell = new ArrayList<>();
        public final List<Entity> extras = new ArrayList<>();

        ActiveDomain(UUID owner, CharacterType type, Location center, double radius, long endMillis) {
            this.owner = owner;
            this.type = type;
            this.center = center;
            this.radius = radius;
            this.endMillis = endMillis;
        }
    }

    // ------------------------------------------------------------------
    public boolean isStunned(Player p) {
        if (plugin.characters().type(p) == CharacterType.TOJI) return false; // Heavenly Restriction
        if (isPredator(p)) return false;
        Long until = stunnedUntil.get(p.getUniqueId());
        return until != null && until > System.currentTimeMillis();
    }

    public boolean isPredator(Player p) {
        Long until = predatorUntil.get(p.getUniqueId());
        return until != null && until > System.currentTimeMillis();
    }

    public void grantPredator(Player p, long ms) {
        predatorUntil.put(p.getUniqueId(), System.currentTimeMillis() + ms);
    }

    /** True when the player is an enemy inside Yuji's Hometown (mobility skills disabled). */
    public boolean mobilityLocked(Player p) {
        for (ActiveDomain d : domains.values()) {
            if (d.type != CharacterType.YUJI || d.owner.equals(p.getUniqueId())) continue;
            if (plugin.characters().type(p) == CharacterType.TOJI) continue;
            if (p.getWorld().equals(d.center.getWorld()) && p.getLocation().distance(d.center) <= d.radius) return true;
        }
        return false;
    }

    /** True when this attacker is inside their own Hometown domain (guaranteed hits). */
    public boolean hasSureHit(Player attacker) {
        ActiveDomain d = domains.get(attacker.getUniqueId());
        return d != null && d.type == CharacterType.YUJI;
    }

    public boolean inOwnShadowGarden(Player p) {
        ActiveDomain d = domains.get(p.getUniqueId());
        return d != null && d.type == CharacterType.MEGUMI;
    }

    public boolean inAnyDomainShell(Player p) {
        for (ActiveDomain d : domains.values()) {
            if (p.getWorld().equals(d.center.getWorld()) && p.getLocation().distance(d.center) <= d.radius) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------
    public void start(Player owner, CharacterType type) {
        endFor(owner);
        double radius = plugin.getConfig().getDouble("domains." + type.id() + "-radius", 20);
        long duration = plugin.getConfig().getLong("domains.duration-seconds", 10) * 1000L;
        Location center = owner.getLocation().clone();
        ActiveDomain d = new ActiveDomain(owner.getUniqueId(), type, center, radius, System.currentTimeMillis() + duration);
        domains.put(owner.getUniqueId(), d);

        int points = plugin.getConfig().getInt("domains.shell-points", 70);
        Material shellMat = switch (type) {
            case GOJO -> Material.TINTED_GLASS;
            case SUKUNA -> Material.BONE_BLOCK;
            case MEGUMI -> Material.BLACK_STAINED_GLASS;
            case YUJI -> Material.SNOW_BLOCK;
            case TOJI -> Material.AIR;
        };
        if (shellMat != Material.AIR) {
            d.shell.addAll(plugin.fx().sphereShell(center.clone().add(0, 2, 0), radius, shellMat, points, 0.6f));
        }

        owner.getWorld().playSound(center, "block.beacon.power.select", 2f, 0.5f);
        owner.getWorld().playSound(center, "entity.warden.sonic_boom", 1.5f, 0.6f);
        announce(owner, type);

        switch (type) {
            case GOJO -> unlimitedVoid(owner, d);
            case MEGUMI -> shadowGarden(owner, d);
            default -> { }
        }
    }

    private void announce(Player owner, CharacterType type) {
        String name = switch (type) {
            case GOJO -> "Domain Expansion: Unlimited Void";
            case SUKUNA -> "Domain Expansion: Malevolent Shrine";
            case MEGUMI -> "Domain Expansion: Chimera Shadow Garden";
            case YUJI -> "Domain Expansion: Hometown";
            case TOJI -> "Predator Instinct";
        };
        for (Player near : owner.getWorld().getPlayers()) {
            if (near.getLocation().distance(owner.getLocation()) < 60) {
                near.sendMessage(Component.text(owner.getName() + " — " + name, NamedTextColor.DARK_PURPLE));
            }
        }
    }

    private void unlimitedVoid(Player owner, ActiveDomain d) {
        long stunMs = plugin.getConfig().getLong("domains.duration-seconds", 10) * 1000L;
        for (Entity e : owner.getWorld().getNearbyEntities(d.center, d.radius, d.radius, d.radius)) {
            if (!(e instanceof LivingEntity le) || e.equals(owner)) continue;
            if (plugin.summons().isOwnedSummon(owner, e)) continue;
            if (e instanceof Player pl) {
                if (plugin.characters().type(pl) == CharacterType.TOJI) continue; // walks through
                stunnedUntil.put(pl.getUniqueId(), System.currentTimeMillis() + stunMs);
                pl.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, (int) (stunMs / 50), 1));
                pl.sendMessage(Component.text("Infinite information floods your mind. You cannot move.", NamedTextColor.DARK_AQUA));
            } else if (e instanceof Mob mob) {
                aiRestore.put(mob.getUniqueId(), mob.hasAI());
                mob.setAI(false);
            }
        }
    }

    private void shadowGarden(Player owner, ActiveDomain d) {
        // Shadow clones: player-head displays that lurk and strike.
        for (int i = 0; i < 3; i++) {
            Location loc = d.center.clone().add((Math.random() - 0.5) * 10, 0, (Math.random() - 0.5) * 10);
            Entity clone = plugin.summons().spawnShadowClone(owner, loc);
            if (clone != null) d.extras.add(clone);
        }
    }

    // ------------------------------------------------------------------
    public void startTicker() {
        ticker = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 5L, 5L);
    }

    private void tick() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, ActiveDomain>> it = domains.entrySet().iterator();
        while (it.hasNext()) {
            ActiveDomain d = it.next().getValue();
            Player owner = plugin.getServer().getPlayer(d.owner);
            if (owner == null || !owner.isOnline() || now >= d.endMillis
                    || !plugin.characters().isTransformed(owner)) {
                cleanup(d);
                it.remove();
                continue;
            }
            switch (d.type) {
                case SUKUNA -> malevolentShrine(owner, d);
                case MEGUMI -> {
                    plugin.fx().dust(d.center.clone().add(0, 0.3, 0), Color.BLACK, 2f, 30, d.radius / 2);
                    for (Entity e : owner.getWorld().getNearbyEntities(d.center, d.radius, d.radius, d.radius)) {
                        if (e instanceof Player pl && !pl.equals(owner)
                                && plugin.characters().type(pl) != CharacterType.TOJI) {
                            pl.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 40, 0));
                        }
                    }
                }
                case YUJI -> {
                    d.center.getWorld().spawnParticle(Particle.SNOWFLAKE, d.center.clone().add(0, 3, 0), 40, d.radius / 2, 3, d.radius / 2, 0.01);
                    for (Entity e : owner.getWorld().getNearbyEntities(d.center, d.radius, d.radius, d.radius)) {
                        if (e instanceof LivingEntity le && !le.equals(owner)
                                && !plugin.summons().isOwnedSummon(owner, e)) {
                            if (le instanceof Player pl && plugin.characters().type(pl) == CharacterType.TOJI) continue;
                            le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 1));
                        }
                    }
                }
                case GOJO -> {
                    // Unlimited Void: circular black-and-white convergence rings.
                    double rr = d.radius;
                    double spin = (now / 1000.0) % (Math.PI * 2);
                    for (int ring = 0; ring < 3; ring++) {
                        double ringR = rr * (0.35 + ring * 0.32);
                        double yOff = 1.0 + ring * 0.9;
                        int pts = 48 + ring * 16;
                        for (int i = 0; i < pts; i++) {
                            double a = (Math.PI * 2 * i / pts) + spin * (ring % 2 == 0 ? 1 : -1);
                            Location pt = d.center.clone().add(Math.cos(a) * ringR, yOff, Math.sin(a) * ringR);
                            plugin.fx().dust(pt, (i % 2 == 0) ? Color.fromRGB(255, 255, 255) : Color.fromRGB(0, 0, 0), 1.1f, 1, 0);
                        }
                    }
                    // Center singularity: pulsing black/white core.
                    Location core = d.center.clone().add(0, 2, 0);
                    plugin.fx().dust(core, Color.fromRGB(0, 0, 0), 3.0f, 12, 0.8);
                    plugin.fx().dust(core, Color.fromRGB(255, 255, 255), 2.2f, 8, 0.4);
                    d.center.getWorld().spawnParticle(Particle.END_ROD, core, 12, 0.6, 0.6, 0.6, 0.01);
                    d.center.getWorld().spawnParticle(Particle.REVERSE_PORTAL, core, 10, 1.2, 1.2, 1.2, 0.02);
                }
                default -> { }
            }
        }
        stunnedUntil.entrySet().removeIf(e -> e.getValue() <= now);
        predatorUntil.entrySet().removeIf(e -> e.getValue() <= now);
    }

    private void malevolentShrine(Player owner, ActiveDomain d) {
        double dmg = plugin.getConfig().getDouble("domains.sukuna-slash-damage", 4.0);
        // Surrounding black-and-white shrine pillars at the domain boundary.
        double rr = d.radius;
        double phase = (System.currentTimeMillis() / 1000.0) % (Math.PI * 2);
        for (int i = 0; i < 48; i++) {
            double a = (Math.PI * 2 * i / 48) + phase;
            Location pt = d.center.clone().add(Math.cos(a) * rr, 1.0 + Math.sin(a * 2) * 0.6, Math.sin(a) * rr);
            d.center.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, pt, 3, 0.1, 0.1, 0.1, 0.02);
            plugin.fx().dust(pt, Color.fromRGB(255, 255, 255), 1.2f, 1, 0);
            plugin.fx().dust(pt, Color.fromRGB(0, 0, 0), 1.2f, 1, 0);
        }
        // Sure-hit: bypasses Infinity and armor. Toji under Predator Instinct is immune.
        for (Entity e : owner.getWorld().getNearbyEntities(d.center, d.radius, d.radius, d.radius)) {
            if (!(e instanceof LivingEntity le) || e.equals(owner)) continue;
            if (e instanceof org.bukkit.entity.Display || e instanceof org.bukkit.entity.ArmorStand) continue;
            if (plugin.summons().isOwnedSummon(owner, e)) continue;
            if (le instanceof Player pl && plugin.characters().type(pl) == CharacterType.TOJI && isPredator(pl)) continue;
            if (le.getLocation().distance(d.center) > d.radius) continue;
            plugin.fx().hit(le, dmg, owner, false, true);
            le.getWorld().spawnParticle(Particle.SWEEP_ATTACK, le.getLocation().add(0, 1, 0), 2, 0.3, 0.5, 0.3, 0);
            plugin.fx().dust(le.getLocation().add(0, 1, 0), Color.RED, 1f, 3, 0.3);
        }
    }

    public void endFor(Player owner) {
        ActiveDomain d = domains.remove(owner.getUniqueId());
        if (d != null) cleanup(d);
    }

    private void cleanup(ActiveDomain d) {
        for (Entity e : d.shell) if (e.isValid()) e.remove();
        for (Entity e : d.extras) if (e.isValid()) e.remove();
        // Release frozen mobs.
        for (Entity e : d.center.getWorld().getNearbyEntities(d.center, d.radius + 4, d.radius + 4, d.radius + 4)) {
            Boolean had = aiRestore.remove(e.getUniqueId());
            if (had != null && e instanceof Mob mob && e.isValid()) mob.setAI(had);
        }
    }

    public void shutdown() {
        if (ticker != null) ticker.cancel();
        for (ActiveDomain d : domains.values()) cleanup(d);
        domains.clear();
        stunnedUntil.clear();
        predatorUntil.clear();
        aiRestore.clear();
    }
}
