package dev.jjk.gui;

import dev.jjk.JJKPlugin;
import dev.jjk.character.CharacterType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * /jjk menu — click a character icon to transform.
 */
public final class CharacterMenu implements Listener, InventoryHolder {

    private final JJKPlugin plugin;
    private final Map<UUID, Inventory> inventories = new HashMap<>();
    private Inventory lastInventory;

    public CharacterMenu(JJKPlugin plugin) { this.plugin = plugin; }

    @Override
    public Inventory getInventory() { return lastInventory; }

    public void open(Player p) {
        Inventory inventory = Bukkit.createInventory(this, 27, Component.text("Choose your Sorcerer", NamedTextColor.DARK_PURPLE));
        int slot = 10;
        for (CharacterType type : CharacterType.values()) {
            ItemStack icon = new ItemStack(type.menuIcon());
            ItemMeta meta = icon.getItemMeta();
            meta.displayName(Component.text(type.displayName(), NamedTextColor.LIGHT_PURPLE).decoration(TextDecoration.ITALIC, false));
            String resource = type.usesStamina() ? "Stamina / Momentum gauge" : plugin.getConfig().getInt("energy." + type.id()) + " Cursed Energy";
            meta.lore(List.of(
                    Component.text(resource, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                    Component.text("Click to transform", NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false)));
            meta.getPersistentDataContainer().set(plugin.cursedObjectKey(), PersistentDataType.STRING, type.id());
            icon.setItemMeta(meta);
            inventory.setItem(slot++, icon);
            if (slot == 15) slot = 16; // spread 5 icons: 10,11,12,13,14 -> keep contiguous
        }
        inventories.put(p.getUniqueId(), inventory);
        lastInventory = inventory;
        p.openInventory(inventory);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof CharacterMenu)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        ItemStack clicked = e.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;
        String id = clicked.getItemMeta().getPersistentDataContainer()
                .get(plugin.cursedObjectKey(), PersistentDataType.STRING);
        if (id == null) return;
        CharacterType type = CharacterType.fromString(id);
        if (type == null) return;
        p.closeInventory();
        plugin.characters().transform(p, type);
    }
}
