package dev.jjk.util;

import dev.jjk.JJKPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.List;

/**
 * Loads messages.yml so all help text and user-facing messages can be edited
 * without recompiling. Uses '&' colour codes (see the file for examples).
 */
public final class Messages {

    private final JJKPlugin plugin;
    private final LegacyComponentSerializer serializer = LegacyComponentSerializer.legacyAmpersand();
    private YamlConfiguration config;

    public Messages(JJKPlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) plugin.saveResource("messages.yml", false);
        config = YamlConfiguration.loadConfiguration(file);
    }

    public Component get(String path) {
        return serializer.deserialize(config.getString(path, "&cMissing message: " + path));
    }

    public List<Component> getList(String path) {
        return config.getStringList(path).stream().<Component>map(serializer::deserialize).toList();
    }

    public String raw(String path) { return config.getString(path); }

    public Component component(String raw) { return serializer.deserialize(raw); }
}
