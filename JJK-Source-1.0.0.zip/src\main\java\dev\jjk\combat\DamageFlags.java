package dev.jjk.combat;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Synchronous damage tags used to let certain techniques bypass defensive
 * passives (Gojo's Infinity) — e.g. World Cutting Slash, Hollow Purple,
 * Malevolent Shrine sure-hits and Toji's Inverted Spear.
 */
public final class DamageFlags {

    private static final Set<UUID> UNBLOCKABLE = new HashSet<>();
    private static final Set<UUID> ISOH_HIT = new HashSet<>();

    private DamageFlags() { }

    public static void markUnblockable(UUID victim) { UNBLOCKABLE.add(victim); }
    public static boolean consumeUnblockable(UUID victim) { return UNBLOCKABLE.remove(victim); }

    public static void markIsoh(UUID victim) { ISOH_HIT.add(victim); }
    public static boolean consumeIsoh(UUID victim) { return ISOH_HIT.remove(victim); }
}
