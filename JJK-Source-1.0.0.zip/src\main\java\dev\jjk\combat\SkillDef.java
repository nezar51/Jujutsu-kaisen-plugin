package dev.jjk.combat;

import java.util.function.Consumer;
import org.bukkit.entity.Player;

/**
 * A single castable skill definition. Keys: "1".."8", "1s".."8s" (shift),
 * "q" (ultimate), "f" (passive / stance), "fs" (domain expansion).
 */
public final class SkillDef {
    public final String key;
    public final String name;
    public final String animationId;
    public final double cost;
    public final long cooldownMs;
    public final Consumer<Player> executor;
    /** When true, left-click casts this (shift) variant of the held ability. */
    public final boolean leftClickVariant;

    public SkillDef(String key, String name, String animationId, double cost, long cooldownMs, Consumer<Player> executor) {
        this(key, name, animationId, cost, cooldownMs, executor, false);
    }

    public SkillDef(String key, String name, String animationId, double cost, long cooldownMs,
                    Consumer<Player> executor, boolean leftClickVariant) {
        this.key = key;
        this.name = name;
        this.animationId = animationId;
        this.cost = cost;
        this.cooldownMs = cooldownMs;
        this.executor = executor;
        this.leftClickVariant = leftClickVariant;
    }

    public void execute(Player p) { executor.accept(p); }
}
