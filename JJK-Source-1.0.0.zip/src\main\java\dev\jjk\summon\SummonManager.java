package dev.jjk.summon;

import dev.jjk.JJKPlugin;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Rabbit;
import org.bukkit.entity.Slime;
import org.bukkit.entity.Vex;
import org.bukkit.entity.Wolf;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Ten Shadows shikigami + Mahoraga. Each summon is a real mob (full AI) tagged
 * with owner PDC data, optionally paired with a BetterModel 3D rig. Summon
 * lifetimes, targeting and despawn are managed here; on-hit effects (bleed,
 * lightning) are handled in PassiveListener via the tags.
 */
public final class SummonManager {

    private final JJKPlugin plugin;
    private final Map<UUID, List<Entity>> summons = new HashMap<>();
    /** Mahoraga adaptation: summon UUID -> (damage cause -> times hit). */
    private final Map<UUID, Map<String, Integer>> adaptation = new HashMap<>();

    public SummonManager(JJKPlugin plugin) { this.plugin = plugin; }

    public boolean isSummon(Entity e) {
        return e != null && e.getPersistentDataContainer().has(plugin.summonKey(), PersistentDataType.STRING);
    }

    public UUID ownerOf(Entity e) {
        String s = e.getPersistentDataContainer().get(plugin.summonKey(), PersistentDataType.STRING);
        if (s == null) return null;
        try { return UUID.fromString(s.split("\\|")[0]); } catch (Exception ex) { return null; }
    }

    public String kindOf(Entity e) {
        String s = e.getPersistentDataContainer().get(plugin.summonKey(), PersistentDataType.STRING);
        return s == null ? "" : s.split("\\|").length > 1 ? s.split("\\|")[1] : "";
    }

    public boolean isOwnedSummon(Player owner, Entity e) {
        return owner != null && owner.getUniqueId().equals(ownerOf(e));
    }

    private void tag(Player owner, Entity e, String kind, int lifeTicks) {
        e.getPersistentDataContainer().set(plugin.summonKey(), PersistentDataType.STRING,
                owner.getUniqueId() + "|" + kind);
        e.setPersistent(false);
        if (e instanceof Mob m) m.setRemoveWhenFarAway(false);
        summons.computeIfAbsent(owner.getUniqueId(), k -> new ArrayList<>()).add(e);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (e.isValid()) {
                e.getWorld().spawnParticle(Particle.SMOKE, e.getLocation(), 15, 0.3, 0.5, 0.3, 0.02);
                e.remove();
            }
        }, lifeTicks);
    }

    /** Retargets a mob at the nearest enemy of its owner. */
    private void startTargeting(Player owner, Mob mob, double range) {
        new BukkitRunnable() {
            @Override public void run() {
                if (!mob.isValid() || mob.isDead() || !owner.isOnline()) { cancel(); return; }
                LivingEntity best = null;
                double bestD = range;
                for (Entity e : mob.getNearbyEntities(range, range, range)) {
                    if (!(e instanceof LivingEntity le) || le.equals(owner) || isOwnedSummon(owner, e)) continue;
                    if (e instanceof org.bukkit.entity.Display || e instanceof org.bukkit.entity.ArmorStand) continue;
                    double dist = le.getLocation().distance(mob.getLocation());
                    if (dist < bestD) { best = le; bestD = dist; }
                }
                if (best != null) mob.setTarget(best);
            }
        }.runTaskTimer(plugin, 10L, 20L);
    }

    // ------------------------------------------------------------------
    public void spawnDivineDog(Player owner, Location loc) {
        int count = plugin.domains().inOwnShadowGarden(owner) ? 2 : 1;
        for (int i = 0; i < count; i++) {
            Wolf wolf = loc.getWorld().spawn(loc, Wolf.class, w -> {
                w.setAdult();
                w.customName(net.kyori.adventure.text.Component.text("Divine Dog: Totality"));
                w.setCustomNameVisible(true);
                w.setCollarColor(org.bukkit.DyeColor.BLACK);
            });
            tag(owner, wolf, "dog", 600);
            startTargeting(owner, wolf, 20);
            plugin.bridge().spawnModel(loc, "divine_dog", "anim_dog_sign");
        }
    }

    public void spawnNue(Player owner, Location loc) {
        Location up = loc.clone().add(0, 6, 0);
        int count = plugin.domains().inOwnShadowGarden(owner) ? 2 : 1;
        for (int i = 0; i < count; i++) {
            Vex nue = up.getWorld().spawn(up, Vex.class, v -> {
                v.customName(net.kyori.adventure.text.Component.text("Nue"));
                v.setCustomNameVisible(true);
            });
            tag(owner, nue, "nue", 500);
            startTargeting(owner, nue, 25);
            plugin.bridge().spawnModel(up, "nue", "anim_nue_sign");
        }
    }

    public void spawnToad(Player owner, Location loc) {
        Slime toad = loc.getWorld().spawn(loc, Slime.class, s -> {
            s.setSize(3);
            s.customName(net.kyori.adventure.text.Component.text("Toad"));
            s.setCustomNameVisible(true);
            s.setWander(false);
        });
        tag(owner, toad, "toad", 400);
        plugin.bridge().spawnModel(loc, "toad", "anim_toad_sign");
    }

    public void spawnRabbitEscape(Player owner, Location loc) {
        for (int i = 0; i < 8; i++) {
            Location l = loc.clone().add((Math.random() - 0.5) * 6, 0, (Math.random() - 0.5) * 6);
            Rabbit r = l.getWorld().spawn(l, Rabbit.class, rb -> rb.setAdult());
            tag(owner, r, "rabbit", 120);
        }
    }

    public void spawnMahoraga(Player owner, Location loc) {
        IronGolem maho = loc.getWorld().spawn(loc, IronGolem.class, g -> {
            g.setPlayerCreated(true);
            g.customName(net.kyori.adventure.text.Component.text("Divine General Mahoraga"));
            g.setCustomNameVisible(true);
        });
        tag(owner, maho, "mahoraga", 1200);
        startTargeting(owner, maho, 25);
        adaptation.put(maho.getUniqueId(), new HashMap<>());
        plugin.bridge().spawnModel(loc, "mahoraga", "anim_mahoraga_ritual");

        // Spinning Dharma wheel above the head (BlockDisplay fallback).
        ItemDisplay wheel = plugin.fx().itemDisplay(loc.clone().add(0, 3.2, 0), Material.RECOVERY_COMPASS, 1.2f);
        wheel.setBillboard(org.bukkit.entity.Display.Billboard.FIXED);
        new BukkitRunnable() {
            float angle = 0;
            @Override public void run() {
                if (!maho.isValid() || !wheel.isValid()) {
                    if (wheel.isValid()) wheel.remove();
                    cancel();
                    return;
                }
                angle += 0.4f;
                wheel.teleport(maho.getLocation().add(0, 3.2, 0));
                wheel.setTransformation(new org.bukkit.util.Transformation(
                        new org.joml.Vector3f(), new org.joml.AxisAngle4f(),
                        new org.joml.Vector3f(1.2f, 1.2f, 1.2f),
                        new org.joml.AxisAngle4f(angle, 0, 1, 0)));
                wheel.setInterpolationDuration(4);
            }
        }.runTaskTimer(plugin, 1L, 4L);
    }

    public Entity spawnShadowClone(Player owner, Location loc) {
        ItemDisplay clone = plugin.fx().itemDisplay(loc.clone().add(0, 1, 0), Material.PLAYER_HEAD, 1.5f);
        org.bukkit.inventory.ItemStack head = new org.bukkit.inventory.ItemStack(Material.PLAYER_HEAD);
        org.bukkit.inventory.meta.SkullMeta meta = (org.bukkit.inventory.meta.SkullMeta) head.getItemMeta();
        meta.setPlayerProfile(owner.getPlayerProfile());
        head.setItemMeta(meta);
        clone.setItemStack(head);
        clone.getPersistentDataContainer().set(plugin.summonKey(), PersistentDataType.STRING,
                owner.getUniqueId() + "|clone");
        summons.computeIfAbsent(owner.getUniqueId(), k -> new ArrayList<>()).add(clone);
        // Clones strike nearby enemies.
        new BukkitRunnable() {
            @Override public void run() {
                if (!clone.isValid() || !owner.isOnline()) { cancel(); return; }
                for (Entity e : clone.getNearbyEntities(4, 3, 4)) {
                    if (e instanceof LivingEntity le && !le.equals(owner) && !isOwnedSummon(owner, e)) {
                        plugin.fx().hit(le, 2.5, owner, false, false);
                        clone.getWorld().spawnParticle(Particle.SWEEP_ATTACK, le.getLocation().add(0, 1, 0), 1);
                        break;
                    }
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
        return clone;
    }

    // ------------------------------------------------------------------
    // Mahoraga adaptation
    // ------------------------------------------------------------------
    /** Returns the damage multiplier after adaptation (drops 15% per repeated hit, min 10%). */
    public double adaptationMultiplier(Entity summon, String cause) {
        Map<String, Integer> map = adaptation.get(summon.getUniqueId());
        if (map == null) return 1.0;
        int times = map.merge(cause, 1, Integer::sum) - 1;
        return Math.max(0.10, 1.0 - 0.15 * times);
    }

    // ------------------------------------------------------------------
    public void despawnAll(Player owner) {
        List<Entity> list = summons.remove(owner.getUniqueId());
        if (list == null) return;
        for (Entity e : list) {
            if (e.isValid()) e.remove();
            adaptation.remove(e.getUniqueId());
        }
    }

    public void despawnSummon(Entity e) {
        if (e.isValid()) e.remove();
        adaptation.remove(e.getUniqueId());
        summons.values().forEach(l -> l.remove(e));
    }

    public void shutdown() {
        for (List<Entity> list : summons.values()) {
            for (Entity e : list) if (e.isValid()) e.remove();
        }
        summons.clear();
        adaptation.clear();
    }
}
