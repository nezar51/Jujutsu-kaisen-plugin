package dev.jjk.util;

import dev.jjk.JJKPlugin;
import dev.jjk.combat.DamageFlags;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * Paper 1.21 Display-entity effect engine: ItemDisplay orbs / slashes / beams,
 * BlockDisplay shells, particles, knockback, raytracing and protection-aware
 * terrain cutting. All effect entities are registered per owner so Toji's
 * Inverted Spear can dispel them.
 */
public final class FX {

    private final JJKPlugin plugin;
    private final Map<UUID, List<Entity>> ownerEffects = new HashMap<>();
    private final Set<Entity> allEffects = new HashSet<>();

    /** Cached DustOptions - particle storms previously allocated one per particle. */
    private static final Map<Long, Particle.DustOptions> DUST_CACHE = new ConcurrentHashMap<>();
    private boolean respectProtection;

    public FX(JJKPlugin plugin) {
        this.plugin = plugin;
        reloadConfig();
    }

    /** Re-read cached config flags (called by /jjk reload). */
    public void reloadConfig() {
        respectProtection = plugin.getConfig().getBoolean("griefing.respect-protection-plugins", true);
    }

    /** Soft foliage that slashes may cut even on protected survival servers. */
    private static final Set<Material> CUTTABLE = EnumSet.of(
            Material.SHORT_GRASS, Material.TALL_GRASS, Material.FERN, Material.LARGE_FERN,
            Material.DANDELION, Material.POPPY, Material.BLUE_ORCHID, Material.ALLIUM,
            Material.AZURE_BLUET, Material.RED_TULIP, Material.ORANGE_TULIP, Material.WHITE_TULIP,
            Material.PINK_TULIP, Material.OXEYE_DAISY, Material.CORNFLOWER, Material.LILY_OF_THE_VALLEY,
            Material.SUGAR_CANE, Material.BAMBOO, Material.KELP, Material.SEAGRASS,
            Material.COBWEB, Material.SNOW, Material.DEAD_BUSH);

    // ------------------------------------------------------------------
    // Effect registry (for ISOH nullification)
    // ------------------------------------------------------------------
    public void register(Player owner, Entity e) {
        ownerEffects.computeIfAbsent(owner.getUniqueId(), k -> new ArrayList<>()).add(e);
        allEffects.add(e);
        e.setPersistent(false);
    }

    public void dispel(Player owner) {
        List<Entity> list = ownerEffects.remove(owner.getUniqueId());
        if (list == null) return;
        for (Entity e : list) {
            if (e.isValid()) {
                e.getWorld().spawnParticle(Particle.SMOKE, e.getLocation(), 8, 0.2, 0.2, 0.2, 0.02);
                e.remove();
            }
            allEffects.remove(e);
        }
    }

    /** Removes every registered effect entity (used on shutdown). */
    public void shutdown() {
        for (Entity e : allEffects) if (e.isValid()) e.remove();
        allEffects.clear();
        ownerEffects.clear();
    }

    /** Periodically prune dead entities from the registry. */
    public void startReaper() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            allEffects.removeIf(e -> !e.isValid());
            ownerEffects.values().forEach(l -> l.removeIf(e -> !e.isValid()));
        }, 100L, 100L);
    }

    // ------------------------------------------------------------------
    // Display spawning
    // ------------------------------------------------------------------
    public ItemDisplay itemDisplay(Location loc, Material mat, float scale) {
        ItemDisplay d = loc.getWorld().spawn(loc, ItemDisplay.class, display -> {
            display.setItemStack(new ItemStack(mat));
            display.setBillboard(org.bukkit.entity.Display.Billboard.CENTER);
            display.setBrightness(new org.bukkit.entity.Display.Brightness(15, 15));
            display.setViewRange(2.0f);
            display.setInterpolationDuration(2);
            display.setInterpolationDelay(0);
            display.setTeleportDuration(2);
            display.setTransformation(new org.bukkit.util.Transformation(
                    new Vector3f(), new AxisAngle4f(), new Vector3f(scale, scale, scale), new AxisAngle4f()));
        });
        return d;
    }

    public ItemDisplay shapedDisplay(Location loc, Material mat, Vector3f scale, float yawRadians) {
        ItemDisplay d = loc.getWorld().spawn(loc, ItemDisplay.class, display -> {
            display.setItemStack(new ItemStack(mat));
            display.setBillboard(org.bukkit.entity.Display.Billboard.FIXED);
            display.setBrightness(new org.bukkit.entity.Display.Brightness(15, 15));
            display.setViewRange(2.0f);
            display.setInterpolationDuration(2);
            display.setTeleportDuration(2);
            display.setTransformation(new org.bukkit.util.Transformation(
                    new Vector3f(), new AxisAngle4f(), scale, new AxisAngle4f(yawRadians, 0, 1, 0)));
        });
        return d;
    }

    public org.bukkit.entity.BlockDisplay blockDisplay(Location loc, Material block, float scale) {
        return loc.getWorld().spawn(loc, org.bukkit.entity.BlockDisplay.class, display -> {
            display.setBlock(block.createBlockData());
            display.setBrightness(new org.bukkit.entity.Display.Brightness(15, 15));
            display.setViewRange(3.0f);
            display.setTransformation(new org.bukkit.util.Transformation(
                    new Vector3f(), new AxisAngle4f(), new Vector3f(scale, scale, scale), new AxisAngle4f()));
            display.setPersistent(false);
        });
    }

    /** Fibonacci-sphere shell of BlockDisplays used for domain barriers. */
    public List<Entity> sphereShell(Location center, double radius, Material block, int points, float scale) {
        List<Entity> shell = new ArrayList<>();
        double golden = Math.PI * (3 - Math.sqrt(5));
        for (int i = 0; i < points; i++) {
            double y = 1 - (i / (double) (points - 1)) * 2;
            double r = Math.sqrt(Math.max(0, 1 - y * y));
            double theta = golden * i;
            Location loc = center.clone().add(Math.cos(theta) * r * radius, y * radius, Math.sin(theta) * r * radius);
            shell.add(blockDisplay(loc, block, scale));
        }
        return shell;
    }

    // ------------------------------------------------------------------
    // Targeting / movement
    // ------------------------------------------------------------------
    public LivingEntity target(Player p, double range) {
        RayTraceResult rt = p.getWorld().rayTraceEntities(p.getEyeLocation(), p.getEyeLocation().getDirection(),
                range, 0.6, e -> e instanceof LivingEntity && !e.equals(p)
                        && !(e instanceof org.bukkit.entity.Display)
                        && !(e instanceof org.bukkit.entity.ArmorStand));
        if (rt != null && rt.getHitEntity() instanceof LivingEntity le) return le;
        // Fallback: nearest living entity within a generous cone.
        LivingEntity best = null;
        double bestDist = range;
        for (Entity e : p.getNearbyEntities(range, range, range)) {
            if (!(e instanceof LivingEntity le) || e.equals(p)) continue;
            if (e instanceof org.bukkit.entity.Display || e instanceof org.bukkit.entity.ArmorStand) continue;
            Vector to = le.getEyeLocation().toVector().subtract(p.getEyeLocation().toVector());
            double dist = to.length();
            if (dist < bestDist && to.normalize().dot(p.getEyeLocation().getDirection()) > 0.75) {
                best = le;
                bestDist = dist;
            }
        }
        return best;
    }

    public Location forwardTeleport(Player p, double maxDist) {
        RayTraceResult rt = p.getWorld().rayTraceBlocks(p.getEyeLocation(), p.getEyeLocation().getDirection(), maxDist);
        Location dest;
        if (rt != null && rt.getHitPosition() != null) {
            dest = rt.getHitPosition().toLocation(p.getWorld()).subtract(p.getEyeLocation().getDirection().multiply(1.2));
            dest.setY(Math.max(dest.getY(), rt.getHitPosition().getY()));
        } else {
            dest = p.getEyeLocation().add(p.getEyeLocation().getDirection().multiply(maxDist));
        }
        dest.setYaw(p.getLocation().getYaw());
        dest.setPitch(p.getLocation().getPitch());
        // Find a safe standing spot.
        for (int i = 0; i < 4; i++) {
            Block feet = dest.getBlock();
            Block head = dest.clone().add(0, 1, 0).getBlock();
            Block below = dest.clone().subtract(0, 1, 0).getBlock();
            if (feet.isPassable() && head.isPassable() && !below.isPassable()) break;
            if (!feet.isPassable() || !head.isPassable()) dest.add(0, 1, 0);
            else dest.subtract(0, 1, 0);
        }
        return dest;
    }

    public void knock(Entity e, Vector direction, double strength) {
        Vector v = direction.clone().normalize().multiply(strength);
        if (Double.isNaN(v.getX()) || Double.isNaN(v.getY()) || Double.isNaN(v.getZ())) return;
        e.setVelocity(e.getVelocity().add(v));
    }

    // ------------------------------------------------------------------
    // Damage helpers
    // ------------------------------------------------------------------
    /**
     * @param pierceArmor   true = true damage (ignores armor, resistance, Infinity)
     * @param bypassInfinity true = cannot be stopped by Gojo's Infinity
     */
    public void hit(LivingEntity target, double damage, Entity source, boolean pierceArmor, boolean bypassInfinity) {
        if (!target.isValid() || target.isDead()) return;
        if (bypassInfinity) DamageFlags.markUnblockable(target.getUniqueId());
        try {
            if (pierceArmor) {
                org.bukkit.damage.DamageSource src = org.bukkit.damage.DamageSource
                        .builder(org.bukkit.damage.DamageType.GENERIC_KILL)
                        .withCausingEntity(source)
                        .withDirectEntity(source)
                        .build();
                target.damage(damage, src);
            } else {
                target.damage(damage, source);
            }
        } finally {
            if (bypassInfinity) DamageFlags.consumeUnblockable(target.getUniqueId());
        }
    }

    public void aoe(Location center, double radius, double damage, Player source,
                    boolean pierceArmor, boolean bypassInfinity, Consumer<LivingEntity> extra) {
        for (Entity e : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (!(e instanceof LivingEntity le) || e.equals(source)) continue;
            if (e instanceof org.bukkit.entity.Display || e instanceof org.bukkit.entity.ArmorStand) continue;
            if (plugin.summons().isOwnedSummon(source, e)) continue;
            if (le.getLocation().distance(center) > radius) continue;
            hit(le, damage, source, pierceArmor, bypassInfinity);
            if (extra != null) extra.accept(le);
        }
    }

    // ------------------------------------------------------------------
    // Particles
    // ------------------------------------------------------------------
    public void dust(Location loc, Color color, float size, int count, double spread) {
        loc.getWorld().spawnParticle(Particle.DUST, loc, count, spread, spread, spread, dustOptions(color, size));
    }

    private static Particle.DustOptions dustOptions(Color color, float size) {
        long key = (((long) color.asRGB()) << 32) | (Float.floatToRawIntBits(size) & 0xFFFFFFFFL);
        return DUST_CACHE.computeIfAbsent(key, k -> new Particle.DustOptions(color, size));
    }

    public void ring(Location center, double radius, Color color, int points) {
        for (int i = 0; i < points; i++) {
            double a = 2 * Math.PI * i / points;
            Location loc = center.clone().add(Math.cos(a) * radius, 0.1, Math.sin(a) * radius);
            dust(loc, color, 1.2f, 1, 0);
        }
    }

    public void expandingRings(Location center, Color color, double maxRadius) {
        new BukkitRunnable() {
            double r = 0.5;
            @Override public void run() {
                if (r > maxRadius) { cancel(); return; }
                ring(center, r, color, (int) (12 + r * 6));
                r += 0.9;
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    public void line(Location from, Vector dir, double length, Color color, double step) {
        Vector d = dir.clone().normalize().multiply(step);
        Location cur = from.clone();
        for (double t = 0; t < length; t += step) {
            dust(cur, color, 1.0f, 1, 0.02);
            cur.add(d);
        }
    }

    /** Dense blade-like particle burst for high-impact cursed techniques. */
    public void sharp(Location center, Vector direction, int strength) {
        Vector dir = direction.clone().normalize();
        Vector side = dir.clone().crossProduct(new Vector(0, 1, 0));
        if (side.lengthSquared() < 0.01) side = new Vector(1, 0, 0);
        side.normalize();
        Vector up = dir.clone().crossProduct(side).normalize();
        for (int i = 0; i < Math.max(4, strength); i++) {
            Location point = center.clone().add(side.clone().multiply((i % 5 - 2) * 0.12))
                    .add(up.clone().multiply(((i * 3) % 5 - 2) * 0.1));
            center.getWorld().spawnParticle(Particle.CRIT, point, 2, 0.03, 0.03, 0.03, 0.08);
            if ((i & 1) == 0) center.getWorld().spawnParticle(Particle.SWEEP_ATTACK, point, 1, 0, 0, 0, 0);
            if ((i & 3) == 0) center.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, point, 1, 0.05, 0.05, 0.05, 0.02);
        }
    }

    // ------------------------------------------------------------------
    // Terrain cutting (protection-aware)
    // ------------------------------------------------------------------
    public boolean canBreak(Player p, Block b) {
        if (!plugin.griefing()) return false;
        if (b.getType().isAir() || b.getType() == Material.BEDROCK || b.getType() == Material.BARRIER) return false;
        if (respectProtection) {
            BlockBreakEvent evt = new BlockBreakEvent(b, p);
            plugin.getServer().getPluginManager().callEvent(evt);
            if (evt.isCancelled()) return false;
        }
        return true;
    }

    public void cutSoftLine(Player p, Location from, Vector dir, double length) {
        Vector d = dir.clone().normalize().multiply(0.7);
        Location cur = from.clone();
        for (double t = 0; t < length; t += 0.7) {
            Block b = cur.getBlock();
            if (CUTTABLE.contains(b.getType()) && canBreak(p, b)) {
                b.breakNaturally();
                cur.getWorld().spawnParticle(Particle.SWEEP_ATTACK, cur, 1);
            }
            cur.add(d);
        }
    }

    public void deleteSphere(Player p, Location center, double radius) {
        int r = (int) Math.ceil(radius);
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            if (x * x + y * y + z * z > radius * radius) continue;
            Block b = center.clone().add(x, y, z).getBlock();
            if (canBreak(p, b)) {
                b.setType(Material.AIR, false);
            }
        }
        center.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, center, 1);
    }

    // ------------------------------------------------------------------
    // Projectiles
    // ------------------------------------------------------------------
    /**
     * Moves an ItemDisplay orb along a direction, running impact logic when it
     * hits a block or living entity. onTick may add extra behaviour.
     */
    public void orbProjectile(Player owner, ItemDisplay orb, Vector dir, double speed, int maxTicks,
                              double hitRadius, Consumer<LivingEntity> onEntityHit, Runnable onBlockHit,
                              Consumer<ItemDisplay> onTick) {
        Vector velocity = dir.clone().normalize().multiply(speed);
        new BukkitRunnable() {
            int ticks = 0;
            @Override public void run() {
                if (!orb.isValid() || ticks++ >= maxTicks) { finish(false); cancel(); return; }
                Location next = orb.getLocation().add(velocity);
                if (!next.getBlock().isPassable()) {
                    orb.teleport(next);
                    if (onBlockHit != null) onBlockHit.run();
                    finish(true);
                    cancel();
                    return;
                }
                orb.teleport(next);
                if (onTick != null) onTick.accept(orb);
                for (Entity e : next.getWorld().getNearbyEntities(next, hitRadius, hitRadius, hitRadius)) {
                    if (!(e instanceof LivingEntity le) || e.equals(owner)) continue;
                    if (e instanceof org.bukkit.entity.Display || e instanceof org.bukkit.entity.ArmorStand) continue;
                    if (plugin.summons().isOwnedSummon(owner, e)) continue;
                    if (onEntityHit != null) onEntityHit.accept(le);
                    finish(true);
                    cancel();
                    return;
                }
            }
            private void finish(boolean remove) {
                if (remove && orb.isValid()) orb.remove();
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    /** Piercing beam of particles that damages every entity along the line once. */
    public void beam(Player owner, double range, double damage, Color color, boolean pierceArmor, boolean bypassInfinity) {
        Location from = owner.getEyeLocation();
        Vector dir = from.getDirection();
        Set<UUID> hit = new HashSet<>();
        Vector step = dir.clone().normalize().multiply(0.5);
        Location cur = from.clone();
        for (double t = 0; t < range; t += 0.5) {
            dust(cur, color, 1.4f, 2, 0.05);
            sharp(cur, dir, 3);
            for (Entity e : cur.getWorld().getNearbyEntities(cur, 0.8, 0.8, 0.8)) {
                if (!(e instanceof LivingEntity le) || e.equals(owner) || hit.contains(e.getUniqueId())) continue;
                if (e instanceof org.bukkit.entity.Display || e instanceof org.bukkit.entity.ArmorStand) continue;
                if (plugin.summons().isOwnedSummon(owner, e)) continue;
                hit.add(e.getUniqueId());
                hit(le, damage, owner, pierceArmor, bypassInfinity);
                cur.getWorld().spawnParticle(Particle.CRIT, le.getEyeLocation(), 10, 0.2, 0.3, 0.2, 0.2);
            }
            if (!cur.getBlock().isPassable()) break;
            cur.add(step);
        }
    }

    /** Thin glowing slash arc that flies forward slicing entities and foliage. */
    public void slashArc(Player owner, Location start, Vector dir, double range, double damage, Color color) {
        float yaw = (float) Math.toRadians(-start.getYaw());
        ItemDisplay slash = shapedDisplay(start, Material.IRON_SWORD, new Vector3f(2.6f, 0.12f, 0.9f), yaw);
        register(owner, slash);
        new BukkitRunnable() {
            double travelled = 0;
            final Set<UUID> hit = new HashSet<>();
            @Override public void run() {
                if (!slash.isValid() || travelled >= range) { slash.remove(); cancel(); return; }
                Location next = slash.getLocation().add(dir.clone().normalize().multiply(1.1));
                slash.teleport(next);
                travelled += 1.1;
                dust(next, color, 1.3f, 4, 0.5);
                sharp(next, dir, 5);
                next.getWorld().spawnParticle(Particle.SWEEP_ATTACK, next, 1);
                for (Entity e : next.getWorld().getNearbyEntities(next, 1.6, 1.2, 1.6)) {
                    if (!(e instanceof LivingEntity le) || e.equals(owner) || hit.contains(e.getUniqueId())) continue;
                    if (plugin.summons().isOwnedSummon(owner, e)) continue;
                    hit.add(e.getUniqueId());
                    hit(le, damage, owner, false, false);
                }
                if (!next.getBlock().isPassable()) {
                    cutSoftLine(owner, next, dir, 3);
                    slash.remove();
                    cancel();
                    return;
                }
                cutSoftLine(owner, next, dir, 1.2);
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    /** Afterimage silhouette of a player (Toji blitz). */
    public void afterimage(Player p) {
        Location loc = p.getLocation();
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        org.bukkit.inventory.meta.SkullMeta meta = (org.bukkit.inventory.meta.SkullMeta) head.getItemMeta();
        meta.setPlayerProfile(p.getPlayerProfile());
        head.setItemMeta(meta);
        ItemDisplay d = loc.getWorld().spawn(loc.clone().add(0, 1.2, 0), ItemDisplay.class, display -> {
            display.setItemStack(head);
            display.setBillboard(org.bukkit.entity.Display.Billboard.FIXED);
            display.setTransformation(new org.bukkit.util.Transformation(
                    new Vector3f(), new AxisAngle4f(), new Vector3f(1.4f, 1.4f, 1.4f), new AxisAngle4f()));
            display.setViewRange(1.5f);
            display.setPersistent(false);
        });
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> { if (d.isValid()) d.remove(); }, 12L);
    }
}
