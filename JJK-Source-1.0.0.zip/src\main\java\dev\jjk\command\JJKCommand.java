package dev.jjk.command;

import dev.jjk.JJKPlugin;
import dev.jjk.character.CharacterType;
import dev.jjk.combat.CharacterController;
import dev.jjk.combat.CombatInputListener;
import dev.jjk.combat.SkillDef;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * /jjk — transformation, menu, and the silent zero-cooldown-gate commands used
 * by client keybind mods (CommandKeys etc.):
 *   /jjk skill <1-8> [shift]   /jjk domain   /jjk passive   /jjk ultimate
 * These produce no chat output and run through the exact same cast gate as
 * the vanilla hotbar inputs.
 */
public final class JJKCommand implements CommandExecutor, TabCompleter {

    private final JJKPlugin plugin;
    private final CombatInputListener gate;

    public JJKCommand(JJKPlugin plugin) {
        this.plugin = plugin;
        this.gate = plugin.gate();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            help(sender, args);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);

        // Admin subcommands
        switch (sub) {
            case "reload" -> {
                if (!sender.hasPermission("jjk.admin")) { noPerm(sender); return true; }
                plugin.reloadConfig();
                plugin.messages().reload();
                plugin.fx().reloadConfig();
                plugin.patchNotes().reload();
                sender.sendMessage(plugin.messages().get("general.reload"));
                return true;
            }
            case "give" -> {
                if (!sender.hasPermission("jjk.admin")) { noPerm(sender); return true; }
                if (args.length < 2) { sender.sendMessage(Component.text("/jjk give <finger|blindfold|seal|blood|curse> [player]", NamedTextColor.RED)); return true; }
                Player target = args.length >= 3 ? plugin.getServer().getPlayerExact(args[2])
                        : (sender instanceof Player p ? p : null);
                if (target == null) { sender.sendMessage(Component.text("Player not found.", NamedTextColor.RED)); return true; }
                var item = plugin.cursedItems().create(args[1]);
                if (item == null) { sender.sendMessage(Component.text("Unknown cursed object. Use finger|blindfold|seal|blood|curse.", NamedTextColor.RED)); return true; }
                target.getInventory().addItem(item);
                sender.sendMessage(Component.text("Gave " + args[1] + " to " + target.getName(), NamedTextColor.GREEN));
                return true;
            }
            case "restore" -> {
                if (!sender.hasPermission("jjk.admin")) { noPerm(sender); return true; }
                if (args.length < 2) { sender.sendMessage(Component.text("/jjk restore <player>", NamedTextColor.RED)); return true; }
                Player target = plugin.getServer().getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(Component.text("Player not found.", NamedTextColor.RED)); return true; }
                var backup = dev.jjk.character.InventoryBackup.readFromDisk(plugin, target);
                if (backup == null) { sender.sendMessage(Component.text("No backup on disk for that player.", NamedTextColor.RED)); return true; }
                backup.restore(target);
                dev.jjk.character.InventoryBackup.deleteFromDisk(plugin, target);
                sender.sendMessage(Component.text("Restored " + target.getName() + "'s inventory from backup.", NamedTextColor.GREEN));
                return true;
            }
        }

        if (!(sender instanceof Player p)) {
            sender.sendMessage(Component.text("Only players can use JJK combat commands.", NamedTextColor.RED));
            return true;
        }

        switch (sub) {
            case "help" -> help(p, args);
            case "controls" -> controls(p);
            case "patches", "patch" -> plugin.patchNotes().open(p);
            case "menu" -> plugin.menu().open(p);
            case "transform" -> {
                if (args.length < 2) {
                    p.sendMessage(Component.text("/jjk transform <gojo|sukuna|megumi|yuji|toji>", NamedTextColor.RED));
                    return true;
                }
                CharacterType type = CharacterType.fromString(args[1]);
                if (type == null) {
                    p.sendMessage(Component.text("Unknown character. Options: gojo, sukuna, megumi, yuji, toji", NamedTextColor.RED));
                    return true;
                }
                plugin.characters().transform(p, type);
            }
            case "leave", "exit" -> {
                if (plugin.characters().isTransformed(p)) plugin.characters().exit(p, "/jjk leave");
                else p.sendMessage(Component.text("You are not transformed.", NamedTextColor.YELLOW));
            }
            // ---- Silent keybind-mod commands (Method B) ----
            case "skill" -> {
                if (!plugin.characters().isTransformed(p)) return true;
                if (args.length < 2) return true;
                CharacterController ctrl = plugin.characters().controller(p);
                String token = args[1].toLowerCase(Locale.ROOT);
                SkillDef def;
                if (token.equals("q")) def = ctrl.ultimate(p);
                else if (token.equals("f")) def = ctrl.passive();
                else if (token.equals("fs")) def = ctrl.domain(p);
                else {
                    int slot;
                    try { slot = Integer.parseInt(token); } catch (NumberFormatException ex) { return true; }
                    if (slot < 1 || slot > 8) return true;
                    boolean shift = args.length >= 3 && args[2].equalsIgnoreCase("shift");
                    def = ctrl.skill(p, slot, shift);
                }
                if (def != null) gate.cast(p, def);
            }
            case "dash" -> {
                gate.dash(p);
            }
            case "domain" -> {
                if (!plugin.characters().isTransformed(p)) return true;
                SkillDef def = plugin.characters().controller(p).domain(p);
                if (def != null) gate.cast(p, def);
            }
            case "passive" -> {
                if (!plugin.characters().isTransformed(p)) return true;
                SkillDef def = plugin.characters().controller(p).passive();
                if (def != null) gate.cast(p, def);
            }
            case "ultimate" -> {
                if (!plugin.characters().isTransformed(p)) return true;
                CharacterController ctrl = plugin.characters().controller(p);
                // Shift+G / /jjk ultimate toggles the Ultimate Form:
                // normal 4 moves are swapped for the form's 4 ultimate moves,
                // and swapped back when the ultimate ends.
                if (ctrl == null) return true;
                if (ctrl.isUltimateForm(p)) {
                    ctrl.exitUltimateForm(p);
                } else {
                    ctrl.enterUltimateForm(p);
                }
            }
            default -> help(p, args);
        }
        return true;
    }

    private void help(CommandSender s, String[] args) {
        if (args.length >= 2) {
            CharacterType type = CharacterType.fromString(args[1]);
            if (type == null) {
                s.sendMessage(plugin.messages().get("general.unknown-character"));
                return;
            }
            String base = "characters." + type.id() + ".";
            s.sendMessage(plugin.messages().get(base + "title"));
            s.sendMessage(plugin.messages().get(base + "passive"));
            for (Component line : plugin.messages().getList(base + "moves")) s.sendMessage(line);
            s.sendMessage(plugin.messages().get(base + "ultimate-form"));
            s.sendMessage(plugin.messages().get("help.hint"));
            return;
        }
        s.sendMessage(plugin.messages().get("help.title"));
        s.sendMessage(plugin.messages().get("help.hint"));
        for (Component line : plugin.messages().getList("help.commands")) s.sendMessage(line);
        s.sendMessage(Component.empty());
        controls(s);
        if (s.hasPermission("jjk.admin")) {
            s.sendMessage(Component.empty());
            for (Component line : plugin.messages().getList("help.admin")) s.sendMessage(line);
        }
        s.sendMessage(plugin.messages().get("help.footer"));
    }

    private void controls(CommandSender s) {
        for (Component line : plugin.messages().getList("help.controls")) s.sendMessage(line);
        s.sendMessage(Component.empty());
        for (Component line : plugin.messages().getList("help.keybinds")) s.sendMessage(line);
    }

    private void noPerm(CommandSender s) {
        s.sendMessage(plugin.messages().get("general.no-permission"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> base = new ArrayList<>(Arrays.asList("transform", "leave", "menu", "skill", "domain", "passive", "ultimate", "dash", "help", "controls", "patches"));
            if (sender.hasPermission("jjk.admin")) base.addAll(Arrays.asList("reload", "give", "restore"));
            return filter(base, args[0]);
        }
        if (args.length == 2) {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "transform", "help" -> { return filter(Arrays.asList("gojo", "sukuna", "megumi", "yuji", "toji"), args[1]); }
                case "skill" -> { return filter(Arrays.asList("1", "2", "3", "4", "5", "6", "q", "f", "fs"), args[1]); }
                case "give" -> { return filter(Arrays.asList("finger", "blindfold", "seal", "blood", "curse"), args[1]); }
                case "restore" -> { return null; }
            }
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("skill")) {
            return filter(List.of("shift"), args[2]);
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String prefix) {
        List<String> out = new ArrayList<>();
        for (String o : options) if (o.toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))) out.add(o);
        return out;
    }
}
